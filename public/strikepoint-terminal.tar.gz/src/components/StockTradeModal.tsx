import React, { useState } from 'react';
import { Ticker, Order, Position, TradeLeg } from '../types/options';
import { playKeyClick, playExecutionChime } from '../utils/terminalSound';
import { X, DollarSign, TrendingUp, TrendingDown, ArrowRight, ShieldAlert, Check } from 'lucide-react';

interface StockTradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  ticker: Ticker;
  cashBalance: number;
  onExecuteTrade: (order: Order, position: Position) => void;
}

export const StockTradeModal: React.FC<StockTradeModalProps> = ({
  isOpen,
  onClose,
  ticker,
  cashBalance,
  onExecuteTrade,
}) => {
  if (!isOpen) return null;

  const isFuture = ticker.symbol.startsWith('/') || ticker.assetType === 'future';
  const defaultQuantity = isFuture ? 1 : 100;

  const [action, setAction] = useState<'buy' | 'sell'>('buy');
  const [orderType, setOrderType] = useState<'market' | 'limit'>('market');
  const [quantity, setQuantity] = useState<number>(defaultQuantity);
  const [limitPrice, setLimitPrice] = useState<number>(ticker.price);

  const multiplier = isFuture ? (ticker.multiplier || 50) : 1;
  const executionPrice = orderType === 'market' ? ticker.price : limitPrice;

  // Notional value & estimated cash/margin requirement
  const notionalCost = quantity * executionPrice * multiplier;
  // Margin required: full cash for stock buy, or initial margin for futures ($5,000 per contract)
  const marginRequired = isFuture ? quantity * 5000 : notionalCost;
  const hasSufficientBP = cashBalance >= marginRequired;

  const handleSendOrder = () => {
    if (!hasSufficientBP && action === 'buy') {
      alert(`Insufficient Buying Power. Required: $${marginRequired.toLocaleString()} | Available: $${cashBalance.toLocaleString()}`);
      return;
    }

    playExecutionChime();

    const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
    const orderId = `ORD-${isFuture ? 'FUT' : 'STK'}-${Date.now().toString().slice(-6)}`;
    const positionId = `POS-${isFuture ? 'FUT' : 'STK'}-${Date.now().toString().slice(-6)}`;

    const leg: TradeLeg = {
      id: `leg-${orderId}`,
      type: isFuture ? 'future' : 'stock',
      action,
      strike: executionPrice,
      expiration: isFuture ? 'Front Month' : 'Perpetual',
      dte: 0,
      iv: 0,
      premium: executionPrice,
      contracts: quantity,
      multiplier,
      underlyingSymbol: ticker.symbol,
    };

    const isDebit = action === 'buy';
    const cashImpact = isDebit ? notionalCost : -notionalCost;

    const newOrder: Order = {
      id: orderId,
      timestamp,
      ticker: ticker.symbol,
      strategyName: `${action === 'buy' ? 'Long' : 'Short'} ${isFuture ? 'Futures' : 'Stock'} (${quantity} ${isFuture ? 'cts' : 'shs'})`,
      type: orderType,
      limitPrice: executionPrice,
      legs: [leg],
      contracts: quantity,
      netDebitCredit: cashImpact,
      totalCost: notionalCost,
      status: 'filled',
      assetCategory: isFuture ? 'future' : 'stock',
      sharesOrContracts: quantity,
    };

    const newPosition: Position = {
      id: positionId,
      ticker: ticker.symbol,
      strategyName: `${action === 'buy' ? 'Long' : 'Short'} ${isFuture ? 'Future' : 'Stock'}`,
      openedAt: timestamp,
      legs: [leg],
      contracts: quantity,
      entryCost: cashImpact,
      currentMark: cashImpact,
      unrealizedPnL: 0,
      unrealizedPnLPercent: 0,
    };

    onExecuteTrade(newOrder, newPosition);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4 font-mono text-xs">
      <div className="bg-[#1e1e1e] border-2 border-[var(--accent)] rounded max-w-lg w-full shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-[var(--sidebar-bg)] border-b border-[var(--border)] px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[var(--accent)] font-black text-sm">
              {isFuture ? 'FUTURES ORDER TICKET' : 'STOCK ORDER TICKET'}
            </span>
            <span className="text-[#fff] font-bold">
              {ticker.symbol} · ${ticker.price.toFixed(2)}
            </span>
            <span className={ticker.change >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}>
              {ticker.change >= 0 ? '+' : ''}{ticker.changePercent.toFixed(2)}%
            </span>
          </div>
          <button
            onClick={() => {
              playKeyClick();
              onClose();
            }}
            className="text-[#8c8c8c] hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 flex flex-col gap-4">
          {/* Action Tabs: BUY vs SELL */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                playKeyClick();
                setAction('buy');
              }}
              className={`py-2 rounded font-extrabold text-xs transition-all flex items-center justify-center gap-1.5 ${
                action === 'buy'
                  ? 'bg-[var(--bull)] text-white shadow-md'
                  : 'bg-[#141b28] text-[#8c8c8c] border border-[#222d44] hover:text-white'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>BUY / GO LONG</span>
            </button>

            <button
              onClick={() => {
                playKeyClick();
                setAction('sell');
              }}
              className={`py-2 rounded font-extrabold text-xs transition-all flex items-center justify-center gap-1.5 ${
                action === 'sell'
                  ? 'bg-[var(--bear)] text-white shadow-md'
                  : 'bg-[#141b28] text-[#8c8c8c] border border-[#222d44] hover:text-white'
              }`}
            >
              <TrendingDown className="w-3.5 h-3.5" />
              <span>SELL / GO SHORT</span>
            </button>
          </div>

          {/* Quantity Selector */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] text-[#8c8c8c] font-bold">
              {isFuture ? 'NUMBER OF CONTRACTS:' : 'NUMBER OF SHARES:'}
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="1"
                max="10000"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                className="bg-[#111] border border-[#3c3c3c] text-white font-extrabold text-sm px-3 py-1.5 rounded w-32 font-mono"
              />
              <div className="flex items-center gap-1">
                {(isFuture ? [1, 2, 5, 10] : [10, 50, 100, 500]).map((qty) => (
                  <button
                    key={qty}
                    onClick={() => {
                      playKeyClick();
                      setQuantity(qty);
                    }}
                    className={`px-2.5 py-1 rounded text-[10px] font-bold border transition-all ${
                      quantity === qty
                        ? 'bg-[var(--accent)] text-black border-[var(--accent)]'
                        : 'bg-[#181a1d] text-[#8c8c8c] border-[#333] hover:text-white'
                    }`}
                  >
                    +{qty}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Order Type & Price */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-[#8c8c8c] font-bold block mb-1">
                ORDER TYPE:
              </label>
              <select
                value={orderType}
                onChange={(e) => {
                  playKeyClick();
                  setOrderType(e.target.value as 'market' | 'limit');
                }}
                className="w-full bg-[#111] border border-[#3c3c3c] text-white px-2 py-1.5 rounded font-mono font-bold"
              >
                <option value="market">MARKET</option>
                <option value="limit">LIMIT</option>
              </select>
            </div>

            <div>
              <label className="text-[10px] text-[#8c8c8c] font-bold block mb-1">
                {orderType === 'market' ? 'MARKET PRICE ($):' : 'LIMIT PRICE ($):'}
              </label>
              <input
                type="number"
                step={ticker.tickSize || 0.01}
                disabled={orderType === 'market'}
                value={orderType === 'market' ? ticker.price : limitPrice}
                onChange={(e) => setLimitPrice(parseFloat(e.target.value) || ticker.price)}
                className={`w-full bg-[#111] border border-[#3c3c3c] text-white px-2 py-1.5 rounded font-mono font-bold ${
                  orderType === 'market' ? 'opacity-60 cursor-not-allowed' : ''
                }`}
              />
            </div>
          </div>

          {/* Execution Cost & Buying Power Impact Details */}
          <div className="bg-[#121417] border border-[#2d3339] p-3 rounded flex flex-col gap-2 text-[11px]">
            <div className="flex justify-between items-center text-[#8c8c8c]">
              <span>Contract Multiplier:</span>
              <span className="text-white font-bold">
                {isFuture ? `${multiplier}x ($${multiplier} per pt)` : '1x ($1.00 per share)'}
              </span>
            </div>

            <div className="flex justify-between items-center text-[#8c8c8c]">
              <span>Estimated Notional Value:</span>
              <span className="text-white font-extrabold">
                ${notionalCost.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>

            <div className="flex justify-between items-center text-[#8c8c8c]">
              <span>Required Margin / Cash:</span>
              <span className="text-[#ffd600] font-extrabold">
                ${marginRequired.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>

            <div className="flex justify-between items-center border-t border-[#26292d] pt-1.5">
              <span className="text-[#8c8c8c]">Available Account BP:</span>
              <span className={hasSufficientBP ? 'text-[var(--bull)] font-bold' : 'text-[var(--bear)] font-bold'}>
                ${cashBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          {!hasSufficientBP && action === 'buy' && (
            <div className="bg-[#e53935]/20 border border-[#e53935]/50 text-[#e53935] p-2 rounded flex items-center gap-2 text-[10px]">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              <span>Insufficient Buying Power to execute this order. Reduce quantity.</span>
            </div>
          )}
        </div>

        {/* Footer Execution Action */}
        <div className="bg-[var(--sidebar-bg)] border-t border-[var(--border)] px-4 py-3 flex items-center justify-between">
          <button
            onClick={() => {
              playKeyClick();
              onClose();
            }}
            className="tos-btn px-4"
          >
            CANCEL
          </button>

          <button
            onClick={handleSendOrder}
            disabled={!hasSufficientBP && action === 'buy'}
            className={`px-6 py-2 rounded font-black text-xs transition-all shadow-lg flex items-center gap-2 ${
              action === 'buy'
                ? 'bg-[var(--bull)] hover:bg-[#4caf50] text-white'
                : 'bg-[var(--bear)] hover:bg-[#ef5350] text-white'
            } ${!hasSufficientBP && action === 'buy' ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <span>TRANSMIT {action.toUpperCase()} ORDER</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useMemo } from 'react';
import { Ticker, TradeLeg, Position, ExpirationOptionChain } from '../types/options';
import {
  analyzeStrategy,
  calculateStrategyPayoff,
  calculateTheoreticalLeg,
  StrategyPayoffPoint,
  StrategyAnalysis,
  SkewModelConfig,
  DEFAULT_SKEW_MODEL,
  SKEW_MODEL_PRESETS,
} from '../utils/blackScholes';
import {
  ALL_OPTIONS_STRATEGIES,
  generateStrategyLegs,
} from '../services/optionsStrategies';
import { playKeyClick, playTickBlip } from '../utils/terminalSound';
import {
  Activity,
  Sliders,
  Calendar,
  Layers,
  CheckCircle,
  Crosshair,
  TrendingUp,
  TrendingDown,
  Info,
  DollarSign,
  ArrowRight,
  Eye,
  EyeOff,
  RotateCcw,
  Sparkles,
  Zap,
  Maximize2,
  Minimize2,
  Trash2,
  Percent,
  RefreshCw,
  ChevronDown,
  ChevronUp,
  Shield,
} from 'lucide-react';

interface RiskProfileViewProps {
  ticker: Ticker;
  chain: ExpirationOptionChain;
  allChains: ExpirationOptionChain[];
  builderLegs: TradeLeg[];
  portfolioPositions: Position[];
  onAddLeg?: (newLeg: TradeLeg) => void;
  onUpdateLeg: (updatedLeg: TradeLeg) => void;
  onRemoveLeg: (legId: string) => void;
  onClearLegs: () => void;
  onApplyStrategyTemplate: (templateName: string) => void;
  onNavigateToChain: () => void;
  onNavigateToValuation: () => void;
  onNavigateToCone: () => void;
  onNavigateToScenario: () => void;
  onOpenStockTrade?: () => void;
  onSelectTicker?: (symbol: string) => void;
  onSeedPositions?: () => void;
  onOpenExpectedMove?: () => void;
  onOpenStrategyCatalog?: () => void;
}

export type RiskProfileSource = 'builder' | 'portfolio' | 'preset';

export const RiskProfileView: React.FC<RiskProfileViewProps> = ({
  ticker,
  chain,
  allChains,
  builderLegs,
  portfolioPositions,
  onAddLeg,
  onUpdateLeg,
  onRemoveLeg,
  onClearLegs,
  onApplyStrategyTemplate,
  onNavigateToChain,
  onNavigateToValuation,
  onNavigateToCone,
  onNavigateToScenario,
  onOpenStockTrade,
  onSelectTicker,
  onSeedPositions,
  onOpenExpectedMove,
  onOpenStrategyCatalog,
}) => {
  const currentPrice = ticker.price;

  // View Source: Builder Legs, Portfolio Positions, or Preset
  const [sourceMode, setSourceMode] = useState<RiskProfileSource>(() => {
    if (builderLegs.length > 0) return 'builder';
    if (portfolioPositions.length > 0) return 'portfolio';
    return 'preset';
  });

  // Toggle for persistent Portfolio Stocks & Futures tray
  const [isPortfolioTrayExpanded, setIsPortfolioTrayExpanded] = useState<boolean>(true);

  // Selected Preset Strategy if in preset mode
  const [selectedPreset, setSelectedPreset] = useState<string>('Iron Condor');

  // Portfolio filter states for Stocks, Futures, and Options
  const [portfolioCategoryFilter, setPortfolioCategoryFilter] = useState<'ALL' | 'STOCKS' | 'FUTURES' | 'OPTIONS'>('ALL');
  const [portfolioTickerFilter, setPortfolioTickerFilter] = useState<'CURRENT' | 'ALL_TICKERS'>('ALL_TICKERS');
  const [enabledPositionIds, setEnabledPositionIds] = useState<Record<string, boolean>>({});

  // Interactive Simulation Deck state
  const [timeElapsedDays, setTimeElapsedDays] = useState<number>(0);
  const [ivShiftPercent, setIvShiftPercent] = useState<number>(0);
  const [priceShockPct, setPriceShockPct] = useState<number>(0);

  // Curve Visibility Toggles
  const [showExpirationCurve, setShowExpirationCurve] = useState<boolean>(true);
  const [showTodayCurve, setShowTodayCurve] = useState<boolean>(true);
  const [showSimulatedCurve, setShowSimulatedCurve] = useState<boolean>(true);
  const [showSigmaBands, setShowSigmaBands] = useState<boolean>(true);
  const [showBreakevens, setShowBreakevens] = useState<boolean>(true);
  const [isBiggerPictureExpanded, setIsBiggerPictureExpanded] = useState<boolean>(true);

  // Enabled Legs Filter (for "What-If" leg elimination)
  const [enabledLegIds, setEnabledLegIds] = useState<Record<string, boolean>>({});

  // Individual Implied Volatility overrides per simulated trade leg ID (e.g. { 'leg-1': 0.35 })
  const [individualIvOverrides, setIndividualIvOverrides] = useState<Record<string, number>>({});

  // Volatility Skew Model configuration for Calendar & Double Diagonal risk profiles
  const [skewModel, setSkewModel] = useState<SkewModelConfig>(DEFAULT_SKEW_MODEL);
  const [isSkewModelEnabled, setIsSkewModelEnabled] = useState<boolean>(true);
  const [isSkewPanelExpanded, setIsSkewPanelExpanded] = useState<boolean>(true);
  const [selectedSkewPresetKey, setSelectedSkewPresetKey] = useState<string>('doubleDiagonalWingSkew');
  const [showUnskewedOverlay, setShowUnskewedOverlay] = useState<boolean>(true);

  // Hovered Point for Crosshair Ruler
  const [hoveredPoint, setHoveredPoint] = useState<StrategyPayoffPoint | null>(null);

  // Generate synthetic preset legs if in preset mode
  const presetLegs = useMemo((): TradeLeg[] => {
    const calls = chain.calls;
    const puts = chain.puts;
    const S = currentPrice;
    const exp = chain.formattedDate;
    const dte = chain.dte;

    let atmIdx = 0;
    let minDiff = Infinity;
    calls.forEach((c, idx) => {
      const diff = Math.abs(c.strike - S);
      if (diff < minDiff) {
        minDiff = diff;
        atmIdx = idx;
      }
    });

    // Check if selectedPreset matches any institutional strategy in ALL_OPTIONS_STRATEGIES
    const matchingStrategy = ALL_OPTIONS_STRATEGIES.find(
      (st) =>
        st.id === selectedPreset ||
        st.name.toLowerCase() === selectedPreset.toLowerCase() ||
        selectedPreset.toLowerCase().includes(st.id) ||
        selectedPreset.toLowerCase().includes(st.name.toLowerCase())
    );
    if (matchingStrategy) {
      return generateStrategyLegs(matchingStrategy.id, ticker, chain, allChains);
    }

    switch (selectedPreset) {
      case 'Iron Condor': {
        const lp = puts[Math.max(0, atmIdx - 4)];
        const sp = puts[Math.max(0, atmIdx - 2)];
        const sc = calls[Math.min(calls.length - 1, atmIdx + 2)];
        const lc = calls[Math.min(calls.length - 1, atmIdx + 4)];
        return [
          { id: 'pre-ic-lp', type: 'put', action: 'buy', strike: lp.strike, expiration: exp, dte, iv: lp.iv, premium: lp.ask, contracts: 1 },
          { id: 'pre-ic-sp', type: 'put', action: 'sell', strike: sp.strike, expiration: exp, dte, iv: sp.iv, premium: sp.bid, contracts: 1 },
          { id: 'pre-ic-sc', type: 'call', action: 'sell', strike: sc.strike, expiration: exp, dte, iv: sc.iv, premium: sc.bid, contracts: 1 },
          { id: 'pre-ic-lc', type: 'call', action: 'buy', strike: lc.strike, expiration: exp, dte, iv: lc.iv, premium: lc.ask, contracts: 1 },
        ];
      }
      case 'Covered Call': {
        const otmCall = calls[Math.min(calls.length - 1, atmIdx + 1)];
        return [
          { id: 'pre-cc-stock', type: 'stock', action: 'buy', strike: S, expiration: 'Perpetual', dte: 0, iv: 0, premium: S, contracts: 100, multiplier: 1, underlyingSymbol: ticker.symbol },
          { id: 'pre-cc-call', type: 'call', action: 'sell', strike: otmCall.strike, expiration: exp, dte, iv: otmCall.iv, premium: otmCall.bid, contracts: 1, multiplier: 100, underlyingSymbol: ticker.symbol },
        ];
      }
      case 'Protective Put': {
        const otmPut = puts[Math.max(0, atmIdx - 1)];
        return [
          { id: 'pre-pp-stock', type: 'stock', action: 'buy', strike: S, expiration: 'Perpetual', dte: 0, iv: 0, premium: S, contracts: 100, multiplier: 1, underlyingSymbol: ticker.symbol },
          { id: 'pre-pp-put', type: 'put', action: 'buy', strike: otmPut.strike, expiration: exp, dte, iv: otmPut.iv, premium: otmPut.ask, contracts: 1, multiplier: 100, underlyingSymbol: ticker.symbol },
        ];
      }
      case 'Collar': {
        const otmPut = puts[Math.max(0, atmIdx - 2)];
        const otmCall = calls[Math.min(calls.length - 1, atmIdx + 2)];
        return [
          { id: 'pre-col-stock', type: 'stock', action: 'buy', strike: S, expiration: 'Perpetual', dte: 0, iv: 0, premium: S, contracts: 100, multiplier: 1, underlyingSymbol: ticker.symbol },
          { id: 'pre-col-put', type: 'put', action: 'buy', strike: otmPut.strike, expiration: exp, dte, iv: otmPut.iv, premium: otmPut.ask, contracts: 1, multiplier: 100, underlyingSymbol: ticker.symbol },
          { id: 'pre-col-call', type: 'call', action: 'sell', strike: otmCall.strike, expiration: exp, dte, iv: otmCall.iv, premium: otmCall.bid, contracts: 1, multiplier: 100, underlyingSymbol: ticker.symbol },
        ];
      }
      case 'Long Stock (100 shs)': {
        return [
          { id: 'pre-stk-buy', type: 'stock', action: 'buy', strike: S, expiration: 'Perpetual', dte: 0, iv: 0, premium: S, contracts: 100, multiplier: 1, underlyingSymbol: ticker.symbol },
        ];
      }
      case 'Short Stock (-100 shs)': {
        return [
          { id: 'pre-stk-sell', type: 'stock', action: 'sell', strike: S, expiration: 'Perpetual', dte: 0, iv: 0, premium: S, contracts: 100, multiplier: 1, underlyingSymbol: ticker.symbol },
        ];
      }
      case 'Long Future (1 ct)': {
        const mult = ticker.multiplier || (ticker.symbol === '/CL' ? 1000 : 50);
        return [
          { id: 'pre-fut-buy', type: 'future', action: 'buy', strike: S, expiration: 'Front Month', dte: 0, iv: 0, premium: S, contracts: 1, multiplier: mult, underlyingSymbol: ticker.symbol },
        ];
      }
      case 'Short Future (-1 ct)': {
        const mult = ticker.multiplier || (ticker.symbol === '/CL' ? 1000 : 50);
        return [
          { id: 'pre-fut-sell', type: 'future', action: 'sell', strike: S, expiration: 'Front Month', dte: 0, iv: 0, premium: S, contracts: 1, multiplier: mult, underlyingSymbol: ticker.symbol },
        ];
      }
      case 'Future + Protective Put': {
        const mult = ticker.multiplier || (ticker.symbol === '/CL' ? 1000 : 50);
        const otmPut = puts[Math.max(0, atmIdx - 1)];
        return [
          { id: 'pre-fhp-fut', type: 'future', action: 'buy', strike: S, expiration: 'Front Month', dte: 0, iv: 0, premium: S, contracts: 1, multiplier: mult, underlyingSymbol: ticker.symbol },
          { id: 'pre-fhp-put', type: 'put', action: 'buy', strike: otmPut.strike, expiration: exp, dte, iv: otmPut.iv, premium: otmPut.ask, contracts: 1, multiplier: mult, underlyingSymbol: ticker.symbol },
        ];
      }
      case 'Bull Call Spread': {
        const buyC = calls[Math.max(0, atmIdx - 1)];
        const sellC = calls[Math.min(calls.length - 1, atmIdx + 2)];
        return [
          { id: 'pre-bcs-buy', type: 'call', action: 'buy', strike: buyC.strike, expiration: exp, dte, iv: buyC.iv, premium: buyC.ask, contracts: 1 },
          { id: 'pre-bcs-sell', type: 'call', action: 'sell', strike: sellC.strike, expiration: exp, dte, iv: sellC.iv, premium: sellC.bid, contracts: 1 },
        ];
      }
      case 'Bear Put Spread': {
        const buyP = puts[Math.min(puts.length - 1, atmIdx + 1)];
        const sellP = puts[Math.max(0, atmIdx - 2)];
        return [
          { id: 'pre-bps-buy', type: 'put', action: 'buy', strike: buyP.strike, expiration: exp, dte, iv: buyP.iv, premium: buyP.ask, contracts: 1 },
          { id: 'pre-bps-sell', type: 'put', action: 'sell', strike: sellP.strike, expiration: exp, dte, iv: sellP.iv, premium: sellP.bid, contracts: 1 },
        ];
      }
      case 'Long Straddle': {
        const c = calls[atmIdx];
        const p = puts[atmIdx];
        return [
          { id: 'pre-strd-c', type: 'call', action: 'buy', strike: c.strike, expiration: exp, dte, iv: c.iv, premium: c.ask, contracts: 1 },
          { id: 'pre-strd-p', type: 'put', action: 'buy', strike: p.strike, expiration: exp, dte, iv: p.iv, premium: p.ask, contracts: 1 },
        ];
      }
      case 'Long Strangle': {
        const p = puts[Math.max(0, atmIdx - 2)];
        const c = calls[Math.min(calls.length - 1, atmIdx + 2)];
        return [
          { id: 'pre-strg-p', type: 'put', action: 'buy', strike: p.strike, expiration: exp, dte, iv: p.iv, premium: p.ask, contracts: 1 },
          { id: 'pre-strg-c', type: 'call', action: 'buy', strike: c.strike, expiration: exp, dte, iv: c.iv, premium: c.ask, contracts: 1 },
        ];
      }
      case 'Long Call': {
        const c = calls[atmIdx];
        return [
          { id: 'pre-lc', type: 'call', action: 'buy', strike: c.strike, expiration: exp, dte, iv: c.iv, premium: c.ask, contracts: 1 },
        ];
      }
      case 'Long Put': {
        const p = puts[atmIdx];
        return [
          { id: 'pre-lp', type: 'put', action: 'buy', strike: p.strike, expiration: exp, dte, iv: p.iv, premium: p.ask, contracts: 1 },
        ];
      }
      default:
        return [];
    }
  }, [selectedPreset, chain, currentPrice]);

  // Portfolio category stats and aggregate financial exposures
  const portfolioStats = useMemo(() => {
    let stocksCount = 0;
    let futuresCount = 0;
    let optionsCount = 0;

    portfolioPositions.forEach((p) => {
      const isStock = p.legs.some((l) => l.type === 'stock') || p.strategyName.toLowerCase().includes('stock');
      const isFuture = p.legs.some((l) => l.type === 'future') || p.strategyName.toLowerCase().includes('future') || p.ticker.startsWith('/');
      if (isStock) stocksCount++;
      else if (isFuture) futuresCount++;
      else optionsCount++;
    });

    return { stocksCount, futuresCount, optionsCount, total: portfolioPositions.length };
  }, [portfolioPositions]);

  // Aggregate financial metrics across portfolio asset classes
  const portfolioAggregates = useMemo(() => {
    let totalStockValue = 0;
    let totalStockPnL = 0;
    let totalStockDelta = 0;

    let totalFuturesNotional = 0;
    let totalFuturesPnL = 0;
    let totalFuturesDelta = 0;

    let totalOptionsPnL = 0;
    let totalOptionsMark = 0;

    let netPnL = 0;

    portfolioPositions.forEach((pos) => {
      netPnL += pos.unrealizedPnL;
      const isStock = pos.legs.some((l) => l.type === 'stock') || pos.strategyName.toLowerCase().includes('stock');
      const isFuture = pos.legs.some((l) => l.type === 'future') || pos.strategyName.toLowerCase().includes('future') || pos.ticker.startsWith('/');

      if (isStock) {
        totalStockValue += Math.abs(pos.currentMark);
        totalStockPnL += pos.unrealizedPnL;
        pos.legs.forEach((l) => {
          if (l.type === 'stock') {
            totalStockDelta += (l.action === 'buy' ? 1 : -1) * l.contracts * (l.multiplier || 1);
          }
        });
      } else if (isFuture) {
        totalFuturesNotional += Math.abs(pos.currentMark);
        totalFuturesPnL += pos.unrealizedPnL;
        pos.legs.forEach((l) => {
          if (l.type === 'future') {
            totalFuturesDelta += (l.action === 'buy' ? 1 : -1) * l.contracts * (l.multiplier || 50);
          }
        });
      } else {
        totalOptionsMark += pos.currentMark;
        totalOptionsPnL += pos.unrealizedPnL;
      }
    });

    return {
      totalStockValue,
      totalStockPnL,
      totalStockDelta,
      totalFuturesNotional,
      totalFuturesPnL,
      totalFuturesDelta,
      totalOptionsMark,
      totalOptionsPnL,
      netPnL,
    };
  }, [portfolioPositions]);

  // Filtered portfolio positions based on category & ticker scope
  const visiblePortfolioPositions = useMemo(() => {
    return portfolioPositions.filter((p) => {
      if (portfolioTickerFilter === 'CURRENT' && p.ticker !== ticker.symbol) return false;
      const isStock = p.legs.some((l) => l.type === 'stock') || p.strategyName.toLowerCase().includes('stock');
      const isFuture = p.legs.some((l) => l.type === 'future') || p.strategyName.toLowerCase().includes('future') || p.ticker.startsWith('/');
      const isOption = !isStock && !isFuture;

      if (portfolioCategoryFilter === 'STOCKS') return isStock;
      if (portfolioCategoryFilter === 'FUTURES') return isFuture;
      if (portfolioCategoryFilter === 'OPTIONS') return isOption;
      return true;
    });
  }, [portfolioPositions, portfolioTickerFilter, portfolioCategoryFilter, ticker.symbol]);

  // Source simulated trade legs prior to checkbox filter
  const allSourceLegs = useMemo((): TradeLeg[] => {
    let source: TradeLeg[] = [];
    if (sourceMode === 'builder') {
      source = builderLegs;
    } else if (sourceMode === 'portfolio') {
      // Flatten legs from filtered open positions (stocks, futures, options)
      const enabledPositions = visiblePortfolioPositions.filter(
        (p) => enabledPositionIds[p.id] !== false
      );
      // Prefer positions matching current ticker to avoid mixing wildly different price scales on 1 curve
      const matchingCurrent = enabledPositions.filter((p) => p.ticker === ticker.symbol);
      const targetPositions = matchingCurrent.length > 0 ? matchingCurrent : enabledPositions;
      source = targetPositions.flatMap((p) => p.legs);
    } else {
      source = presetLegs;
    }
    return source;
  }, [sourceMode, builderLegs, visiblePortfolioPositions, enabledPositionIds, presetLegs, ticker.symbol]);

  // Active enabled legs used for payoff curves and analysis
  const activeLegs = useMemo((): TradeLeg[] => {
    return allSourceLegs.filter((leg) => enabledLegIds[leg.id] !== false);
  }, [allSourceLegs, enabledLegIds]);

  // Effective legs incorporating individual IV overrides
  const legsWithEffectiveIv = useMemo((): TradeLeg[] => {
    return activeLegs.map((leg) => {
      const override = individualIvOverrides[leg.id];
      if (override !== undefined && leg.type !== 'stock' && leg.type !== 'future') {
        return { ...leg, iv: override };
      }
      return leg;
    });
  }, [activeLegs, individualIvOverrides]);

  const maxDte = useMemo(() => {
    const optLegs = legsWithEffectiveIv.filter((l) => l.type === 'call' || l.type === 'put');
    return optLegs.length > 0 ? Math.max(...optLegs.map((l) => l.dte)) : 30;
  }, [legsWithEffectiveIv]);

  // Inspect if active position has multiple expiration cycles (Calendar, Double Calendar, Diagonal, Double Diagonal)
  const calendarDiagonalDetails = useMemo(() => {
    const optLegs = legsWithEffectiveIv.filter((l) => l.type === 'call' || l.type === 'put');
    if (optLegs.length < 2) return null;
    const dtes = Array.from(new Set(optLegs.map((l) => l.dte))).sort((a, b) => a - b);
    if (dtes.length < 2) return null;
    const frontDte = dtes[0];
    const backDte = dtes[dtes.length - 1];
    const frontLegs = optLegs.filter((l) => l.dte === frontDte);
    const backLegs = optLegs.filter((l) => l.dte === backDte);
    const isDoubleDiagonal = optLegs.length >= 4 && frontLegs.length >= 2 && backLegs.length >= 2;
    const isDoubleCalendar =
      isDoubleDiagonal &&
      frontLegs.every((fl) => backLegs.some((bl) => bl.strike === fl.strike && bl.type === fl.type));
    const isCalendar = frontLegs.some((fl) => backLegs.some((bl) => bl.strike === fl.strike && bl.type === fl.type));
    return {
      frontDte,
      backDte,
      dteGap: backDte - frontDte,
      frontLegs,
      backLegs,
      isDoubleDiagonal,
      isDoubleCalendar,
      isCalendar,
    };
  }, [legsWithEffectiveIv]);

  const isCalendarOrDiagonal = calendarDiagonalDetails !== null;
  const activeSkewModel = isSkewModelEnabled ? skewModel : undefined;

  // Analyze strategy with effective individual leg IVs and skew model
  const analysis: StrategyAnalysis = useMemo(() => {
    return analyzeStrategy(legsWithEffectiveIv, currentPrice, activeSkewModel);
  }, [legsWithEffectiveIv, currentPrice, activeSkewModel]);

  // Generate high-resolution Payoff and Greeks Curve Points with individual IV overrides and skew model
  const payoffPoints = useMemo(() => {
    return calculateStrategyPayoff(
      legsWithEffectiveIv,
      currentPrice,
      ivShiftPercent / 100,
      timeElapsedDays,
      undefined,
      undefined,
      individualIvOverrides,
      activeSkewModel
    );
  }, [legsWithEffectiveIv, currentPrice, ivShiftPercent, timeElapsedDays, individualIvOverrides, activeSkewModel]);

  // Unskewed Baseline Curve (Flat Vol / Zero Skew Reference)
  const unskewedPayoffPoints = useMemo(() => {
    if (!isSkewModelEnabled) return null;
    return calculateStrategyPayoff(
      legsWithEffectiveIv,
      currentPrice,
      ivShiftPercent / 100,
      timeElapsedDays,
      undefined,
      undefined,
      individualIvOverrides,
      undefined // Flat BSM baseline
    );
  }, [legsWithEffectiveIv, currentPrice, ivShiftPercent, timeElapsedDays, individualIvOverrides, isSkewModelEnabled]);

  // Front-month DTE for calendar and diagonal spreads
  const frontDte = useMemo(() => {
    const optLegs = activeLegs.filter((l) => l.type === 'call' || l.type === 'put');
    return optLegs.length > 0 ? Math.min(...optLegs.map((l) => l.dte)) : undefined;
  }, [activeLegs]);

  // Calculate Statistical Sigma Bands based on 30D / DTE Volatility
  const sigma1Move = useMemo(() => {
    const T = Math.max(0.005, maxDte / 365);
    const effectiveIV = Math.max(0.08, ticker.currentIV + ivShiftPercent / 100);
    return currentPrice * effectiveIV * Math.sqrt(T);
  }, [currentPrice, ticker.currentIV, ivShiftPercent, maxDte]);

  const sigma2Move = sigma1Move * 2;
  const lower1Sigma = currentPrice - sigma1Move;
  const upper1Sigma = currentPrice + sigma1Move;
  const lower2Sigma = currentPrice - sigma2Move;
  const upper2Sigma = currentPrice + sigma2Move;

  // SVG Chart Dimensions ("Bigger Picture" expansive view)
  const svgWidth = 1040;
  const svgHeight = isBiggerPictureExpanded ? 500 : 380;
  const padding = { top: 32, right: 65, bottom: 45, left: 80 };
  const graphWidth = svgWidth - padding.left - padding.right;
  const graphHeight = svgHeight - padding.top - padding.bottom;

  // Domain & Range calculations
  const { minPrice, maxPrice, minPnl, maxPnl } = useMemo(() => {
    if (!payoffPoints.length) {
      return {
        minPrice: currentPrice * 0.8,
        maxPrice: currentPrice * 1.2,
        minPnl: -500,
        maxPnl: 500,
      };
    }

    const prices = payoffPoints.map((p) => p.price);
    const pnlExps = payoffPoints.map((p) => p.pnlExpiration);
    const pnlTodays = payoffPoints.map((p) => p.pnlT0);

    const minX = Math.min(...prices);
    const maxX = Math.max(...prices);

    let minY = Math.min(...pnlExps, ...pnlTodays);
    let maxY = Math.max(...pnlExps, ...pnlTodays);

    // Provide balanced zero line padding
    if (minY >= 0) minY = -maxY * 0.2;
    if (maxY <= 0) maxY = -minY * 0.2;

    const span = Math.max(100, maxY - minY);
    minY = Math.floor((minY - span * 0.08) / 50) * 50;
    maxY = Math.ceil((maxY + span * 0.08) / 50) * 50;

    return { minPrice: minX, maxPrice: maxX, minPnl: minY, maxPnl: maxY };
  }, [payoffPoints, currentPrice]);

  // Coordinate transforms
  const scaleX = (price: number) => {
    const ratio = (price - minPrice) / (maxPrice - minPrice || 1);
    return padding.left + Math.max(0, Math.min(graphWidth, ratio * graphWidth));
  };

  const scaleY = (pnl: number) => {
    const ratio = (pnl - minPnl) / (maxPnl - minPnl || 1);
    return padding.top + graphHeight - ratio * graphHeight;
  };

  const zeroY = scaleY(0);
  const spotX = scaleX(currentPrice);

  // SVG Paths
  const expirationPath = useMemo(() => {
    if (!payoffPoints.length) return '';
    return payoffPoints.reduce((acc, pt, idx) => {
      const x = scaleX(pt.price);
      const y = scaleY(pt.pnlExpiration);
      return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [payoffPoints, minPrice, maxPrice, minPnl, maxPnl]);

  const todayPath = useMemo(() => {
    if (!payoffPoints.length) return '';
    return payoffPoints.reduce((acc, pt, idx) => {
      const x = scaleX(pt.price);
      const y = scaleY(pt.pnlT0);
      return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [payoffPoints, minPrice, maxPrice, minPnl, maxPnl]);

  // Unskewed baseline overlay paths (for side-by-side comparison with Flat Vol)
  const unskewedExpirationPath = useMemo(() => {
    if (!unskewedPayoffPoints || !unskewedPayoffPoints.length) return '';
    return unskewedPayoffPoints.reduce((acc, pt, idx) => {
      const x = scaleX(pt.price);
      const y = scaleY(pt.pnlExpiration);
      return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [unskewedPayoffPoints, minPrice, maxPrice, minPnl, maxPnl]);

  const unskewedTodayPath = useMemo(() => {
    if (!unskewedPayoffPoints || !unskewedPayoffPoints.length) return '';
    return unskewedPayoffPoints.reduce((acc, pt, idx) => {
      const x = scaleX(pt.price);
      const y = scaleY(pt.pnlT0);
      return idx === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
    }, '');
  }, [unskewedPayoffPoints, minPrice, maxPrice, minPnl, maxPnl]);

  // Area under curve for green (profit) / red (loss) shading at expiration
  const profitAreaPath = useMemo(() => {
    if (!payoffPoints.length) return '';
    const pointsAboveZero = payoffPoints.map((pt) => ({
      x: scaleX(pt.price),
      y: scaleY(Math.max(0, pt.pnlExpiration)),
    }));

    const path = pointsAboveZero.reduce((acc, pt, idx) => {
      return idx === 0 ? `M ${pt.x} ${pt.y}` : `${acc} L ${pt.x} ${pt.y}`;
    }, '');

    return `${path} L ${scaleX(maxPrice)} ${zeroY} L ${scaleX(minPrice)} ${zeroY} Z`;
  }, [payoffPoints, minPrice, maxPrice, minPnl, maxPnl, zeroY]);

  // Breakevens
  const breakEvenLines = useMemo(() => {
    return analysis.breakEvens.map((be) => ({
      price: be,
      x: scaleX(be),
    }));
  }, [analysis.breakEvens, minPrice, maxPrice]);

  // Scenario Table Points
  const scenarioSteps = [-20, -15, -10, -5, -2, 0, 2, 5, 10, 15, 20];
  const scenarioRows = useMemo(() => {
    return scenarioSteps.map((stepPct) => {
      const targetP = Number((currentPrice * (1 + stepPct / 100)).toFixed(2));
      // Closest payoff point
      let closestPt = payoffPoints[0];
      let minDiff = Infinity;
      payoffPoints.forEach((pt) => {
        const diff = Math.abs(pt.price - targetP);
        if (diff < minDiff) {
          minDiff = diff;
          closestPt = pt;
        }
      });

      return {
        stepPct,
        targetP,
        pnlToday: closestPt ? closestPt.pnlT0 : 0,
        pnlExp: closestPt ? closestPt.pnlExpiration : 0,
        delta: closestPt ? closestPt.delta : 0,
        theta: closestPt ? closestPt.theta : 0,
      };
    });
  }, [scenarioSteps, currentPrice, payoffPoints]);

  const toggleLegCheckbox = (legId: string) => {
    playKeyClick();
    setEnabledLegIds((prev) => ({
      ...prev,
      [legId]: prev[legId] === false ? true : false,
    }));
  };

  const togglePositionCheckbox = (posId: string) => {
    playKeyClick();
    setEnabledPositionIds((prev) => ({
      ...prev,
      [posId]: prev[posId] === false ? true : false,
    }));
  };

  // Handler to update an individual simulated trade leg's Implied Volatility
  const handleUpdateLegIv = (leg: TradeLeg, newIv: number) => {
    playKeyClick();
    const clampedIv = Math.max(0.01, Math.min(5.00, Number(newIv.toFixed(4))));
    setIndividualIvOverrides((prev) => ({
      ...prev,
      [leg.id]: clampedIv,
    }));
    if (sourceMode === 'builder') {
      onUpdateLeg({ ...leg, iv: clampedIv });
    }
  };

  // Handler to reset an individual simulated trade leg's Implied Volatility back to base
  const handleResetLegIv = (legId: string, baseLeg: TradeLeg) => {
    playKeyClick();
    setIndividualIvOverrides((prev) => {
      const next = { ...prev };
      delete next[legId];
      return next;
    });
    if (sourceMode === 'builder') {
      const origContract = [...chain.calls, ...chain.puts].find((c) => c.strike === baseLeg.strike);
      const originalIv = origContract ? origContract.iv : ticker.currentIV;
      onUpdateLeg({ ...baseLeg, iv: originalIv });
    }
  };

  // Reset all individual leg IV overrides across simulated trades
  const handleResetAllIndividualIvs = () => {
    playKeyClick();
    setIndividualIvOverrides({});
  };

  // Quick preset: Simulate Post-Earnings IV Crush (-25% relative IV on option legs)
  const handleApplyEarningsCrush = () => {
    playKeyClick();
    const newOverrides: Record<string, number> = {};
    allSourceLegs.forEach((leg) => {
      if (leg.type === 'call' || leg.type === 'put') {
        const baseIv = individualIvOverrides[leg.id] ?? leg.iv;
        const crushed = Math.max(0.05, baseIv * 0.75);
        newOverrides[leg.id] = Number(crushed.toFixed(4));
        if (sourceMode === 'builder') {
          onUpdateLeg({ ...leg, iv: Number(crushed.toFixed(4)) });
        }
      }
    });
    setIndividualIvOverrides(newOverrides);
  };

  // Quick preset: Simulate Event Vol Expansion (+25% relative IV on option legs)
  const handleApplyVolExpansion = () => {
    playKeyClick();
    const newOverrides: Record<string, number> = {};
    allSourceLegs.forEach((leg) => {
      if (leg.type === 'call' || leg.type === 'put') {
        const baseIv = individualIvOverrides[leg.id] ?? leg.iv;
        const expanded = Math.min(5.00, baseIv * 1.25);
        newOverrides[leg.id] = Number(expanded.toFixed(4));
        if (sourceMode === 'builder') {
          onUpdateLeg({ ...leg, iv: Number(expanded.toFixed(4)) });
        }
      }
    });
    setIndividualIvOverrides(newOverrides);
  };

  const handleAddStockLeg = (action: 'buy' | 'sell', shares = 100) => {
    playKeyClick();
    const newLeg: TradeLeg = {
      id: `leg-stk-${Date.now()}`,
      type: 'stock',
      action,
      strike: currentPrice,
      expiration: 'Perpetual',
      dte: 0,
      iv: 0,
      premium: currentPrice,
      contracts: shares,
      multiplier: 1,
      underlyingSymbol: ticker.symbol,
    };
    if (onAddLeg) {
      onAddLeg(newLeg);
    } else {
      onUpdateLeg(newLeg);
    }
    setSourceMode('builder');
  };

  const handleAddFuturesLeg = (action: 'buy' | 'sell', contracts = 1) => {
    playKeyClick();
    const mult = ticker.multiplier || (ticker.symbol === '/CL' ? 1000 : 50);
    const newLeg: TradeLeg = {
      id: `leg-fut-${Date.now()}`,
      type: 'future',
      action,
      strike: currentPrice,
      expiration: 'Front Month',
      dte: 0,
      iv: 0,
      premium: currentPrice,
      contracts,
      multiplier: mult,
      underlyingSymbol: ticker.symbol,
    };
    if (onAddLeg) {
      onAddLeg(newLeg);
    } else {
      onUpdateLeg(newLeg);
    }
    setSourceMode('builder');
  };

  const handleModelPositionInRiskProfile = (pos: Position) => {
    playKeyClick();
    if (onSelectTicker && pos.ticker !== ticker.symbol) {
      onSelectTicker(pos.ticker);
    }
    setSourceMode('portfolio');
    setEnabledPositionIds({ [pos.id]: true });
  };

  const handleStagePositionLegsInBuilder = (pos: Position) => {
    playKeyClick();
    if (onAddLeg) {
      pos.legs.forEach((l) => {
        onAddLeg({
          ...l,
          id: `leg-staged-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
        });
      });
    }
    setSourceMode('builder');
  };

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e] border border-[var(--border)] rounded overflow-hidden font-mono text-xs select-none">
      {/* ========================================================
          1. HEADER BANNER: RISK PROFILE // BIGGER PICTURE ENGINE
      ======================================================== */}
      <div className="bg-[var(--sidebar-bg)] border-b border-[var(--border)] px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-[var(--accent)] font-black text-sm tracking-wider">
              {ticker.symbol} RISK PROFILE
            </span>
            <span className="text-[var(--ink-muted)] text-[11px] hidden md:inline">
              // BIGGER PICTURE VISUAL PAYOFF ENGINE
            </span>
          </div>

          <div className="h-4 w-px bg-[var(--border)]" />

          {/* Source Mode Switcher */}
          <div className="flex items-center bg-[#111] border border-[var(--border)] rounded p-0.5 text-[10px]">
            <button
              onClick={() => {
                playKeyClick();
                setSourceMode('builder');
              }}
              className={`px-2.5 py-0.5 rounded font-bold transition-all ${
                sourceMode === 'builder'
                  ? 'bg-[var(--accent)] text-black font-extrabold shadow-sm'
                  : 'text-[#8c8c8c] hover:text-white'
              }`}
            >
              BUILDER LEGS ({builderLegs.length})
            </button>
            <button
              onClick={() => {
                playKeyClick();
                setSourceMode('portfolio');
              }}
              className={`px-2.5 py-0.5 rounded font-bold transition-all flex items-center gap-1 ${
                sourceMode === 'portfolio'
                  ? 'bg-[#00d2ff] text-black font-extrabold shadow-sm'
                  : 'text-[#8c8c8c] hover:text-white'
              }`}
            >
              <span>PORTFOLIO POSITIONS ({portfolioPositions.length})</span>
              {portfolioPositions.length > 0 && (
                <span className="text-[8.5px] opacity-80">
                  [{portfolioStats.stocksCount} Stk · {portfolioStats.futuresCount} Fut · {portfolioStats.optionsCount} Opt]
                </span>
              )}
            </button>
            <button
              onClick={() => {
                playKeyClick();
                setSourceMode('preset');
              }}
              className={`px-2.5 py-0.5 rounded font-bold transition-all ${
                sourceMode === 'preset'
                  ? 'bg-[#43a047] text-white font-extrabold shadow-sm'
                  : 'text-[#8c8c8c] hover:text-white'
              }`}
            >
              STRATEGY PRESETS
            </button>
          </div>

          {/* Preset Selector Dropdown & Catalog Button */}
          {sourceMode === 'preset' && (
            <div className="flex items-center gap-1.5">
              <select
                value={selectedPreset}
                onChange={(e) => {
                  playKeyClick();
                  const nextPreset = e.target.value;
                  setSelectedPreset(nextPreset);
                  if (nextPreset === 'double-diagonal-spread' || nextPreset.toLowerCase().includes('diagonal')) {
                    setIsSkewModelEnabled(true);
                    setIsSkewPanelExpanded(true);
                    setSelectedSkewPresetKey('doubleDiagonalWingSkew');
                    setSkewModel({ ...SKEW_MODEL_PRESETS.doubleDiagonalWingSkew.config });
                  } else if (nextPreset.includes('calendar')) {
                    setIsSkewModelEnabled(true);
                    setIsSkewPanelExpanded(true);
                    setSelectedSkewPresetKey('normalContango');
                    setSkewModel({ ...SKEW_MODEL_PRESETS.normalContango.config });
                  }
                }}
                className="tos-btn text-[10px] font-bold text-[var(--accent)] py-1 px-2 max-w-[260px] truncate"
              >
                <optgroup label="Single Leg Options">
                  <option value="long-call">Long Call (Bullish)</option>
                  <option value="short-call">Short Call (Naked Bearish)</option>
                  <option value="long-put">Long Put (Bearish / Protection)</option>
                  <option value="cash-secured-put">Cash-Secured Put (Income)</option>
                </optgroup>
                <optgroup label="Vertical Spreads (Debit & Credit)">
                  <option value="bull-call-spread">Bull Call Spread (Debit +Δ)</option>
                  <option value="bear-call-spread">Bear Call Spread (Credit +Θ)</option>
                  <option value="bull-put-spread">Bull Put Spread (Credit +Θ)</option>
                  <option value="bear-put-spread">Bear Put Spread (Debit -Δ)</option>
                </optgroup>
                <optgroup label="Straddles & Strangles (Volatility)">
                  <option value="long-straddle">Long Straddle (Vol Breakout)</option>
                  <option value="short-straddle">Short Straddle (IV Crush)</option>
                  <option value="long-strangle">Long Strangle (OTM Breakout)</option>
                  <option value="short-strangle">Short Strangle (High Prob Theta)</option>
                  <option value="long-guts">Long Guts (ITM Volatility)</option>
                  <option value="short-guts">Short Guts (Deep Credit)</option>
                </optgroup>
                <optgroup label="Wings (Condors & Butterflies)">
                  <option value="iron-condor">Iron Condor (4-Leg Neutral)</option>
                  <option value="reverse-iron-condor">Reverse Iron Condor (Debit)</option>
                  <option value="iron-butterfly">Iron Butterfly (4-Leg ATM)</option>
                  <option value="reverse-iron-butterfly">Reverse Iron Butterfly</option>
                  <option value="long-call-butterfly">Long Call Butterfly (1-2-1 Pin)</option>
                  <option value="long-put-butterfly">Long Put Butterfly (1-2-1)</option>
                  <option value="broken-wing-call-butterfly">Broken Wing Call Butterfly</option>
                  <option value="broken-wing-put-butterfly">Broken Wing Put Butterfly</option>
                  <option value="long-call-condor">Long Call Condor (Plateau)</option>
                  <option value="long-put-condor">Long Put Condor (Plateau)</option>
                </optgroup>
                <optgroup label="Calendars & Diagonals (Time Spreads)">
                  <option value="call-calendar-spread">Call Calendar Spread (Time)</option>
                  <option value="put-calendar-spread">Put Calendar Spread</option>
                  <option value="poor-mans-covered-call">Poor Man's Covered Call (PMCC)</option>
                  <option value="poor-mans-covered-put">Poor Man's Covered Put (PMCP)</option>
                  <option value="double-calendar-spread">Double Calendar Spread</option>
                  <option value="double-diagonal-spread">Double Diagonal Spread</option>
                </optgroup>
                <optgroup label="Stock & Synthetic Equities">
                  <option value="covered-call">Covered Call (Stock + Short Call)</option>
                  <option value="protective-put">Protective Put (Stock + Put Hedge)</option>
                  <option value="collar">Collar (Zero-Cost Hedge)</option>
                  <option value="synthetic-long-stock">Synthetic Long Stock (+100Δ)</option>
                  <option value="synthetic-short-stock">Synthetic Short Stock (-100Δ)</option>
                  <option value="covered-put">Covered Put (Short Stock + Put)</option>
                  <option value="Long Stock (100 shs)">Long Stock (+100 shs)</option>
                  <option value="Short Stock (-100 shs)">Short Stock (-100 shs)</option>
                </optgroup>
                <optgroup label="Ratio & Asymmetric Exotics">
                  <option value="jade-lizard">Jade Lizard (No Upside Risk)</option>
                  <option value="reverse-jade-lizard">Reverse Jade Lizard (Twisted Sister)</option>
                  <option value="call-ratio-front-spread">Call Ratio Front Spread (1x2)</option>
                  <option value="put-ratio-front-spread">Put Ratio Front Spread (1x2)</option>
                  <option value="call-ratio-backspread">Call Ratio Backspread (2x1)</option>
                  <option value="put-ratio-backspread">Put Ratio Backspread (Crash Hedge)</option>
                  <option value="strap">Strap (Bullish Volatility)</option>
                  <option value="strip">Strip (Bearish Volatility)</option>
                  <option value="box-spread">Box Spread (4-Leg Arbitrage)</option>
                  <option value="risk-reversal">Risk Reversal (Directional Tunnel)</option>
                </optgroup>
                <optgroup label="Futures Strategies">
                  <option value="Long Future (1 ct)">Long Future (+1 ct)</option>
                  <option value="Short Future (-1 ct)">Short Future (-1 ct)</option>
                  <option value="Future + Protective Put">Future + Put Hedge</option>
                </optgroup>
              </select>

              {onOpenStrategyCatalog && (
                <button
                  onClick={() => {
                    playKeyClick();
                    onOpenStrategyCatalog();
                  }}
                  className="px-2 py-1 bg-[#ff9900]/20 hover:bg-[#ff9900]/30 text-[#ff9900] border border-[#ff9900]/50 rounded text-[10px] font-black transition-all flex items-center gap-1 shadow-sm"
                  title="Browse complete Institutional Options Strategy Directory with risk-reward parameters"
                >
                  <Layers className="w-3 h-3" />
                  <span>ALL STRATEGIES ({ALL_OPTIONS_STRATEGIES.length})</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Spot Quote & Navigation Buttons */}
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <div className="text-[#fff] font-extrabold text-xs">
              ${ticker.price.toFixed(2)}{' '}
              <span className={ticker.change >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}>
                {ticker.change >= 0 ? '+' : ''}{ticker.changePercent.toFixed(2)}%
              </span>
            </div>
            <div className="text-[9px] text-[#8c8c8c] flex items-center justify-end gap-2">
              <span>IV: {(ticker.currentIV * 100).toFixed(1)}% | IVR: {ticker.ivRank}%</span>
              <button
                onClick={() => {
                  playKeyClick();
                  if (onOpenExpectedMove) onOpenExpectedMove();
                }}
                className="hover:underline text-[#00d2ff] font-bold flex items-center gap-0.5"
                title="Click to view Expected Price Move & Volatility Bands"
              >
                <span>EXP:</span>
                <span className="text-[#00e676]">
                  ±${(ticker.price * (ticker.currentIV || 0.25) * Math.sqrt(Math.max(1, chain.dte) / 365)).toFixed(2)}
                </span>
              </button>
            </div>
          </div>

          <button
            onClick={() => {
              playKeyClick();
              onNavigateToChain();
            }}
            className="tos-btn"
            title="Return to Options Chain (OMON)"
          >
            CHAIN &gt;
          </button>
          <button
            onClick={() => {
              playKeyClick();
              onNavigateToValuation();
            }}
            className="tos-btn"
            title="Open Options Valuation (OVME)"
          >
            OVME &gt;
          </button>
        </div>
      </div>

      {/* ========================================================
          2. VITAL RISK & GREEKS METRICS RIBBON
      ======================================================== */}
      <div className="bg-[#181a1d] border-b border-[var(--border)] px-4 py-2 grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-3 text-[11px]">
        {/* Strategy Name */}
        <div className="flex flex-col">
          <span className="text-[9px] text-[#8c8c8c]">STRATEGY</span>
          <span className="font-extrabold text-[var(--accent)] truncate">{analysis.name}</span>
        </div>

        {/* Max Profit */}
        <div className="flex flex-col">
          <span className="text-[9px] text-[#8c8c8c]">MAX PROFIT</span>
          <span className="font-extrabold text-[var(--bull)]">
            {typeof analysis.maxProfit === 'number'
              ? `$${analysis.maxProfit.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
              : 'Unlimited (∞)'}
          </span>
        </div>

        {/* Max Loss */}
        <div className="flex flex-col">
          <span className="text-[9px] text-[#8c8c8c]">MAX LOSS</span>
          <span className="font-extrabold text-[var(--bear)]">
            {typeof analysis.maxLoss === 'number'
              ? `$${analysis.maxLoss.toLocaleString('en-US', { minimumFractionDigits: 2 })}`
              : 'Unlimited (∞)'}
          </span>
        </div>

        {/* Margin BP Requirement */}
        <div className="flex flex-col">
          <span className="text-[9px] text-[#ff9900] font-bold">MARGIN BP (REQ)</span>
          <span className="font-extrabold text-[#ff9900]">
            ${analysis.marginBuyingPower.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </span>
          <span className="text-[8px] text-[#8c8c8c] truncate" title={analysis.marginFormula}>
            {analysis.marginType.replace(/_/g, ' ')}
          </span>
        </div>

        {/* Return on Margin (RoM) */}
        <div className="flex flex-col">
          <span className="text-[9px] text-[#00e676] font-bold">RETURN ON MARGIN</span>
          <span className="font-extrabold text-[#00e676]">
            {analysis.returnOnMargin}
          </span>
          <span className="text-[8px] text-[#8c8c8c]">RoM / Capital</span>
        </div>

        {/* Breakevens */}
        <div className="flex flex-col">
          <span className="text-[9px] text-[#8c8c8c]">BREAKEVEN(S)</span>
          <span className="font-bold text-[#fff]">
            {analysis.breakEvens.length > 0
              ? analysis.breakEvens.map((b) => `$${b.toFixed(2)}`).join(' | ')
              : 'None / Delta Stock'}
          </span>
        </div>

        {/* Probability of Profit */}
        <div className="flex flex-col">
          <span className="text-[9px] text-[#8c8c8c]">PROB OF PROFIT (POP)</span>
          <span className="font-extrabold text-[#00d2ff]">{analysis.probOfProfit}%</span>
        </div>

        {/* Net Delta */}
        <div className="flex flex-col">
          <span className="text-[9px] text-[#8c8c8c]">NET DELTA (Δ)</span>
          <span className={`font-bold ${analysis.totalDelta >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
            {analysis.totalDelta >= 0 ? '+' : ''}{analysis.totalDelta.toFixed(2)}
          </span>
        </div>

        {/* Net Theta */}
        <div className="flex flex-col">
          <span className="text-[9px] text-[#8c8c8c]">NET THETA (Θ)</span>
          <span className={`font-bold ${analysis.totalTheta >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
            {analysis.totalTheta >= 0 ? '+' : ''}${analysis.totalTheta.toFixed(2)}/day
          </span>
        </div>

        {/* Net Vega */}
        <div className="flex flex-col">
          <span className="text-[9px] text-[#8c8c8c]">NET VEGA (V)</span>
          <span className="font-bold text-[#ffd600]">
            ${analysis.totalVega.toFixed(2)}/1% IV
          </span>
        </div>
      </div>

      {/* ========================================================
          3. MAIN RISK PROFILE CANVAS VIEWPORT ("BIGGER PICTURE")
      ======================================================== */}
      <div className="flex-1 flex flex-col overflow-y-auto">
        <div className="relative bg-[#0d0f12] border-b border-[var(--border)] p-3">
          {/* Canvas Sub-Header with Controls & Toggles */}
          <div className="flex flex-wrap items-center justify-between gap-3 mb-2 px-1 text-[10px]">
            <div className="flex items-center gap-3">
              <span className="font-bold text-[var(--accent)] flex items-center gap-1">
                <Activity className="w-3.5 h-3.5" />
                <span>EXPANSIVE PAYOFF CANVAS</span>
              </span>

              {/* Underlying Position Indicator */}
              {activeLegs.some((l) => l.type === 'stock' || l.type === 'future') && (
                <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#10b981]/20 border border-[#10b981]/40 text-[#34d399] font-bold text-[9.5px]">
                  <span>UNDERLYING LOADED:</span>
                  <span className="text-white font-mono">
                    {[
                      ...activeLegs
                        .filter((l) => l.type === 'stock')
                        .map((l) => `${l.action === 'buy' ? '+' : '-'}${l.contracts} shs Stock`),
                      ...activeLegs
                        .filter((l) => l.type === 'future')
                        .map((l) => `${l.action === 'buy' ? '+' : '-'}${l.contracts} ct Future (${l.multiplier || 50}x)`),
                    ].join(' · ')}
                  </span>
                </div>
              )}

              {/* Legend Badges */}
              <div className="flex items-center gap-2 text-[10px]">
                <label className="flex items-center gap-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showExpirationCurve}
                    onChange={(e) => setShowExpirationCurve(e.target.checked)}
                    className="accent-[var(--bull)]"
                  />
                  <span className="text-[var(--bull)] font-bold">Expiration Line (T)</span>
                </label>

                <label className="flex items-center gap-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showTodayCurve}
                    onChange={(e) => setShowTodayCurve(e.target.checked)}
                    className="accent-[#00d2ff]"
                  />
                  <span className="text-[#00d2ff] font-bold">Today Curve (T+0)</span>
                </label>

                {timeElapsedDays > 0 && (
                  <label className="flex items-center gap-1 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={showSimulatedCurve}
                      onChange={(e) => setShowSimulatedCurve(e.target.checked)}
                      className="accent-[var(--accent)]"
                    />
                    <span className="text-[var(--accent)] font-bold">Simulated Curve (T+{timeElapsedDays}d)</span>
                  </label>
                )}

                <label className="flex items-center gap-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={showSigmaBands}
                    onChange={(e) => setShowSigmaBands(e.target.checked)}
                    className="accent-[#8c8c8c]"
                  />
                  <span className="text-[#8c8c8c]">±1σ / ±2σ Bands</span>
                </label>

                {/* Skew Baseline Overlay Checkbox */}
                {isSkewModelEnabled && (
                  <label className="flex items-center gap-1 cursor-pointer" title="Overlay classical unskewed flat-vol Black-Scholes curve to observe skew alpha">
                    <input
                      type="checkbox"
                      checked={showUnskewedOverlay}
                      onChange={(e) => setShowUnskewedOverlay(e.target.checked)}
                      className="accent-[#f59e0b]"
                    />
                    <span className="text-[#f59e0b] font-bold flex items-center gap-1">
                      <span className="inline-block w-2.5 h-0.5 border-t border-dashed border-[#f59e0b]" />
                      <span>Flat-Vol Baseline Overlay</span>
                    </span>
                  </label>
                )}

                {/* Skew Active Pill Badge */}
                {isSkewModelEnabled && (
                  <button
                    onClick={() => {
                      playKeyClick();
                      setIsSkewPanelExpanded(!isSkewPanelExpanded);
                    }}
                    className="px-1.5 py-0.5 rounded bg-purple-900/30 text-purple-300 border border-purple-500/40 hover:bg-purple-900/50 text-[9px] font-bold flex items-center gap-1 transition-all"
                    title="Click to configure Volatility Skew Engine parameters"
                  >
                    <Sliders className="w-2.5 h-2.5 text-[#c084fc]" />
                    <span>SKEW: {SKEW_MODEL_PRESETS[selectedSkewPresetKey]?.name.split(' (')[0] || 'Custom Skew'}</span>
                  </button>
                )}
              </div>
            </div>

            {/* Canvas Actions & Expand Toggle */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  playKeyClick();
                  setIsBiggerPictureExpanded(!isBiggerPictureExpanded);
                }}
                className={`tos-btn flex items-center gap-1.5 ${
                  isBiggerPictureExpanded ? 'bg-[var(--accent)] text-black font-extrabold border-[var(--accent)]' : ''
                }`}
                title="Toggle expansive full-size bigger picture canvas"
              >
                {isBiggerPictureExpanded ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
                <span>{isBiggerPictureExpanded ? 'EXPANDED CANVAS' : 'BIGGER PICTURE'}</span>
              </button>

              {/* Quick Reset */}
              {(timeElapsedDays !== 0 || ivShiftPercent !== 0 || priceShockPct !== 0) && (
                <button
                  onClick={() => {
                    playKeyClick();
                    setTimeElapsedDays(0);
                    setIvShiftPercent(0);
                    setPriceShockPct(0);
                  }}
                  className="tos-btn text-[var(--accent)] flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>RESET SHOCKS</span>
                </button>
              )}
            </div>
          </div>

          {/* SVG Canvas */}
          <div className="w-full overflow-x-auto no-scrollbar">
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className={`w-full h-auto min-w-[760px] ${
                isBiggerPictureExpanded ? 'max-h-[580px]' : 'max-h-[420px]'
              } bg-[#121417] rounded border border-[#2d3339] shadow-inner`}
              onMouseMove={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const mouseX = e.clientX - rect.left;
                const ratio = (mouseX - padding.left) / graphWidth;
                const price = minPrice + ratio * (maxPrice - minPrice);
                // Find closest point
                let closest = payoffPoints[0];
                let minD = Infinity;
                payoffPoints.forEach((pt) => {
                  const d = Math.abs(pt.price - price);
                  if (d < minD) {
                    minD = d;
                    closest = pt;
                  }
                });
                if (closest && mouseX >= padding.left && mouseX <= svgWidth - padding.right) {
                  setHoveredPoint(closest);
                }
              }}
              onMouseLeave={() => setHoveredPoint(null)}
            >
              {/* Grids and Axes */}
              <defs>
                <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#43a047" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#43a047" stopOpacity="0.0" />
                </linearGradient>
                <linearGradient id="lossGrad" x1="0" y1="1" x2="0" y2="0">
                  <stop offset="0%" stopColor="#e53935" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#e53935" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Standard Deviation Expected Move Bands */}
              {showSigmaBands && (
                <>
                  {/* 2-Sigma Band (95.4% probability) */}
                  <rect
                    x={scaleX(lower2Sigma)}
                    y={padding.top}
                    width={Math.max(2, scaleX(upper2Sigma) - scaleX(lower2Sigma))}
                    height={graphHeight}
                    fill="#3c3f41"
                    opacity="0.18"
                  />
                  {/* 1-Sigma Band (68.2% probability) */}
                  <rect
                    x={scaleX(lower1Sigma)}
                    y={padding.top}
                    width={Math.max(2, scaleX(upper1Sigma) - scaleX(lower1Sigma))}
                    height={graphHeight}
                    fill="#ff9900"
                    opacity="0.08"
                  />
                  {/* Sigma labels */}
                  <text
                    x={scaleX(lower1Sigma)}
                    y={padding.top + 14}
                    fill="#8c8c8c"
                    fontSize="9"
                    textAnchor="middle"
                  >
                    -1σ (${lower1Sigma.toFixed(1)})
                  </text>
                  <text
                    x={scaleX(upper1Sigma)}
                    y={padding.top + 14}
                    fill="#8c8c8c"
                    fontSize="9"
                    textAnchor="middle"
                  >
                    +1σ (${upper1Sigma.toFixed(1)})
                  </text>
                </>
              )}

              {/* Horizontal P&L Gridlines */}
              {[-1000, -500, -250, 0, 250, 500, 1000].map((level) => {
                if (level < minPnl || level > maxPnl) return null;
                const y = scaleY(level);
                const isZero = level === 0;
                return (
                  <g key={level}>
                    <line
                      x1={padding.left}
                      y1={y}
                      x2={svgWidth - padding.right}
                      y2={y}
                      stroke={isZero ? '#8c8c8c' : '#26292d'}
                      strokeWidth={isZero ? 1.5 : 1}
                      strokeDasharray={isZero ? '4 3' : undefined}
                    />
                    <text
                      x={padding.left - 8}
                      y={y + 3}
                      fill={isZero ? '#fff' : '#64748b'}
                      fontSize="9"
                      textAnchor="end"
                      fontWeight={isZero ? 'bold' : 'normal'}
                    >
                      {level >= 0 ? `+$${level}` : `-$${Math.abs(level)}`}
                    </text>
                  </g>
                );
              })}

              {/* Vertical Stock Price Gridlines */}
              {[0.85, 0.9, 0.95, 1.0, 1.05, 1.1, 1.15].map((multiplier) => {
                const p = Number((currentPrice * multiplier).toFixed(1));
                if (p < minPrice || p > maxPrice) return null;
                const x = scaleX(p);
                return (
                  <g key={p}>
                    <line
                      x1={x}
                      y1={padding.top}
                      x2={x}
                      y2={svgHeight - padding.bottom}
                      stroke="#22252a"
                      strokeWidth="1"
                    />
                    <text
                      x={x}
                      y={svgHeight - padding.bottom + 15}
                      fill="#8c8c8c"
                      fontSize="9"
                      textAnchor="middle"
                    >
                      ${p}
                    </text>
                  </g>
                );
              })}

              {/* Shading Above / Below Zero for Expiration */}
              {showExpirationCurve && (
                <path d={profitAreaPath} fill="url(#profitGrad)" pointerEvents="none" />
              )}

              {/* Expiration Curve (T) */}
              {showExpirationCurve && (
                <path
                  d={expirationPath}
                  fill="none"
                  stroke="#43a047"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              )}

              {/* Today Curve (T+0) */}
              {showTodayCurve && (
                <path
                  d={todayPath}
                  fill="none"
                  stroke="#00d2ff"
                  strokeWidth="2"
                  strokeDasharray={timeElapsedDays > 0 ? '5 3' : undefined}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              )}

              {/* Unskewed Baseline Reference Curves (Flat-Vol / Zero-Skew Overlay) */}
              {showUnskewedOverlay && isSkewModelEnabled && (
                <>
                  {showExpirationCurve && unskewedExpirationPath && (
                    <path
                      d={unskewedExpirationPath}
                      fill="none"
                      stroke="#84cc16"
                      strokeWidth="1.5"
                      strokeDasharray="4 4"
                      strokeOpacity="0.75"
                    />
                  )}
                  {showTodayCurve && unskewedTodayPath && (
                    <path
                      d={unskewedTodayPath}
                      fill="none"
                      stroke="#f59e0b"
                      strokeWidth="1.5"
                      strokeDasharray="4 4"
                      strokeOpacity="0.75"
                    />
                  )}
                </>
              )}

              {/* Breakeven Marker Lines */}
              {showBreakevens &&
                breakEvenLines.map((be) => (
                  <g key={be.price}>
                    <line
                      x1={be.x}
                      y1={padding.top}
                      x2={be.x}
                      y2={svgHeight - padding.bottom}
                      stroke="#ffd600"
                      strokeWidth="1.5"
                      strokeDasharray="3 3"
                    />
                    <rect
                      x={be.x - 26}
                      y={svgHeight - padding.bottom + 4}
                      width="52"
                      height="15"
                      fill="#ffd600"
                      rx="2"
                    />
                    <text
                      x={be.x}
                      y={svgHeight - padding.bottom + 15}
                      fill="#000"
                      fontSize="9"
                      textAnchor="middle"
                      fontWeight="bold"
                    >
                      BE ${be.price}
                    </text>
                  </g>
                ))}

              {/* Current Spot Price Vertical Benchmark */}
              <line
                x1={spotX}
                y1={padding.top}
                x2={spotX}
                y2={svgHeight - padding.bottom}
                stroke="#fff"
                strokeWidth="1.5"
                strokeDasharray="4 2"
              />
              <rect
                x={spotX - 30}
                y={padding.top - 18}
                width="60"
                height="15"
                fill="#fff"
                rx="2"
              />
              <text
                x={spotX}
                y={padding.top - 7}
                fill="#000"
                fontSize="9"
                textAnchor="middle"
                fontWeight="900"
              >
                SPOT ${currentPrice.toFixed(2)}
              </text>

              {/* Interactive Hover Inspection Ruler */}
              {hoveredPoint && (
                <g>
                  <line
                    x1={scaleX(hoveredPoint.price)}
                    y1={padding.top}
                    x2={scaleX(hoveredPoint.price)}
                    y2={svgHeight - padding.bottom}
                    stroke="#ff9900"
                    strokeWidth="1"
                    strokeDasharray="2 2"
                  />
                  {/* Point circles */}
                  <circle
                    cx={scaleX(hoveredPoint.price)}
                    cy={scaleY(hoveredPoint.pnlExpiration)}
                    r="4"
                    fill="#43a047"
                    stroke="#fff"
                    strokeWidth="1.5"
                  />
                  <circle
                    cx={scaleX(hoveredPoint.price)}
                    cy={scaleY(hoveredPoint.pnlT0)}
                    r="4"
                    fill="#00d2ff"
                    stroke="#fff"
                    strokeWidth="1.5"
                  />
                </g>
              )}
            </svg>
          </div>

          {/* Floating Hover Inspector HUD */}
          {hoveredPoint && (
            <div className="absolute top-14 right-6 bg-[#1a1e22]/95 border border-[var(--accent)] p-2.5 rounded shadow-xl pointer-events-none text-[11px] flex flex-col gap-1 min-w-[210px]">
              <div className="flex justify-between border-b border-[#3c3c3c] pb-1 font-bold">
                <span className="text-[var(--accent)]">TARGET SPOT:</span>
                <span className="text-white">
                  ${hoveredPoint.price.toFixed(2)} (
                  {(((hoveredPoint.price - currentPrice) / currentPrice) * 100).toFixed(1)}%)
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[var(--bull)]">P&L At Expiration:</span>
                <span className={`font-bold ${hoveredPoint.pnlExpiration >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
                  {hoveredPoint.pnlExpiration >= 0 ? '+' : ''}${hoveredPoint.pnlExpiration.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#00d2ff]">P&L Today:</span>
                <span className={`font-bold ${hoveredPoint.pnlT0 >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
                  {hoveredPoint.pnlT0 >= 0 ? '+' : ''}${hoveredPoint.pnlT0.toFixed(2)}
                </span>
              </div>

              {/* Skew Alpha Breakdown */}
              {isSkewModelEnabled && unskewedPayoffPoints && (
                <div className="border-t border-[#3c3c3c] pt-1 flex flex-col gap-0.5 text-[9px]">
                  {(() => {
                    const closestUnskewed =
                      unskewedPayoffPoints.find((u) => Math.abs(u.price - hoveredPoint.price) < 0.5) ||
                      unskewedPayoffPoints[0];
                    const diffT0 = closestUnskewed ? hoveredPoint.pnlT0 - closestUnskewed.pnlT0 : 0;
                    return (
                      <>
                        <div className="flex justify-between text-[#8c8c8c]">
                          <span>Flat-Vol Base (T+0):</span>
                          <span className="text-[#f59e0b] font-mono font-bold">
                            {closestUnskewed ? `${closestUnskewed.pnlT0 >= 0 ? '+' : ''}$${closestUnskewed.pnlT0.toFixed(2)}` : '—'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-[#c084fc] font-bold">Skew Alpha (Δ):</span>
                          <span className={`font-mono font-bold ${diffT0 >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
                            {diffT0 >= 0 ? '+' : ''}${diffT0.toFixed(2)}
                          </span>
                        </div>
                      </>
                    );
                  })()}
                </div>
              )}
              <div className="grid grid-cols-2 gap-1 border-t border-[#3c3c3c] pt-1 text-[9px] text-[#8c8c8c]">
                <div>Δ: <strong className="text-white">{hoveredPoint.delta.toFixed(2)}</strong></div>
                <div>Γ: <strong className="text-white">{hoveredPoint.gamma.toFixed(3)}</strong></div>
                <div>Θ: <strong className="text-white">${hoveredPoint.theta.toFixed(2)}</strong></div>
                <div>V: <strong className="text-white">${hoveredPoint.vega.toFixed(2)}</strong></div>
              </div>
            </div>
          )}

          {/* Bigger Picture Executive Strategy & Capital Profile Strip */}
          <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-[10px]">
            <div className="bg-[#121417] border border-[#2d3339] p-2 rounded flex flex-col justify-between">
              <span className="text-[#8c8c8c] text-[9px]">RETURN ON RISK (RoR)</span>
              <span className="text-[var(--accent)] font-extrabold text-xs">
                {typeof analysis.maxProfit === 'number' && typeof analysis.maxLoss === 'number' && analysis.maxLoss > 0
                  ? `${((analysis.maxProfit / analysis.maxLoss) * 100).toFixed(1)}%`
                  : 'Open-Ended'}
              </span>
            </div>

            <div className="bg-[#121417] border border-[#2d3339] p-2 rounded flex flex-col justify-between">
              <span className="text-[#8c8c8c] text-[9px]">BREAKEVEN CORRIDOR</span>
              <span className="text-white font-bold text-xs truncate">
                {analysis.breakEvens.length >= 2
                  ? `$${analysis.breakEvens[0].toFixed(2)} - $${analysis.breakEvens[analysis.breakEvens.length - 1].toFixed(2)}`
                  : analysis.breakEvens.length === 1
                  ? `$${analysis.breakEvens[0].toFixed(2)}`
                  : 'N/A'}
              </span>
            </div>

            <div className="bg-[#121417] border border-[#2d3339] p-2 rounded flex flex-col justify-between">
              <span className="text-[#8c8c8c] text-[9px]">DOWNSIDE BUFFER</span>
              <span className="text-[#00d2ff] font-bold text-xs">
                {analysis.breakEvens.length > 0 && analysis.breakEvens[0] < currentPrice
                  ? `-${(((currentPrice - analysis.breakEvens[0]) / currentPrice) * 100).toFixed(1)}% cushion`
                  : 'At Market'}
              </span>
            </div>

            <div className="bg-[#121417] border border-[#2d3339] p-2 rounded flex flex-col justify-between">
              <span className="text-[#8c8c8c] text-[9px]">PROBABILITY OF PROFIT</span>
              <span className="text-[var(--bull)] font-extrabold text-xs">
                {analysis.probOfProfit}% POP
              </span>
            </div>

            <div className="bg-[#121417] border border-[#2d3339] p-2 rounded flex flex-col justify-between">
              <span className="text-[#8c8c8c] text-[9px]">DAILY THETA CASH FLOW</span>
              <span className={`font-bold text-xs ${analysis.totalTheta >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
                {analysis.totalTheta >= 0 ? '+' : ''}${analysis.totalTheta.toFixed(2)} / day
              </span>
            </div>

            <div className="bg-[#121417] border border-[#2d3339] p-2 rounded flex flex-col justify-between">
              <span className="text-[#8c8c8c] text-[9px]">1-SIGMA CONFIDENCE (68.2%)</span>
              <span className="text-[#ffd600] font-bold text-xs truncate">
                ${lower1Sigma.toFixed(1)} - ${upper1Sigma.toFixed(1)}
              </span>
            </div>
          </div>
        </div>

        {/* ========================================================
            4. INTERACTIVE "WHAT-IF" SIMULATION CONTROLS DECK
        ======================================================== */}
        <div className="bg-[#181a1d] border-b border-[var(--border)] p-3 grid grid-cols-1 md:grid-cols-3 gap-4 text-[11px]">
          {/* Slider 1: Days to Expiration Decay */}
          <div className="flex flex-col gap-1.5 bg-[#121417] p-2.5 rounded border border-[#2d3339]">
            <div className="flex justify-between items-center">
              <span className="text-[#8c8c8c] font-bold flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-[var(--accent)]" />
                <span>TIME DECAY (DAYS PASSED):</span>
              </span>
              <span className="text-[var(--accent)] font-extrabold">+{timeElapsedDays} Days</span>
            </div>
            <input
              type="range"
              min="0"
              max={Math.max(1, maxDte)}
              value={timeElapsedDays}
              onChange={(e) => setTimeElapsedDays(parseInt(e.target.value, 10))}
              className="accent-[var(--accent)] w-full cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#8c8c8c]">
              <button onClick={() => setTimeElapsedDays(0)} className="hover:text-white">Today (T+0)</button>
              <button onClick={() => setTimeElapsedDays(Math.min(maxDte, 7))} className="hover:text-white">+7d</button>
              <button onClick={() => setTimeElapsedDays(Math.min(maxDte, 14))} className="hover:text-white">+14d</button>
              <button onClick={() => setTimeElapsedDays(Math.min(maxDte, 30))} className="hover:text-white">+30d</button>
              <button onClick={() => setTimeElapsedDays(maxDte)} className="hover:text-white">Expiry (T)</button>
            </div>
          </div>

          {/* Slider 2: Implied Volatility Shock */}
          <div className="flex flex-col gap-1.5 bg-[#121417] p-2.5 rounded border border-[#2d3339]">
            <div className="flex justify-between items-center">
              <span className="text-[#8c8c8c] font-bold flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-[#00d2ff]" />
                <span>IMPLIED VOL SHIFT (IV CRUSH / SPIKE):</span>
              </span>
              <span className={`font-extrabold ${ivShiftPercent >= 0 ? 'text-[#00d2ff]' : 'text-[var(--bear)]'}`}>
                {ivShiftPercent >= 0 ? '+' : ''}{ivShiftPercent}% IV
              </span>
            </div>
            <input
              type="range"
              min="-25"
              max="25"
              value={ivShiftPercent}
              onChange={(e) => setIvShiftPercent(parseInt(e.target.value, 10))}
              className="accent-[#00d2ff] w-full cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-[#8c8c8c]">
              <button onClick={() => setIvShiftPercent(-15)} className="hover:text-white">-15% (Earnings Crush)</button>
              <button onClick={() => setIvShiftPercent(0)} className="hover:text-white">0% (Unchanged)</button>
              <button onClick={() => setIvShiftPercent(15)} className="hover:text-white">+15% (Vol Spike)</button>
            </div>
          </div>

          {/* Stepper 3: Underlying Spot Step Buttons */}
          <div className="flex flex-col gap-1.5 bg-[#121417] p-2.5 rounded border border-[#2d3339]">
            <div className="flex justify-between items-center">
              <span className="text-[#8c8c8c] font-bold flex items-center gap-1">
                <Crosshair className="w-3.5 h-3.5 text-[var(--bull)]" />
                <span>SPOT PRICE STEP SIMULATOR:</span>
              </span>
              <span className="text-white font-extrabold">
                ${(currentPrice * (1 + priceShockPct / 100)).toFixed(2)} ({priceShockPct >= 0 ? '+' : ''}{priceShockPct}%)
              </span>
            </div>
            <div className="grid grid-cols-5 gap-1 pt-1">
              {[-10, -5, 0, 5, 10].map((step) => (
                <button
                  key={step}
                  onClick={() => {
                    playKeyClick();
                    setPriceShockPct(step);
                  }}
                  className={`tos-btn py-1 text-[9px] ${
                    priceShockPct === step ? 'bg-[#ff9900] text-black font-extrabold' : ''
                  }`}
                >
                  {step === 0 ? 'SPOT' : `${step >= 0 ? '+' : ''}${step}%`}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* ========================================================
            4B. VOLATILITY SKEW ENGINE (CALENDARS & DOUBLE DIAGONALS)
        ======================================================== */}
        <div className="bg-[#121519] border-b border-[var(--border)] p-3 flex flex-col gap-2.5">
          {/* Header Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#242b33] pb-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="font-extrabold text-[#c084fc] flex items-center gap-1.5 text-xs">
                <Sliders className="w-4 h-4 text-[#a855f7]" />
                <span>VOLATILITY SKEW ENGINE (CALENDAR &amp; DOUBLE DIAGONAL PROFILES)</span>
              </span>

              {/* Strategy Detection Badges */}
              {calendarDiagonalDetails?.isDoubleDiagonal ? (
                <span className="px-2 py-0.5 rounded bg-purple-900/40 text-purple-300 border border-purple-500/50 font-black text-[9px] flex items-center gap-1 animate-pulse">
                  <span>★</span>
                  <span>DOUBLE DIAGONAL DETECTED: 4 LEGS / 2 EXPIRATIONS / ASYMMETRIC WINGS</span>
                </span>
              ) : calendarDiagonalDetails?.isDoubleCalendar ? (
                <span className="px-2 py-0.5 rounded bg-blue-900/40 text-blue-300 border border-blue-500/50 font-black text-[9px] flex items-center gap-1">
                  <span>★</span>
                  <span>DOUBLE CALENDAR DETECTED: 4 LEGS / 2 EXPIRATIONS</span>
                </span>
              ) : calendarDiagonalDetails?.isCalendar ? (
                <span className="px-2 py-0.5 rounded bg-cyan-900/40 text-cyan-300 border border-cyan-500/50 font-black text-[9px] flex items-center gap-1">
                  <span>★</span>
                  <span>TIME CALENDAR SPREAD: HORIZONTAL SKEW ACTIVE</span>
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded bg-[#1e2228] text-[#8c8c8c] border border-[#333d48] font-bold text-[9px]">
                  MULTI-EXP VOLATILITY SURFACE CALIBRATOR
                </span>
              )}

              <span className="text-[10px] text-[#8c8c8c] hidden xl:inline">
                Model term structure contango/backwardation &amp; smile skew across strikes
              </span>
            </div>

            {/* Actions & Toggles */}
            <div className="flex items-center gap-2">
              {/* Master Skew Model Toggle */}
              <button
                onClick={() => {
                  playKeyClick();
                  setIsSkewModelEnabled(!isSkewModelEnabled);
                }}
                className={`px-2.5 py-1 rounded text-[10px] font-extrabold border transition-all flex items-center gap-1.5 ${
                  isSkewModelEnabled
                    ? 'bg-[#10b981]/20 text-[#34d399] border-[#10b981]/50 shadow-sm'
                    : 'bg-[#222830] text-[#8c8c8c] border-[#333d48] hover:text-white'
                }`}
                title="Toggle Skew Modeling on payoff curves"
              >
                <Zap className={`w-3 h-3 ${isSkewModelEnabled ? 'text-[#34d399]' : 'text-[#8c8c8c]'}`} />
                <span>{isSkewModelEnabled ? 'SKEW MODEL: ACTIVE' : 'SKEW MODEL: DISABLED (FLAT BSM)'}</span>
              </button>

              {/* Reset to Contango Button */}
              <button
                onClick={() => {
                  playKeyClick();
                  setSelectedSkewPresetKey('normalContango');
                  setSkewModel({ ...SKEW_MODEL_PRESETS.normalContango.config });
                  setIsSkewModelEnabled(true);
                }}
                className="tos-btn py-1 px-2 text-[9.5px] flex items-center gap-1 text-[#8c8c8c] hover:text-white"
                title="Reset to default Contango baseline (+3.5% Back IV)"
              >
                <RotateCcw className="w-3 h-3" />
                <span>RESET</span>
              </button>

              {/* Expand / Collapse Button */}
              <button
                onClick={() => {
                  playKeyClick();
                  setIsSkewPanelExpanded(!isSkewPanelExpanded);
                }}
                className="tos-btn py-1 px-2 text-[9.5px] flex items-center gap-1"
                title="Expand or collapse Volatility Skew controls"
              >
                {isSkewPanelExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                <span>{isSkewPanelExpanded ? 'COLLAPSE' : 'EXPAND SKEW DECK'}</span>
              </button>
            </div>
          </div>

          {/* Expanded Skew Modeler Controls */}
          {isSkewPanelExpanded && (
            <div className="flex flex-col gap-3">
              {/* Presets Quick Strip */}
              <div className="flex flex-wrap items-center gap-1.5 bg-[#0a0c0e] p-1.5 rounded border border-[#222830]">
                <span className="text-[9.5px] font-bold text-[#8c8c8c] flex items-center gap-1 mr-1">
                  <Sparkles className="w-3 h-3 text-[#ff9900]" />
                  <span>SKEW REGIME PRESETS:</span>
                </span>
                {Object.entries(SKEW_MODEL_PRESETS).map(([key, preset]) => {
                  const isSelected = selectedSkewPresetKey === key && isSkewModelEnabled;
                  return (
                    <button
                      key={key}
                      onClick={() => {
                        playKeyClick();
                        setSelectedSkewPresetKey(key);
                        setSkewModel({ ...preset.config });
                        setIsSkewModelEnabled(true);
                      }}
                      className={`px-2 py-1 rounded text-[9.5px] font-bold transition-all border ${
                        isSelected
                          ? 'bg-[#a855f7] text-white border-[#c084fc] shadow-sm font-extrabold'
                          : 'bg-[#161a1f] text-[#aaa] border-[#2a3038] hover:bg-[#20262e] hover:text-white'
                      }`}
                      title={preset.description}
                    >
                      {preset.name}
                    </button>
                  );
                })}
              </div>

              {/* 6 Parameter Sliders & Inputs Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-[11px]">
                {/* 1. Term Structure Skew */}
                <div className="bg-[#16191e] border border-[#2b333c] p-2.5 rounded flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-[#38bdf8]" />
                      <span>TERM SKEW (FRONT VS BACK):</span>
                    </span>
                    <span
                      className={`font-mono font-extrabold px-1.5 py-0.2 rounded text-[10.5px] ${
                        skewModel.calendarTermSkew > 0
                          ? 'bg-sky-950/60 text-sky-400 border border-sky-600/40'
                          : skewModel.calendarTermSkew < 0
                          ? 'bg-rose-950/60 text-rose-400 border border-rose-600/40'
                          : 'bg-zinc-800 text-zinc-300'
                      }`}
                    >
                      {skewModel.calendarTermSkew > 0 ? '+' : ''}{(skewModel.calendarTermSkew * 100).toFixed(1)}%{' '}
                      {skewModel.calendarTermSkew > 0 ? 'Contango' : skewModel.calendarTermSkew < 0 ? 'Inversion' : 'Flat'}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="-35"
                    max="35"
                    step="0.5"
                    value={Math.round(skewModel.calendarTermSkew * 1000) / 10}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) / 100;
                      setSkewModel((prev) => ({ ...prev, calendarTermSkew: val }));
                      setSelectedSkewPresetKey('custom');
                    }}
                    className="accent-[#38bdf8] w-full cursor-pointer"
                  />
                  <div className="flex justify-between text-[8.5px] text-[#8c8c8c]">
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, calendarTermSkew: -0.18 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">-18% Invert</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, calendarTermSkew: -0.05 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">-5% Backw</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, calendarTermSkew: 0 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">0% Flat</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, calendarTermSkew: 0.035 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">+3.5% Norm</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, calendarTermSkew: 0.08 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">+8% Steep</button>
                  </div>
                  <div className="text-[8.5px] text-[#788596] leading-tight">
                    Horizontal spread: Back-month IV minus front-month IV. Crucial for calendar spread peak tent value.
                  </div>
                </div>

                {/* 2. Strike Skew Slope */}
                <div className="bg-[#16191e] border border-[#2b333c] p-2.5 rounded flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold flex items-center gap-1">
                      <TrendingDown className="w-3.5 h-3.5 text-[#c084fc]" />
                      <span>STRIKE SKEW SLOPE (dIV/dM):</span>
                    </span>
                    <span
                      className={`font-mono font-extrabold px-1.5 py-0.2 rounded text-[10.5px] ${
                        skewModel.strikeSkewSlope < 0
                          ? 'bg-purple-950/60 text-purple-400 border border-purple-600/40'
                          : 'bg-zinc-800 text-zinc-300'
                      }`}
                    >
                      {(skewModel.strikeSkewSlope * 100).toFixed(1)}% Slope
                    </span>
                  </div>
                  <input
                    type="range"
                    min="-45"
                    max="10"
                    step="0.5"
                    value={Math.round(skewModel.strikeSkewSlope * 1000) / 10}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) / 100;
                      setSkewModel((prev) => ({ ...prev, strikeSkewSlope: val }));
                      setSelectedSkewPresetKey('custom');
                    }}
                    className="accent-[#c084fc] w-full cursor-pointer"
                  />
                  <div className="flex justify-between text-[8.5px] text-[#8c8c8c]">
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, strikeSkewSlope: -0.32 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">-32% Crash</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, strikeSkewSlope: -0.20 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">-20% DblDiag</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, strikeSkewSlope: -0.16 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">-16% Equity</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, strikeSkewSlope: 0 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">0% Flat</button>
                  </div>
                  <div className="text-[8.5px] text-[#788596] leading-tight">
                    Vertical put skew: Negative slope elevates lower-strike put IV vs higher-strike call IV.
                  </div>
                </div>

                {/* 3. Smile Curvature */}
                <div className="bg-[#16191e] border border-[#2b333c] p-2.5 rounded flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold flex items-center gap-1">
                      <Activity className="w-3.5 h-3.5 text-[#fbbf24]" />
                      <span>SMILE CURVATURE (CONVEXITY):</span>
                    </span>
                    <span className="font-mono font-extrabold px-1.5 py-0.2 rounded text-[10.5px] bg-amber-950/60 text-amber-400 border border-amber-600/40">
                      +{(skewModel.smileCurvature * 100).toFixed(1)}% Curvature
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="25"
                    step="0.5"
                    value={Math.round(skewModel.smileCurvature * 1000) / 10}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) / 100;
                      setSkewModel((prev) => ({ ...prev, smileCurvature: val }));
                      setSelectedSkewPresetKey('custom');
                    }}
                    className="accent-[#fbbf24] w-full cursor-pointer"
                  />
                  <div className="flex justify-between text-[8.5px] text-[#8c8c8c]">
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, smileCurvature: 0 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">0% Linear</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, smileCurvature: 0.06 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">6% Moderate</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, smileCurvature: 0.10 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">10% Pronounced</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, smileCurvature: 0.18 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">18% Deep</button>
                  </div>
                  <div className="text-[8.5px] text-[#788596] leading-tight">
                    Quadratic smile convexity: Boosts both far wings (OTM puts and OTM calls) for double diagonal outer strikes.
                  </div>
                </div>

                {/* 4. Post-Front Vol Shock */}
                <div className="bg-[#16191e] border border-[#2b333c] p-2.5 rounded flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold flex items-center gap-1">
                      <Zap className="w-3.5 h-3.5 text-[#f43f5e]" />
                      <span>POST-FRONT VOL SHOCK (@ T_FRONT):</span>
                    </span>
                    <span
                      className={`font-mono font-extrabold px-1.5 py-0.2 rounded text-[10.5px] ${
                        skewModel.backMonthVolShock < 0
                          ? 'bg-rose-950/60 text-rose-400 border border-rose-600/40'
                          : skewModel.backMonthVolShock > 0
                          ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-600/40'
                          : 'bg-zinc-800 text-zinc-300'
                      }`}
                    >
                      {skewModel.backMonthVolShock > 0 ? '+' : ''}{(skewModel.backMonthVolShock * 100).toFixed(1)}% Vol Shock
                    </span>
                  </div>
                  <input
                    type="range"
                    min="-25"
                    max="15"
                    step="0.5"
                    value={Math.round(skewModel.backMonthVolShock * 1000) / 10}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) / 100;
                      setSkewModel((prev) => ({ ...prev, backMonthVolShock: val }));
                      setSelectedSkewPresetKey('custom');
                    }}
                    className="accent-[#f43f5e] w-full cursor-pointer"
                  />
                  <div className="flex justify-between text-[8.5px] text-[#8c8c8c]">
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, backMonthVolShock: -0.12 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">-12% Crush</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, backMonthVolShock: -0.04 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">-4% Decay</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, backMonthVolShock: 0 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">0% Unch</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, backMonthVolShock: 0.05 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">+5% Spike</button>
                  </div>
                  <div className="text-[8.5px] text-[#788596] leading-tight">
                    Vol shift applied to back-month options when front month expires. Critical for post-earnings calendar drops.
                  </div>
                </div>

                {/* 5. Double Diagonal Wing Bias */}
                <div className="bg-[#16191e] border border-[#2b333c] p-2.5 rounded flex flex-col gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold flex items-center gap-1">
                      <Layers className="w-3.5 h-3.5 text-[#a855f7]" />
                      <span>DOUBLE DIAGONAL PUT WING BIAS:</span>
                    </span>
                    <span
                      className={`font-mono font-extrabold px-1.5 py-0.2 rounded text-[10.5px] ${
                        (skewModel.doubleDiagonalWingBias || 0) < 0
                          ? 'bg-purple-950/60 text-purple-400 border border-purple-600/40'
                          : 'bg-zinc-800 text-zinc-300'
                      }`}
                    >
                      {((skewModel.doubleDiagonalWingBias || 0) * 100).toFixed(1)}% Put Bias
                    </span>
                  </div>
                  <input
                    type="range"
                    min="-20"
                    max="10"
                    step="0.5"
                    value={Math.round((skewModel.doubleDiagonalWingBias || 0) * 1000) / 10}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value) / 100;
                      setSkewModel((prev) => ({ ...prev, doubleDiagonalWingBias: val }));
                      setSelectedSkewPresetKey('custom');
                    }}
                    className="accent-[#a855f7] w-full cursor-pointer"
                  />
                  <div className="flex justify-between text-[8.5px] text-[#8c8c8c]">
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, doubleDiagonalWingBias: -0.12 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">-12% Heavy</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, doubleDiagonalWingBias: -0.06 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">-6% Moderate</button>
                    <button onClick={() => { setSkewModel((prev) => ({ ...prev, doubleDiagonalWingBias: 0 })); setSelectedSkewPresetKey('custom'); }} className="hover:text-white">0% Symmetric</button>
                  </div>
                  <div className="text-[8.5px] text-[#788596] leading-tight">
                    Asymmetric steepener for the put diagonal wing vs call diagonal wing in 4-leg double diagonals.
                  </div>
                </div>

                {/* 6. Skew Dynamics Model */}
                <div className="bg-[#16191e] border border-[#2b333c] p-2.5 rounded flex flex-col justify-between gap-2">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-bold flex items-center gap-1">
                      <Crosshair className="w-3.5 h-3.5 text-[#34d399]" />
                      <span>SKEW DYNAMICS MODEL:</span>
                    </span>
                    <span className="font-mono font-extrabold text-[10px] text-[#34d399]">
                      {skewModel.skewDynamics === 'stickyStrike' ? 'Sticky Strike' : 'Sticky Moneyness'}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-1.5 pt-1">
                    <button
                      onClick={() => {
                        playKeyClick();
                        setSkewModel((prev) => ({ ...prev, skewDynamics: 'stickyMoneyness' }));
                        setSelectedSkewPresetKey('custom');
                      }}
                      className={`px-2 py-1.5 rounded text-[9.5px] font-bold border transition-all text-center ${
                        skewModel.skewDynamics !== 'stickyStrike'
                          ? 'bg-[#10b981]/20 text-[#34d399] border-[#10b981]/60 font-extrabold shadow-sm'
                          : 'bg-[#111] text-[#888] border-[#2a3038] hover:text-white'
                      }`}
                      title="Volatility surface moves with spot price (Floating Delta Skew, Standard for Equities & Index options)"
                    >
                      Sticky Moneyness (Floating)
                    </button>
                    <button
                      onClick={() => {
                        playKeyClick();
                        setSkewModel((prev) => ({ ...prev, skewDynamics: 'stickyStrike' }));
                        setSelectedSkewPresetKey('custom');
                      }}
                      className={`px-2 py-1.5 rounded text-[9.5px] font-bold border transition-all text-center ${
                        skewModel.skewDynamics === 'stickyStrike'
                          ? 'bg-[#10b981]/20 text-[#34d399] border-[#10b981]/60 font-extrabold shadow-sm'
                          : 'bg-[#111] text-[#888] border-[#2a3038] hover:text-white'
                      }`}
                      title="Implied volatility remains fixed per strike price regardless of spot moves (Anchored Strike Skew)"
                    >
                      Sticky Strike (Fixed)
                    </button>
                  </div>
                  <div className="text-[8.5px] text-[#788596] leading-tight">
                    Institutional convention: Floating moneyness dynamically recalculates IV smile as stock moves along x-axis.
                  </div>
                </div>
              </div>

              {/* Live Skew Mathematical Diagnostics Strip */}
              <div className="bg-[#0b0e11] border border-[#202730] p-2.5 rounded grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-[10px]">
                <div className="flex flex-col">
                  <span className="text-[8.5px] text-[#8c8c8c]">FRONT ATM BASE IV</span>
                  <span className="font-mono font-bold text-white">{(ticker.currentIV * 100).toFixed(1)}%</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[8.5px] text-[#8c8c8c]">BACK ATM MODELED IV</span>
                  <span className="font-mono font-bold text-[#38bdf8]">
                    {((ticker.currentIV + skewModel.calendarTermSkew) * 100).toFixed(1)}%
                    <span className="text-[8.5px] ml-1 opacity-80">
                      ({skewModel.calendarTermSkew >= 0 ? '+' : ''}{(skewModel.calendarTermSkew * 100).toFixed(1)}%)
                    </span>
                  </span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[8.5px] text-[#8c8c8c]">PUT WING (-5% OTM) IV</span>
                  <span className="font-mono font-bold text-[#c084fc]">
                    {((ticker.currentIV + (skewModel.strikeSkewSlope + (skewModel.doubleDiagonalWingBias || 0)) * -0.05 + skewModel.smileCurvature * 0.0025) * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[8.5px] text-[#8c8c8c]">CALL WING (+5% OTM) IV</span>
                  <span className="font-mono font-bold text-[#fbbf24]">
                    {((ticker.currentIV + skewModel.strikeSkewSlope * 0.05 + skewModel.smileCurvature * 0.0025) * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[8.5px] text-[#8c8c8c]">POST-FRONT VOL SHOCK</span>
                  <span className={`font-mono font-bold ${skewModel.backMonthVolShock <= 0 ? 'text-[#f87171]' : 'text-[#34d399]'}`}>
                    {skewModel.backMonthVolShock >= 0 ? '+' : ''}{(skewModel.backMonthVolShock * 100).toFixed(1)}%
                  </span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[8.5px] text-[#8c8c8c]">SKEW ALPHA AT SPOT</span>
                  <span className="font-mono font-bold text-[#34d399]">
                    {(() => {
                      if (!unskewedPayoffPoints || !payoffPoints.length) return '—';
                      const spotPt = payoffPoints.find((p) => Math.abs(p.price - currentPrice) < 1.0) || payoffPoints[0];
                      const unskewedPt = unskewedPayoffPoints.find((p) => Math.abs(p.price - currentPrice) < 1.0) || unskewedPayoffPoints[0];
                      const diff = spotPt && unskewedPt ? spotPt.pnlT0 - unskewedPt.pnlT0 : 0;
                      return `${diff >= 0 ? '+' : ''}$${diff.toFixed(2)}`;
                    })()}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ========================================================
            4C. MARGIN REQUIREMENTS & BUYING POWER (BP) ENGINE
        ======================================================== */}
        <div className="bg-[#101317] border-b border-[var(--border)] p-3 flex flex-col gap-2.5">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#222830] pb-2">
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-[#ff9900] flex items-center gap-1.5 text-xs">
                <Shield className="w-4 h-4 text-[#ff9900]" />
                <span>MARGIN REQUIREMENTS &amp; BUYING POWER (BP) ENGINE</span>
              </span>
              <span className="px-1.5 py-0.2 rounded text-[8.5px] font-extrabold border bg-[#ff9900]/20 text-[#ff9900] border-[#ff9900]/50 font-mono">
                FINRA RULE 4210 / REG-T
              </span>
              <span className="text-[10px] text-[#8c8c8c] hidden md:inline">
                Institutional collateral calculation &amp; risk/leverage metrics
              </span>
            </div>
            <div className="flex items-center gap-2 text-[10px] font-mono">
              <span className="text-[#8c8c8c]">ACCOUNT TYPE:</span>
              <span className="px-1.5 py-0.5 rounded bg-[#1e2638] text-white font-bold border border-[#334155]">
                US REG-T MARGIN (LEVEL 4)
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2.5 text-xs font-mono">
            {/* Initial Margin BP */}
            <div className="bg-[#161a20] border border-[#2a303a] rounded p-2.5 flex flex-col">
              <span className="text-[9px] text-[#ff9900] font-bold">INITIAL MARGIN BP</span>
              <span className="text-base font-black text-[#ff9900] mt-0.5">
                ${analysis.marginBuyingPower.toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-[8.5px] text-[#8c8c8c] mt-0.5">
                Capital earmarked / frozen
              </span>
            </div>

            {/* Maintenance Margin */}
            <div className="bg-[#161a20] border border-[#2a303a] rounded p-2.5 flex flex-col">
              <span className="text-[9px] text-[#8c8c8c]">MAINTENANCE MARGIN</span>
              <span className="text-base font-bold text-white mt-0.5">
                ${(analysis.marginBuyingPower * 0.75).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </span>
              <span className="text-[8.5px] text-[#8c8c8c] mt-0.5">
                75% FINRA house threshold
              </span>
            </div>

            {/* Return on Margin */}
            <div className="bg-[#161a20] border border-[#2a303a] rounded p-2.5 flex flex-col">
              <span className="text-[9px] text-[#00e676] font-bold">RETURN ON MARGIN (RoM)</span>
              <span className="text-base font-black text-[#00e676] mt-0.5">
                {analysis.returnOnMargin}
              </span>
              <span className="text-[8.5px] text-[#8c8c8c] mt-0.5">
                Max Profit / Margin BP
              </span>
            </div>

            {/* Margin Rule & Classification */}
            <div className="bg-[#161a20] border border-[#2a303a] rounded p-2.5 flex flex-col">
              <span className="text-[9px] text-[#8c8c8c]">MARGIN RULE APPLIED</span>
              <span className="text-xs font-bold text-[#38bdf8] mt-1 truncate" title={analysis.marginFormula}>
                {analysis.marginType.replace(/_/g, ' ')}
              </span>
              <span className="text-[8px] text-[#8c8c8c] mt-0.5 truncate" title={analysis.marginFormula}>
                {analysis.marginFormula}
              </span>
            </div>

            {/* Risk / Reward Ratio */}
            <div className="bg-[#161a20] border border-[#2a303a] rounded p-2.5 flex flex-col">
              <span className="text-[9px] text-[#8c8c8c]">RISK / REWARD RATIO</span>
              <span className="text-base font-bold text-white mt-0.5">
                {analysis.riskRewardRatio}
              </span>
              <span className="text-[8.5px] text-[#8c8c8c] mt-0.5">
                Strategy asymmetry
              </span>
            </div>

            {/* Free BP After Trade */}
            <div className="bg-[#161a20] border border-[#2a303a] rounded p-2.5 flex flex-col">
              <span className="text-[9px] text-[#8c8c8c]">SIMULATED COLLATERAL STATUS</span>
              <span className="text-xs font-bold text-[#10b981] mt-1 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5 text-[#10b981]" />
                <span>MARGIN APPROVED</span>
              </span>
              <span className="text-[8.5px] text-[#8c8c8c] mt-0.5">
                Complies with FINRA 4210
              </span>
            </div>
          </div>
        </div>

        {/* ========================================================
            5. PORTFOLIO STOCKS & FUTURES INSPECTOR TRAY
        ======================================================== */}
        {(sourceMode === 'portfolio' || isPortfolioTrayExpanded) && (
          <div className="p-3 bg-[#15181c] border-b border-[var(--border)] flex flex-col gap-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#2a3038] pb-2">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-[#00d2ff] flex items-center gap-1.5 text-xs">
                  <Layers className="w-4 h-4" />
                  <span>PORTFOLIO STOCKS &amp; FUTURES POSITION BLOTTER</span>
                </span>
                <span
                  className={`px-1.5 py-0.2 rounded text-[8.5px] font-extrabold border ${
                    sourceMode === 'portfolio'
                      ? 'bg-[#00d2ff]/20 text-[#00d2ff] border-[#00d2ff]/50'
                      : 'bg-[#222] text-[#8c8c8c] border-[#444]'
                  }`}
                >
                  {sourceMode === 'portfolio' ? 'ACTIVE PAYOFF ENGINE' : 'INSPECTION TRAY'}
                </span>
                <span className="text-[10px] text-[#8c8c8c] hidden md:inline">
                  Model underlying stock/futures delta &amp; risk curve
                </span>
              </div>

              {/* Category & Scope Filters */}
              <div className="flex flex-wrap items-center gap-1.5">
                <div className="flex items-center bg-[#0d0f12] p-0.5 rounded border border-[#2a3038] text-[9.5px]">
                  {(['ALL', 'STOCKS', 'FUTURES', 'OPTIONS'] as const).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => {
                        playKeyClick();
                        setPortfolioCategoryFilter(cat);
                      }}
                      className={`px-2 py-0.5 rounded font-bold transition-all ${
                        portfolioCategoryFilter === cat
                          ? cat === 'STOCKS'
                            ? 'bg-[#10b981] text-black font-extrabold'
                            : cat === 'FUTURES'
                            ? 'bg-[#ffd600] text-black font-extrabold'
                            : cat === 'OPTIONS'
                            ? 'bg-[#00d2ff] text-black font-extrabold'
                            : 'bg-white text-black font-extrabold'
                          : 'text-[#8c8c8c] hover:text-white'
                      }`}
                    >
                      {cat} (
                      {cat === 'STOCKS'
                        ? portfolioStats.stocksCount
                        : cat === 'FUTURES'
                        ? portfolioStats.futuresCount
                        : cat === 'OPTIONS'
                        ? portfolioStats.optionsCount
                        : portfolioStats.total}
                      )
                    </button>
                  ))}
                </div>

                <div className="flex items-center bg-[#0d0f12] p-0.5 rounded border border-[#2a3038] text-[9.5px]">
                  <button
                    onClick={() => {
                      playKeyClick();
                      setPortfolioTickerFilter('ALL_TICKERS');
                    }}
                    className={`px-2 py-0.5 rounded font-bold transition-all ${
                      portfolioTickerFilter === 'ALL_TICKERS'
                        ? 'bg-white text-black font-bold'
                        : 'text-[#8c8c8c] hover:text-white'
                    }`}
                  >
                    ALL TICKERS
                  </button>
                  <button
                    onClick={() => {
                      playKeyClick();
                      setPortfolioTickerFilter('CURRENT');
                    }}
                    className={`px-2 py-0.5 rounded font-bold transition-all ${
                      portfolioTickerFilter === 'CURRENT'
                        ? 'bg-[var(--accent)] text-black font-bold'
                        : 'text-[#8c8c8c] hover:text-white'
                    }`}
                  >
                    {ticker.symbol} ONLY
                  </button>
                </div>

                {onOpenStockTrade && (
                  <button
                    onClick={() => {
                      playKeyClick();
                      onOpenStockTrade();
                    }}
                    className="px-2 py-0.5 bg-[#10b981]/20 hover:bg-[#10b981] hover:text-black text-[#34d399] font-bold rounded border border-[#10b981]/50 text-[9.5px] transition-all"
                  >
                    + Trade Ticket
                  </button>
                )}

                {onSeedPositions && (
                  <button
                    onClick={() => {
                      playKeyClick();
                      onSeedPositions();
                    }}
                    className="px-2 py-0.5 bg-[#252525] hover:bg-[#333] text-[#aaa] hover:text-white font-bold rounded border border-[#444] text-[9.5px] transition-all"
                    title="Seed sample stocks & futures (NVDA, AAPL, /ES, /CL)"
                  >
                    Seed Sample
                  </button>
                )}

                <button
                  onClick={() => {
                    playKeyClick();
                    setIsPortfolioTrayExpanded(!isPortfolioTrayExpanded);
                  }}
                  className="px-1.5 py-0.5 bg-[#1e2329] hover:bg-[#283038] text-[#8c8c8c] rounded text-[9.5px]"
                  title="Collapse tray"
                >
                  {isPortfolioTrayExpanded ? '▲' : '▼'}
                </button>
              </div>
            </div>

            {/* Financial Aggregates Bar */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
              <div className="bg-[#0f1216] border border-[#262c33] rounded p-2 flex flex-col">
                <div className="flex items-center justify-between text-[10px] text-[#8c8c8c]">
                  <span className="flex items-center gap-1 text-[#10b981] font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#10b981]" />
                    STOCKS EXPOSURE
                  </span>
                  <span>{portfolioStats.stocksCount} pos</span>
                </div>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="font-extrabold text-white font-mono text-[13px]">
                    ${portfolioAggregates.totalStockValue.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span className={`text-[10px] font-bold font-mono ${portfolioAggregates.totalStockPnL >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
                    {portfolioAggregates.totalStockPnL >= 0 ? '+' : ''}${portfolioAggregates.totalStockPnL.toFixed(2)}
                  </span>
                </div>
                <span className="text-[9.5px] text-[#8c8c8c] mt-0.5">
                  Total Delta: <strong className="text-[#ffd600]">{portfolioAggregates.totalStockDelta >= 0 ? '+' : ''}{portfolioAggregates.totalStockDelta.toFixed(0)} Δ</strong>
                </span>
              </div>

              <div className="bg-[#0f1216] border border-[#262c33] rounded p-2 flex flex-col">
                <div className="flex items-center justify-between text-[10px] text-[#8c8c8c]">
                  <span className="flex items-center gap-1 text-[#ffd600] font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#ffd600]" />
                    FUTURES NOTIONAL
                  </span>
                  <span>{portfolioStats.futuresCount} pos</span>
                </div>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="font-extrabold text-white font-mono text-[13px]">
                    ${portfolioAggregates.totalFuturesNotional.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span className={`text-[10px] font-bold font-mono ${portfolioAggregates.totalFuturesPnL >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
                    {portfolioAggregates.totalFuturesPnL >= 0 ? '+' : ''}${portfolioAggregates.totalFuturesPnL.toFixed(2)}
                  </span>
                </div>
                <span className="text-[9.5px] text-[#8c8c8c] mt-0.5">
                  Total Delta: <strong className="text-[#ffd600]">{portfolioAggregates.totalFuturesDelta >= 0 ? '+' : ''}{portfolioAggregates.totalFuturesDelta.toFixed(0)} Δ</strong>
                </span>
              </div>

              <div className="bg-[#0f1216] border border-[#262c33] rounded p-2 flex flex-col">
                <div className="flex items-center justify-between text-[10px] text-[#8c8c8c]">
                  <span className="flex items-center gap-1 text-[#00d2ff] font-bold">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#00d2ff]" />
                    OPTIONS VALUE
                  </span>
                  <span>{portfolioStats.optionsCount} pos</span>
                </div>
                <div className="flex items-baseline justify-between mt-1">
                  <span className="font-extrabold text-white font-mono text-[13px]">
                    ${portfolioAggregates.totalOptionsMark.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span className={`text-[10px] font-bold font-mono ${portfolioAggregates.totalOptionsPnL >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
                    {portfolioAggregates.totalOptionsPnL >= 0 ? '+' : ''}${portfolioAggregates.totalOptionsPnL.toFixed(2)}
                  </span>
                </div>
                <span className="text-[9.5px] text-[#8c8c8c] mt-0.5">
                  Options Premium &amp; Greeks
                </span>
              </div>

              <div className="bg-[#0f1216] border border-[#262c33] rounded p-2 flex flex-col">
                <div className="flex items-center justify-between text-[10px] text-[#8c8c8c]">
                  <span className="font-bold text-white">NET UNREALIZED P&amp;L</span>
                  <span>Total Portfolio</span>
                </div>
                <div className="flex items-baseline justify-between mt-1">
                  <span className={`font-extrabold font-mono text-[14px] ${portfolioAggregates.netPnL >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
                    {portfolioAggregates.netPnL >= 0 ? '+' : ''}${portfolioAggregates.netPnL.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                  <span className={`text-[10px] font-extrabold px-1.5 py-0.2 rounded border ${
                    portfolioAggregates.netPnL >= 0
                      ? 'bg-[#10b981]/20 text-[#34d399] border-[#10b981]/40'
                      : 'bg-[#ef4444]/20 text-[#f87171] border-[#ef4444]/40'
                  }`}>
                    {portfolioAggregates.netPnL >= 0 ? 'PROFIT' : 'DRAWDOWN'}
                  </span>
                </div>
                <span className="text-[9.5px] text-[#8c8c8c] mt-0.5">
                  Real-time Mark-to-Market
                </span>
              </div>
            </div>

            {/* Positions Table / Empty Helper */}
            {visiblePortfolioPositions.length === 0 ? (
              <div className="bg-[#101215] p-4 rounded border border-[#262b32] flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded bg-[#ff9900]/10 border border-[#ff9900]/30 text-[#ff9900]">
                    <Info className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-white block">
                      No open {portfolioCategoryFilter !== 'ALL' ? portfolioCategoryFilter.toLowerCase() : ''} positions for{' '}
                      {portfolioTickerFilter === 'CURRENT' ? ticker.symbol : 'portfolio'}.
                    </span>
                    <span className="text-[10px] text-[#8c8c8c]">
                      Stage a sample stock or futures position to immediately model underlying delta &amp; risk curve!
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleAddStockLeg('buy', 100)}
                    className="px-2.5 py-1 bg-[#10b981]/20 hover:bg-[#10b981] hover:text-black text-[#34d399] font-bold rounded border border-[#10b981]/50 text-[10px] transition-all"
                  >
                    + Stage 100 Shares Stock ({ticker.symbol})
                  </button>
                  <button
                    onClick={() => handleAddFuturesLeg('buy', 1)}
                    className="px-2.5 py-1 bg-[#ffd600]/20 hover:bg-[#ffd600] hover:text-black text-[#ffd600] font-bold rounded border border-[#ffd600]/50 text-[10px] transition-all"
                  >
                    + Stage 1 Future Contract
                  </button>
                  {onSeedPositions && (
                    <button
                      onClick={() => {
                        playKeyClick();
                        onSeedPositions();
                      }}
                      className="px-2.5 py-1 bg-[#ff9900]/20 hover:bg-[#ff9900] hover:text-black text-[#ff9900] font-bold rounded border border-[#ff9900]/50 text-[10px] transition-all"
                    >
                      + Seed Sample Positions
                    </button>
                  )}
                  {onOpenStockTrade && (
                    <button
                      onClick={() => {
                        playKeyClick();
                        onOpenStockTrade();
                      }}
                      className="px-2.5 py-1 bg-[#252525] hover:bg-[#333] text-white rounded border border-[#444] text-[10px] transition-all"
                    >
                      Trade Stock &gt;
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-[11px] border-collapse">
                  <thead>
                    <tr className="border-b border-[#2a3038] text-[#8c8c8c] text-[10px] uppercase bg-[#101215]">
                      <th className="py-1.5 px-2">MODEL</th>
                      <th className="py-1.5 px-2">ASSET</th>
                      <th className="py-1.5 px-2">STRATEGY / POSITION</th>
                      <th className="py-1.5 px-2">CONTRACTS / SHARES</th>
                      <th className="py-1.5 px-2 text-right">ENTRY COST</th>
                      <th className="py-1.5 px-2 text-right">CURRENT MARK</th>
                      <th className="py-1.5 px-2 text-right">UNREALIZED P&amp;L</th>
                      <th className="py-1.5 px-2 text-right">DELTA (Δ)</th>
                      <th className="py-1.5 px-2 text-right">ACTIONS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1e2329] bg-[#121417]">
                    {visiblePortfolioPositions.map((pos) => {
                      const isEnabled = enabledPositionIds[pos.id] !== false;
                      const isStock = pos.legs.some((l) => l.type === 'stock') || pos.strategyName.toLowerCase().includes('stock');
                      const isFuture = pos.legs.some((l) => l.type === 'future') || pos.strategyName.toLowerCase().includes('future') || pos.ticker.startsWith('/');
                      
                      const assetBadge = isStock ? (
                        <span className="px-1.5 py-0.2 rounded bg-[#10b981]/20 text-[#34d399] font-bold text-[8.5px] border border-[#10b981]/40">
                          STOCK
                        </span>
                      ) : isFuture ? (
                        <span className="px-1.5 py-0.2 rounded bg-[#ffd600]/20 text-[#ffd600] font-bold text-[8.5px] border border-[#ffd600]/40">
                          /FUTURE
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.2 rounded bg-[#00d2ff]/20 text-[#00d2ff] font-bold text-[8.5px] border border-[#00d2ff]/40">
                          OPTION
                        </span>
                      );

                      const deltaVal = pos.legs.reduce((acc, l) => {
                        const mult = l.multiplier !== undefined ? l.multiplier : (l.type === 'stock' ? 1 : 100);
                        const s = l.action === 'buy' ? 1 : -1;
                        if (l.type === 'stock' || l.type === 'future') return acc + s * mult * l.contracts;
                        return acc;
                      }, 0);

                      return (
                        <tr
                          key={pos.id}
                          className={`hover:bg-[#1a1f26] transition-colors ${
                            !isEnabled ? 'opacity-40' : ''
                          }`}
                        >
                          <td className="py-1.5 px-2">
                            <input
                              type="checkbox"
                              checked={isEnabled}
                              onChange={() => togglePositionCheckbox(pos.id)}
                              className="cursor-pointer accent-[#00d2ff]"
                              title="Include/exclude this position from Risk Profile payoff curve"
                            />
                          </td>
                          <td className="py-1.5 px-2">
                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() => {
                                  playKeyClick();
                                  if (onSelectTicker) onSelectTicker(pos.ticker);
                                }}
                                className="font-bold text-white font-mono hover:text-[#00d2ff] hover:underline"
                                title={`Switch to ${pos.ticker}`}
                              >
                                {pos.ticker}
                              </button>
                              {assetBadge}
                            </div>
                          </td>
                          <td className="py-1.5 px-2 font-bold text-white">{pos.strategyName}</td>
                          <td className="py-1.5 px-2 text-[#aaa]">
                            {isStock
                              ? `${pos.contracts} shares`
                              : isFuture
                              ? `${pos.contracts} contracts (${pos.legs[0]?.multiplier || 50}x)`
                              : `${pos.contracts} contracts (${pos.legs.length} legs)`}
                          </td>
                          <td className="py-1.5 px-2 text-right font-mono text-[#8c8c8c]">
                            ${Math.abs(pos.entryCost).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-1.5 px-2 text-right font-mono text-white font-bold">
                            ${Math.abs(pos.currentMark).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-1.5 px-2 text-right font-mono font-bold">
                            <span className={pos.unrealizedPnL >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}>
                              {pos.unrealizedPnL >= 0 ? '+' : ''}${pos.unrealizedPnL.toFixed(2)} ({pos.unrealizedPnL >= 0 ? '+' : ''}{pos.unrealizedPnLPercent.toFixed(1)}%)
                            </span>
                          </td>
                          <td className="py-1.5 px-2 text-right font-mono font-bold text-[#ffd600]">
                            {deltaVal !== 0 ? `${deltaVal >= 0 ? '+' : ''}${deltaVal.toFixed(0)} Δ` : '—'}
                          </td>
                          <td className="py-1.5 px-2 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                onClick={() => handleModelPositionInRiskProfile(pos)}
                                className="px-2 py-0.5 rounded bg-[#00d2ff]/20 hover:bg-[#00d2ff] hover:text-black text-[#00d2ff] font-bold text-[9px] border border-[#00d2ff]/40 transition-all"
                                title="Plot this exact position's payoff curve and risk bands"
                              >
                                MODEL
                              </button>
                              <button
                                onClick={() => handleStagePositionLegsInBuilder(pos)}
                                className="px-1.5 py-0.5 rounded bg-[#ffd600]/20 hover:bg-[#ffd600] hover:text-black text-[#ffd600] font-bold text-[9px] border border-[#ffd600]/40 transition-all"
                                title="Copy legs to Strategy Builder to model options hedges"
                              >
                                + BUILDER
                              </button>
                              {onOpenStockTrade && (isStock || isFuture) && (
                                <button
                                  onClick={() => {
                                    playKeyClick();
                                    if (onSelectTicker && pos.ticker !== ticker.symbol) {
                                      onSelectTicker(pos.ticker);
                                    }
                                    onOpenStockTrade();
                                  }}
                                  className="px-1.5 py-0.5 rounded bg-[#252525] hover:bg-[#333] text-white text-[9px] border border-[#444] transition-all"
                                  title="Open trading order ticket"
                                >
                                  TRADE
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* ========================================================
            6. LEGS BREAKDOWN & WHAT-IF CHECKLIST
        ======================================================== */}
        <div className="p-3 grid grid-cols-1 xl:grid-cols-3 gap-3">
          {/* Active Simulated Trades Table with Individual IV and Theoretical Price modeling */}
          <div className="xl:col-span-2 bg-[#14171a] p-3 rounded border border-[var(--border)] flex flex-col gap-2">
            <div className="flex flex-wrap justify-between items-center border-b border-[#2d3339] pb-2 gap-2">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-[var(--accent)] flex items-center gap-1.5 text-xs">
                  <Layers className="w-4 h-4" />
                  <span>POSITIONS &amp; SIMULATED TRADES ({allSourceLegs.length})</span>
                </span>
                {Object.keys(individualIvOverrides).length > 0 && (
                  <span className="px-1.5 py-0.2 rounded text-[8.5px] font-extrabold border bg-[#a855f7]/20 text-[#c084fc] border-[#a855f7]/40 flex items-center gap-1">
                    <Sparkles className="w-2.5 h-2.5" />
                    <span>{Object.keys(individualIvOverrides).length} LEGS WITH CUSTOM IV</span>
                  </span>
                )}
              </div>

              {/* Quick Simulated Volatility & Underlying Controls */}
              <div className="flex flex-wrap items-center gap-1.5 text-[9px]">
                {/* Volatility Modeling Quick Shocks */}
                <div className="flex items-center bg-[#0d0f12] p-0.5 rounded border border-[#262c33] gap-1">
                  <span className="text-[#8c8c8c] px-1 font-bold">Simulate IV:</span>
                  <button
                    onClick={handleApplyEarningsCrush}
                    title="Simulate immediate Post-Earnings Volatility Crush (-25% relative IV on option legs)"
                    className="px-1.5 py-0.5 bg-[#ef4444]/20 hover:bg-[#ef4444] hover:text-white text-[#f87171] font-bold rounded border border-[#ef4444]/40 flex items-center gap-1 transition-all"
                  >
                    <span>Crush (-25%)</span>
                  </button>
                  <button
                    onClick={handleApplyVolExpansion}
                    title="Simulate Event / Earnings Implied Volatility Expansion (+25% relative IV on option legs)"
                    className="px-1.5 py-0.5 bg-[#10b981]/20 hover:bg-[#10b981] hover:text-black text-[#34d399] font-bold rounded border border-[#10b981]/40 flex items-center gap-1 transition-all"
                  >
                    <span>Expand (+25%)</span>
                  </button>
                  {Object.keys(individualIvOverrides).length > 0 && (
                    <button
                      onClick={handleResetAllIndividualIvs}
                      title="Reset all individual leg IV overrides back to base market chain IV"
                      className="px-1.5 py-0.5 bg-[#a855f7]/20 hover:bg-[#a855f7] hover:text-white text-[#c084fc] font-bold rounded border border-[#a855f7]/40 flex items-center gap-1 transition-all"
                    >
                      <RotateCcw className="w-2.5 h-2.5" />
                      <span>Reset IVs</span>
                    </button>
                  )}
                </div>

                {/* Quick Underlying Stock & Futures Controls */}
                <div className="flex items-center gap-1">
                  <span className="text-[#8c8c8c]">Underlying:</span>
                  <button
                    onClick={() => handleAddStockLeg('buy', 100)}
                    title="Add 100 Shares Long Stock to Risk Profile"
                    className="px-1.5 py-0.5 bg-[#10b981]/20 hover:bg-[#10b981] hover:text-black text-[#34d399] font-bold rounded border border-[#10b981]/40"
                  >
                    +100 Shs
                  </button>
                  <button
                    onClick={() => handleAddStockLeg('sell', 100)}
                    title="Add 100 Shares Short Stock to Risk Profile"
                    className="px-1.5 py-0.5 bg-[#ef4444]/20 hover:bg-[#ef4444] hover:text-white text-[#f87171] font-bold rounded border border-[#ef4444]/40"
                  >
                    -100 Shs
                  </button>
                  <button
                    onClick={() => handleAddFuturesLeg('buy', 1)}
                    title="Add 1 Contract Long Futures to Risk Profile"
                    className="px-1.5 py-0.5 bg-[#ffd600]/20 hover:bg-[#ffd600] hover:text-black text-[#ffd600] font-bold rounded border border-[#ffd600]/40"
                  >
                    +1 Fut
                  </button>
                  <button
                    onClick={() => handleAddFuturesLeg('sell', 1)}
                    title="Add 1 Contract Short Futures to Risk Profile"
                    className="px-1.5 py-0.5 bg-[#f97316]/20 hover:bg-[#f97316] hover:text-black text-[#fb923c] font-bold rounded border border-[#f97316]/40"
                  >
                    -1 Fut
                  </button>
                  {allSourceLegs.length > 0 && (
                    <button
                      onClick={onClearLegs}
                      title="Clear All Staged Legs"
                      className="px-1.5 py-0.5 bg-[#252525] hover:bg-[#333] text-[#aaa] rounded border border-[#444]"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
            </div>

            {allSourceLegs.length === 0 ? (
              <div className="p-6 text-center text-[#8c8c8c] flex flex-col items-center gap-2">
                <span>No active legs loaded in Risk Profile.</span>
                <div className="flex items-center gap-2 mt-1">
                  <button
                    onClick={() => handleAddStockLeg('buy', 100)}
                    className="px-2.5 py-1 bg-[#10b981]/20 text-[#34d399] border border-[#10b981]/40 rounded font-bold text-[10px]"
                  >
                    + Add 100 Shares Stock
                  </button>
                  <button
                    onClick={() => handleAddFuturesLeg('buy', 1)}
                    className="px-2.5 py-1 bg-[#ffd600]/20 text-[#ffd600] border border-[#ffd600]/40 rounded font-bold text-[10px]"
                  >
                    + Add 1 Futures Contract
                  </button>
                  <button
                    onClick={() => {
                      setSelectedPreset('Covered Call');
                      setSourceMode('preset');
                    }}
                    className="px-2.5 py-1 bg-[#ff9900]/20 text-[#ff9900] border border-[#ff9900]/40 rounded font-bold text-[10px]"
                  >
                    Load Covered Call Preset
                  </button>
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto no-scrollbar">
                <table className="w-full text-left text-[11px] whitespace-nowrap">
                  <thead>
                    <tr className="border-b border-[#262a30] text-[#8c8c8c] text-[10px] uppercase">
                      <th className="py-1 px-2">INC</th>
                      <th className="py-1 px-2">TYPE</th>
                      <th className="py-1 px-2">ACTION</th>
                      <th className="py-1 px-2">STRIKE / BASIS</th>
                      <th className="py-1 px-2">EXPIRY</th>
                      <th className="py-1 px-2 text-right">MARK</th>
                      <th className="py-1 px-2 text-center text-[#c084fc]">INDIVIDUAL IV (%)</th>
                      <th className="py-1 px-2 text-right text-white">THEO PRICE</th>
                      <th className="py-1 px-2 text-right">QTY / SIZE</th>
                      <th className="py-1 px-2 text-right text-[#ff9900]">MARGIN BP</th>
                      <th className="py-1 px-2 text-right">DELTA (Δ)</th>
                      <th className="py-1 px-2 text-right">VEGA (ν)</th>
                      <th className="py-1 px-2 text-right">THETA (Θ)</th>
                      <th className="py-1 px-2 text-center">ACTION</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1e2227]">
                    {allSourceLegs.map((leg) => {
                      const isEnabled = enabledLegIds[leg.id] !== false;
                      const isStock = leg.type === 'stock';
                      const isFuture = leg.type === 'future';
                      const isOption = leg.type === 'call' || leg.type === 'put';

                      const baseIv = leg.iv;
                      const hasOverride = individualIvOverrides[leg.id] !== undefined;
                      const effectiveIv = hasOverride ? individualIvOverrides[leg.id] : baseIv;
                      const ivDiff = effectiveIv - baseIv;

                      // Compute theoretical values for this leg under simulated time, individual IV, and volatility skew
                      const theoData = isOption
                        ? calculateTheoreticalLeg(leg, currentPrice, timeElapsedDays, effectiveIv, undefined, activeSkewModel, frontDte)
                        : {
                            theoreticalPrice: currentPrice,
                            unrealizedPnL: (leg.action === 'buy' ? 1 : -1) * (currentPrice - leg.premium) * leg.contracts * (leg.multiplier || 1),
                            effectiveIV: 0,
                            delta: (leg.action === 'buy' ? 1 : -1) * leg.contracts * (leg.multiplier || (isFuture ? 50 : 1)),
                            gamma: 0,
                            theta: 0,
                            vega: 0,
                            rho: 0,
                            valueAtFrontExp: undefined as number | undefined,
                            strikeSkewAdj: undefined as number | undefined,
                            termSkewAdj: undefined as number | undefined,
                          };

                      const typeBadge = isStock ? (
                        <span className="px-1.5 py-0.2 rounded bg-[#10b981]/20 text-[#34d399] font-bold text-[8.5px] border border-[#10b981]/40">
                          STOCK
                        </span>
                      ) : isFuture ? (
                        <span className="px-1.5 py-0.2 rounded bg-[#ffd600]/20 text-[#ffd600] font-bold text-[8.5px] border border-[#ffd600]/40">
                          /FUTURE
                        </span>
                      ) : (
                        <span className="font-bold uppercase text-white">{leg.type}</span>
                      );

                      return (
                        <tr
                          key={leg.id}
                          className={`hover:bg-[#1a1e22] transition-colors ${
                            !isEnabled ? 'opacity-40 bg-[#0d0f12]' : ''
                          }`}
                        >
                          {/* Include Checkbox */}
                          <td className="py-1.5 px-2">
                            <input
                              type="checkbox"
                              checked={isEnabled}
                              onChange={() => toggleLegCheckbox(leg.id)}
                              className="cursor-pointer accent-[var(--accent)]"
                              title={isEnabled ? 'Included in simulated payoff profile' : 'Excluded from simulated payoff profile'}
                            />
                          </td>

                          {/* Type */}
                          <td className="py-1.5 px-2">{typeBadge}</td>

                          {/* Action */}
                          <td className="py-1.5 px-2 font-bold uppercase">
                            <span
                              className={leg.action === 'buy' ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}
                            >
                              {leg.action}
                            </span>
                          </td>

                          {/* Strike / Basis */}
                          <td className="py-1.5 px-2 font-extrabold text-[#ffd600]">
                            {isStock
                              ? `Basis: $${leg.premium.toFixed(2)}`
                              : isFuture
                              ? `Basis: $${leg.premium.toFixed(2)}`
                              : `$${leg.strike.toFixed(2)}`}
                          </td>

                          {/* Expiration */}
                          <td className="py-1.5 px-2 text-[#8c8c8c]">
                            {leg.expiration}
                            {isOption && leg.dte > 0 ? (
                              <span className="text-[9.5px] text-[#666] ml-1">({leg.dte}d)</span>
                            ) : null}
                          </td>

                          {/* Initial Mark / Basis */}
                          <td className="py-1.5 px-2 text-right font-bold text-white font-mono">
                            ${leg.premium.toFixed(2)}
                          </td>

                          {/* Individual Implied Volatility (IV) Stepper & Custom Input */}
                          <td className="py-1.5 px-2">
                            {isOption ? (
                              <div className="flex flex-col items-center">
                                <div className="flex items-center justify-center gap-1 font-mono">
                                  <button
                                    onClick={() => handleUpdateLegIv(leg, effectiveIv - 0.01)}
                                    title="Decrease individual IV (-1%)"
                                    className="w-4 h-4 flex items-center justify-center bg-[#222830] hover:bg-[#333d4a] text-white rounded text-[10px]"
                                  >
                                    -
                                  </button>
                                  <div className="relative flex items-center">
                                    <input
                                      type="number"
                                      step="0.5"
                                      min="1"
                                      max="500"
                                      value={Number((effectiveIv * 100).toFixed(1))}
                                      onChange={(e) => {
                                        const val = parseFloat(e.target.value);
                                        if (!isNaN(val)) {
                                          handleUpdateLegIv(leg, val / 100);
                                        }
                                      }}
                                      className={`w-14 px-1 py-0.5 bg-[#090b0e] border rounded text-right text-[11px] font-bold font-mono ${
                                        hasOverride
                                          ? 'text-[#c084fc] border-[#a855f7] bg-[#a855f7]/10'
                                          : 'text-white border-[#2a3038] hover:border-[#444]'
                                      }`}
                                      title="Edit individual Implied Volatility (%) for this simulated trade"
                                    />
                                    <span className="text-[10px] text-[#8c8c8c] ml-0.5">%</span>
                                  </div>
                                  <button
                                    onClick={() => handleUpdateLegIv(leg, effectiveIv + 0.01)}
                                    title="Increase individual IV (+1%)"
                                    className="w-4 h-4 flex items-center justify-center bg-[#222830] hover:bg-[#333d4a] text-white rounded text-[10px]"
                                  >
                                    +
                                  </button>
                                  {hasOverride && (
                                    <button
                                      onClick={() => handleResetLegIv(leg.id, leg)}
                                      title={`Reset IV to base chain (${(baseIv * 100).toFixed(1)}%)`}
                                      className="p-0.5 text-[#a855f7] hover:text-white rounded hover:bg-[#a855f7]/30 transition-colors"
                                    >
                                      <RotateCcw className="w-3 h-3" />
                                    </button>
                                  )}
                                </div>
                                {hasOverride && (
                                  <div className="text-[8.5px] text-center font-mono font-bold mt-0.5">
                                    <span className={ivDiff > 0 ? 'text-[#c084fc]' : 'text-[#f87171]'}>
                                      {ivDiff > 0 ? `+${(ivDiff * 100).toFixed(1)}% user` : `${(ivDiff * 100).toFixed(1)}% user`}
                                    </span>
                                  </div>
                                )}
                                {isOption && activeSkewModel && (
                                  <div className="flex flex-wrap items-center justify-center gap-1 mt-0.5 text-[8px] font-mono">
                                    {theoData.strikeSkewAdj !== undefined && Math.abs(theoData.strikeSkewAdj) > 0.0005 && (
                                      <span
                                        className={`px-1 py-0.2 rounded border ${
                                          theoData.strikeSkewAdj > 0
                                            ? 'bg-purple-900/30 text-purple-300 border-purple-500/40'
                                            : 'bg-indigo-900/30 text-indigo-300 border-indigo-500/40'
                                        }`}
                                        title="Strike Skew (Moneyness Smile adjustment)"
                                      >
                                        {theoData.strikeSkewAdj > 0 ? '+' : ''}{(theoData.strikeSkewAdj * 100).toFixed(1)}% strike
                                      </span>
                                    )}
                                    {theoData.termSkewAdj !== undefined && Math.abs(theoData.termSkewAdj) > 0.0005 && (
                                      <span
                                        className={`px-1 py-0.2 rounded border ${
                                          theoData.termSkewAdj > 0
                                            ? 'bg-sky-900/30 text-sky-300 border-sky-500/40'
                                            : 'bg-rose-900/30 text-rose-300 border-rose-500/40'
                                        }`}
                                        title="Term Structure Skew (Contango/Inversion adjustment)"
                                      >
                                        {theoData.termSkewAdj > 0 ? '+' : ''}{(theoData.termSkewAdj * 100).toFixed(1)}% term
                                      </span>
                                    )}
                                  </div>
                                )}
                              </div>
                            ) : (
                              <span className="text-[#555] text-center block font-mono">—</span>
                            )}
                          </td>

                          {/* Modeled Theoretical Price */}
                          <td className="py-1.5 px-2 text-right font-mono">
                            <div className="font-bold text-white">${theoData.theoreticalPrice.toFixed(2)}</div>
                            <div className={`text-[9px] font-bold ${theoData.unrealizedPnL >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
                              {theoData.unrealizedPnL >= 0 ? '+' : ''}${theoData.unrealizedPnL.toFixed(2)}
                            </div>
                            {theoData.valueAtFrontExp !== undefined && (
                              <div
                                className="text-[8.5px] text-[#34d399] font-mono font-bold mt-0.5 truncate"
                                title="Modeled theoretical value of surviving back-month option at front-month expiration (accounting for skew and vol shock)"
                              >
                                @ T_front: ${theoData.valueAtFrontExp.toFixed(2)}
                              </div>
                            )}
                          </td>

                          {/* Quantity / Contracts */}
                          <td className="py-1.5 px-2 text-right text-[#ccc] font-mono">
                            {isStock ? (
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  onClick={() => {
                                    playKeyClick();
                                    const newQty = Math.max(10, leg.contracts - 50);
                                    onUpdateLeg({ ...leg, contracts: newQty });
                                  }}
                                  className="px-1 py-0.2 bg-[#252525] hover:bg-[#333] text-white rounded text-[9px]"
                                  title="Decrease shares (-50)"
                                >
                                  -
                                </button>
                                <span className="font-bold text-white min-w-[50px] text-center">
                                  {leg.contracts} shs
                                </span>
                                <button
                                  onClick={() => {
                                    playKeyClick();
                                    const newQty = leg.contracts + 50;
                                    onUpdateLeg({ ...leg, contracts: newQty });
                                  }}
                                  className="px-1 py-0.2 bg-[#252525] hover:bg-[#333] text-white rounded text-[9px]"
                                  title="Increase shares (+50)"
                                >
                                  +
                                </button>
                              </div>
                            ) : isFuture ? (
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  onClick={() => {
                                    playKeyClick();
                                    const newQty = Math.max(1, leg.contracts - 1);
                                    onUpdateLeg({ ...leg, contracts: newQty });
                                  }}
                                  className="px-1 py-0.2 bg-[#252525] hover:bg-[#333] text-[#ffd600] rounded text-[9px]"
                                  title="Decrease contracts (-1)"
                                >
                                  -
                                </button>
                                <span className="font-bold text-[#ffd600] min-w-[50px] text-center">
                                  {leg.contracts} ct ({leg.multiplier || 50}x)
                                </span>
                                <button
                                  onClick={() => {
                                    playKeyClick();
                                    const newQty = leg.contracts + 1;
                                    onUpdateLeg({ ...leg, contracts: newQty });
                                  }}
                                  className="px-1 py-0.2 bg-[#252525] hover:bg-[#333] text-[#ffd600] rounded text-[9px]"
                                  title="Increase contracts (+1)"
                                >
                                  +
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center justify-end gap-1">
                                <button
                                  onClick={() => {
                                    playKeyClick();
                                    const newQty = Math.max(1, leg.contracts - 1);
                                    onUpdateLeg({ ...leg, contracts: newQty });
                                  }}
                                  className="px-1 py-0.2 bg-[#252525] hover:bg-[#333] text-white rounded text-[9px]"
                                  title="Decrease contracts (-1)"
                                >
                                  -
                                </button>
                                <span className="font-bold text-white min-w-[32px] text-center">
                                  {leg.contracts}x
                                </span>
                                <button
                                  onClick={() => {
                                    playKeyClick();
                                    const newQty = leg.contracts + 1;
                                    onUpdateLeg({ ...leg, contracts: newQty });
                                  }}
                                  className="px-1 py-0.2 bg-[#252525] hover:bg-[#333] text-white rounded text-[9px]"
                                  title="Increase contracts (+1)"
                                >
                                  +
                                </button>
                              </div>
                            )}
                          </td>

                          {/* Margin Buying Power (BP) */}
                          <td className="py-1.5 px-2 text-right font-mono font-bold text-[#ff9900]" title="Initial Margin Buying Power Reduction for this leg">
                            {(() => {
                              let legBp = 0;
                              let rule = 'DEBIT';
                              if (isStock) {
                                legBp = currentPrice * leg.contracts * (leg.multiplier || 1) * 0.5;
                                rule = leg.action === 'buy' ? 'REG-T 50%' : 'SHORT 50%';
                              } else if (isFuture) {
                                legBp = leg.contracts * 12320;
                                rule = 'SPAN FUT';
                              } else if (leg.action === 'buy') {
                                legBp = leg.premium * 100 * leg.contracts;
                                rule = 'DEBIT 100%';
                              } else {
                                const mult = (leg.multiplier || 100) * leg.contracts;
                                const prem = leg.premium * mult;
                                if (leg.type === 'call') {
                                  const otm = Math.max(0, (leg.strike - currentPrice) * mult);
                                  legBp = Math.max(currentPrice * mult * 0.20 - otm + prem, currentPrice * mult * 0.10 + prem);
                                } else {
                                  const otm = Math.max(0, (currentPrice - leg.strike) * mult);
                                  legBp = Math.max(currentPrice * mult * 0.20 - otm + prem, leg.strike * mult * 0.10 + prem);
                                }
                                rule = 'RULE 4210';
                              }
                              return (
                                <div>
                                  <span>${legBp.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                                  <span className="block text-[8px] text-[#8c8c8c] font-normal">{rule}</span>
                                </div>
                              );
                            })()}
                          </td>

                          {/* Delta */}
                          <td className="py-1.5 px-2 text-right font-mono font-bold">
                            <span className={theoData.delta >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}>
                              {theoData.delta >= 0 ? '+' : ''}{theoData.delta.toFixed(1)} Δ
                            </span>
                          </td>

                          {/* Vega */}
                          <td className="py-1.5 px-2 text-right font-mono text-[#00d2ff]">
                            {theoData.vega ? `${theoData.vega >= 0 ? '+' : ''}${theoData.vega.toFixed(2)}` : '0.00'}
                          </td>

                          {/* Theta */}
                          <td className="py-1.5 px-2 text-right font-mono text-[#ffd600]">
                            {theoData.theta ? `${theoData.theta.toFixed(2)}` : '$0.00'}
                          </td>

                          {/* Action (Remove Leg) */}
                          <td className="py-1.5 px-2 text-center">
                            {sourceMode === 'builder' ? (
                              <button
                                onClick={() => {
                                  playKeyClick();
                                  onRemoveLeg(leg.id);
                                }}
                                title="Remove leg from strategy builder"
                                className="p-1 text-[#8c8c8c] hover:text-[#ef4444] rounded hover:bg-[#ef4444]/10 transition-colors"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            ) : (
                              <span className="text-[#444] text-[9px]">LOCK</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot className="border-t-2 border-[#262a30] bg-[#121417] text-[10px] font-mono">
                    <tr>
                      <td colSpan={5} className="py-1.5 px-2 font-bold text-[#8c8c8c]">
                        <span className="text-[#38bdf8] font-black mr-2">NET STRATEGY COLLATERAL:</span>
                        <span className="text-white">Rule 4210 / FINRA Standard Portfolio Margin</span>
                      </td>
                      <td className="py-1.5 px-2 text-right font-bold text-white">
                        ${analysis.netDebitCredit.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-1.5 px-2 text-center text-[#c084fc] font-bold">
                        {allSourceLegs.length} LEGS
                      </td>
                      <td className="py-1.5 px-2 text-right font-bold text-white">
                        —
                      </td>
                      <td className="py-1.5 px-2 text-right font-bold text-white">
                        {allSourceLegs.reduce((sum, l) => sum + l.contracts, 0)}x
                      </td>
                      <td className="py-1.5 px-2 text-right font-black text-[#ff9900]">
                        ${analysis.marginBuyingPower.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                        <div className="text-[8px] text-[#8c8c8c] font-normal">
                          {analysis.marginType.replace(/_/g, ' ')}
                        </div>
                      </td>
                      <td className={`py-1.5 px-2 text-right font-bold ${analysis.totalDelta >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'}`}>
                        {analysis.totalDelta >= 0 ? '+' : ''}{analysis.totalDelta.toFixed(1)} Δ
                      </td>
                      <td className="py-1.5 px-2 text-right font-bold text-[#00d2ff]">
                        ${analysis.totalVega.toFixed(2)}
                      </td>
                      <td className="py-1.5 px-2 text-right font-bold text-[#ffd600]">
                        ${analysis.totalTheta.toFixed(2)}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}
          </div>

          {/* Scenario P&L Matrix Table */}
          <div className="bg-[#14171a] p-3 rounded border border-[var(--border)] flex flex-col gap-2">
            <div className="flex justify-between items-center border-b border-[#2d3339] pb-2">
              <span className="font-extrabold text-[var(--accent)] flex items-center gap-1.5">
                <Sliders className="w-4 h-4" />
                <span>SCENARIO PAYOFF MATRIX</span>
              </span>
              <span className="text-[10px] text-[#8c8c8c]">Discrete price outcome lookup</span>
            </div>

            <table className="w-full text-left text-[11px]">
              <thead>
                <tr className="border-b border-[#262a30] text-[#8c8c8c] text-[10px] uppercase">
                  <th className="py-1 px-2">CHANGE %</th>
                  <th className="py-1 px-2">PRICE TARGET</th>
                  <th className="py-1 px-2 text-right">P&L TODAY</th>
                  <th className="py-1 px-2 text-right">P&L EXPIRY</th>
                  <th className="py-1 px-2 text-right">DELTA (Δ)</th>
                  <th className="py-1 px-2 text-right">THETA (Θ)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1e2227]">
                {scenarioRows.map((row) => {
                  const isAtm = row.stepPct === 0;
                  return (
                    <tr
                      key={row.stepPct}
                      className={`hover:bg-[#1a1e22] transition-colors ${
                        isAtm ? 'bg-[#222830] font-bold' : ''
                      }`}
                    >
                      <td
                        className={`py-1 px-2 font-bold ${
                          row.stepPct > 0
                            ? 'text-[var(--bull)]'
                            : row.stepPct < 0
                            ? 'text-[var(--bear)]'
                            : 'text-white'
                        }`}
                      >
                        {row.stepPct >= 0 ? `+${row.stepPct}%` : `${row.stepPct}%`}
                      </td>
                      <td className="py-1 px-2 font-mono text-white">${row.targetP.toFixed(2)}</td>
                      <td
                        className={`py-1 px-2 text-right font-bold ${
                          row.pnlToday >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'
                        }`}
                      >
                        {row.pnlToday >= 0 ? '+' : ''}${row.pnlToday.toFixed(2)}
                      </td>
                      <td
                        className={`py-1 px-2 text-right font-bold ${
                          row.pnlExp >= 0 ? 'text-[var(--bull)]' : 'text-[var(--bear)]'
                        }`}
                      >
                        {row.pnlExp >= 0 ? '+' : ''}${row.pnlExp.toFixed(2)}
                      </td>
                      <td className="py-1 px-2 text-right text-[#8c8c8c]">{row.delta.toFixed(2)}</td>
                      <td className="py-1 px-2 text-right text-[#ffd600]">${row.theta.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

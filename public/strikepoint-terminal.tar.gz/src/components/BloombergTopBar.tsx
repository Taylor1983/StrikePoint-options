import React, { useState, useEffect, useRef } from 'react';
import { Ticker, TerminalScreen, AccountState } from '../types/options';
import {
  playKeyClick,
  isTerminalAudioEnabled,
  setTerminalAudioEnabled,
} from '../utils/terminalSound';
import {
  Volume2,
  VolumeX,
  Terminal as TerminalIcon,
  Search,
  Radio,
  Clock,
  HelpCircle,
  Shield,
} from 'lucide-react';
import { calculateMarginHealth } from '../utils/marginHealth';

interface BloombergTopBarProps {
  currentScreen: TerminalScreen;
  onNavigateScreen: (screen: TerminalScreen) => void;
  selectedTicker: Ticker;
  tickers: Record<string, Ticker>;
  onSelectTicker: (sym: string) => void;
  account: AccountState;
  onOpenHelp: () => void;
}

export const BloombergTopBar: React.FC<BloombergTopBarProps> = ({
  currentScreen,
  onNavigateScreen,
  selectedTicker,
  tickers,
  onSelectTicker,
  account,
  onOpenHelp,
}) => {
  const [commandInput, setCommandInput] = useState('');
  const [isAudioOn, setIsAudioOn] = useState(true);
  const [clockTime, setClockTime] = useState({ utc: '', est: '' });
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Update terminal clock every second
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const utcStr = now.toUTCString().split(' ')[4] + ' UTC';
      const estStr = now.toLocaleTimeString('en-US', {
        timeZone: 'America/New_York',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      }) + ' EST';
      setClockTime({ utc: utcStr, est: estStr });
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleAudioToggle = () => {
    const next = !isAudioOn;
    setIsAudioOn(next);
    setTerminalAudioEnabled(next);
    if (next) playKeyClick();
  };

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playKeyClick();
    const trimmed = commandInput.trim().toUpperCase();
    if (!trimmed) return;

    // Check screen commands
    if (trimmed.includes('OMON')) {
      onNavigateScreen('omon');
    } else if (trimmed.includes('OVME') || trimmed.includes('CALC') || trimmed.includes('STRAT')) {
      onNavigateScreen('ovme');
    } else if (trimmed.includes('CONE') || trimmed.includes('PROB') || trimmed.includes('EXP')) {
      onNavigateScreen('cone');
    } else if (trimmed.includes('FLOW') || trimmed.includes('AOP')) {
      onNavigateScreen('flow');
    } else if (trimmed.includes('SCEN')) {
      onNavigateScreen('scen');
    } else if (trimmed.includes('HIVG') || trimmed.includes('HVT') || trimmed.includes('HVIV') || trimmed === 'HV' || trimmed === 'IV') {
      onNavigateScreen('hivg');
    } else if (trimmed.includes('SURF') || trimmed.includes('3D') || trimmed.includes('GVS')) {
      onNavigateScreen('surf');
    } else if (trimmed.includes('VOL') || trimmed.includes('GV') || trimmed.includes('SKEW')) {
      onNavigateScreen('vols');
    } else if (
      trimmed.includes('VEGA') ||
      trimmed.includes('TERM STRUCT') ||
      trimmed === 'VTS' ||
      trimmed.includes('VOLGA') ||
      trimmed.includes('VOMMA')
    ) {
      onNavigateScreen('vega');
    } else if (trimmed.includes('CHART') || trimmed.includes('HP') || trimmed.includes('G') || trimmed === 'TA' || trimmed.includes('TECHO') || trimmed.includes('TECH') || trimmed.includes('INDICATOR') || trimmed.includes('INDICATORS') || trimmed.includes('STUDY') || trimmed.includes('STUDIES')) {
      onNavigateScreen('chart');
    } else if (
      trimmed.includes('MONITOR') ||
      trimmed === 'MON' ||
      trimmed === 'WATCH' ||
      trimmed === 'BLOTTER' ||
      trimmed.includes('CAD') ||
      trimmed.includes('CANADIAN') ||
      trimmed.includes('CIRO') ||
      trimmed.includes('TFSA') ||
      trimmed.includes('RRSP') ||
      trimmed.includes('FHSA')
    ) {
      onNavigateScreen('monitor');
    } else if (
      trimmed.includes('PORT') ||
      trimmed.includes('BLOT') ||
      trimmed.includes('POS') ||
      trimmed === 'BUYING POWER' ||
      trimmed === 'MARGIN' ||
      trimmed === 'BP MARGIN' ||
      trimmed.includes('BORROW') ||
      trimmed.includes('INTEREST') ||
      trimmed.includes('FINANCING') ||
      trimmed.includes('HTB')
    ) {
      onNavigateScreen('port');
    } else if (
      trimmed.includes('MARGIN DEBT') ||
      trimmed === 'DEBT' ||
      trimmed.includes('GDP')
    ) {
      onNavigateScreen('chart');
    } else if (trimmed.includes('PCR') || trimmed === 'P/C' || trimmed.includes('PUTCALL') || trimmed.includes('PUT/CALL') || trimmed.includes('RATIO')) {
      onNavigateScreen('pcr');
    } else if (
      trimmed.includes('OPEC') ||
      trimmed.includes('JMMC') ||
      trimmed.includes('OVX') ||
      trimmed.includes('OIL EVENT') ||
      trimmed.includes('OIL VOL')
    ) {
      onNavigateScreen('opec');
    } else if (
      trimmed.includes('TARIFF') ||
      trimmed === 'TRFF' ||
      trimmed.includes('TRADE WAR') ||
      trimmed.includes('DUTY') ||
      trimmed.includes('CUSTOMS')
    ) {
      onNavigateScreen('tariff');
    } else if (trimmed === 'BP' || trimmed === 'BP US' || trimmed === 'BP US EQUITY' || trimmed === 'BP EQUITY') {
      onSelectTicker('BP');
    } else if (trimmed.includes('HELP')) {
      onOpenHelp();
    }

    // Check ticker commands (e.g. "NVDA", "TSLA", "SPY US EQUITY", "BP")
    const words = trimmed.split(' ');
    for (const w of words) {
      if (tickers[w]) {
        onSelectTicker(w);
        break;
      }
    }

    setCommandInput('');
    setShowSuggestions(false);
  };

  const functionKeys: { label: string; key: string; screen?: TerminalScreen; action?: () => void }[] = [
    { label: '<F1 HELP>', key: 'HELP', action: onOpenHelp },
    { label: '<F2 OMON>', key: 'OMON', screen: 'omon' },
    { label: '<F3 OVME>', key: 'OVME', screen: 'ovme' },
    { label: '<F4 CONE>', key: 'CONE', screen: 'cone' },
    { label: '<F5 SCEN>', key: 'SCEN', screen: 'scen' },
    { label: '<F6 FLOW>', key: 'FLOW', screen: 'flow' },
    { label: '<F7 VOLS>', key: 'VOLS', screen: 'vols' },
    { label: '<SURF 3D>', key: 'SURF', screen: 'surf' },
    { label: '<F8 HIVG>', key: 'HIVG', screen: 'hivg' },
    { label: '<F9 CHART/TA>', key: 'CHART', screen: 'chart' },
    { label: '<F10 PORT>', key: 'PORT', screen: 'port' },
    {
      label: account.positions.length > 0 ? `<MONITOR (${account.positions.length})>` : '<MONITOR>',
      key: 'MONITOR',
      screen: 'monitor',
    },
    { label: '<F11 PCR>', key: 'PCR', screen: 'pcr' },
    { label: '<F12 OPEC>', key: 'OPEC', screen: 'opec' },
    { label: '<TRFF TARIFF>', key: 'TRFF', screen: 'tariff' },
    { label: '<VEGA VTS>', key: 'VEGA', screen: 'vega' },
  ];

  const positionsMark = account.positions.reduce((acc, p) => acc + p.currentMark, 0);
  const netLiq = account.cashBalance + positionsMark;
  const totalPnL = netLiq - account.startingBalance;
  const isPnlPositive = totalPnL >= 0;

  const marginRequirement = account.positions.reduce((acc, p) => {
    if (p.entryCost < 0) return acc + Math.abs(p.entryCost) * 1.5;
    return acc;
  }, 0);
  const optionsBP = Math.max(0, account.cashBalance - marginRequirement);

  const marginHealth = React.useMemo(() => {
    return calculateMarginHealth(account.cashBalance, account.positions, tickers);
  }, [account.cashBalance, account.positions, tickers]);

  return (
    <div className="bg-[#05070a] border-b-2 border-[#1e2638] select-none text-xs font-mono">
      {/* Function Keys Strip (Bloomberg Keyboard Top Row) */}
      <div className="bg-[#080b12] border-b border-[#141b2a] px-3 py-1 flex items-center justify-between overflow-x-auto no-scrollbar gap-2">
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="flex items-center gap-1 font-black text-[#ff9900] tracking-wider pr-2 border-r border-[#1e2638]">
            <TerminalIcon className="w-3.5 h-3.5" />
            <span>BLOOMBERG</span>
            <span className="text-[10px] text-[#8b9bb4] font-normal">PROFESSIONAL</span>
          </div>

          {functionKeys.map((fk) => {
            const isActive = fk.screen && currentScreen === fk.screen;
            return (
              <button
                key={fk.key}
                onClick={() => {
                  playKeyClick();
                  if (fk.action) fk.action();
                  else if (fk.screen) onNavigateScreen(fk.screen);
                }}
                className={`px-2.5 py-0.5 rounded text-[11px] font-bold tracking-tight transition-all border shrink-0 ${
                  isActive
                    ? 'bg-[#ff9900] text-black border-[#ff9900] font-extrabold shadow-[0_0_8px_rgba(255,153,0,0.5)]'
                    : 'bg-[#0f1422] text-[#ffb020] hover:bg-[#1a2236] border-[#222d44] hover:border-[#ff9900]/50'
                }`}
              >
                {fk.label}
              </button>
            );
          })}
        </div>

        {/* Audio Toggle & Clock */}
        <div className="flex items-center gap-3 shrink-0 text-[11px] text-[#8b9bb4]">
          <button
            onClick={handleAudioToggle}
            title={isAudioOn ? 'Mute terminal audio' : 'Enable terminal audio'}
            className={`flex items-center gap-1 px-2 py-0.5 rounded border transition-colors ${
              isAudioOn
                ? 'bg-[#00e676]/10 border-[#00e676]/40 text-[#00e676]'
                : 'bg-[#141b2a] border-[#222d44] text-[#8b9bb4] hover:text-white'
            }`}
          >
            {isAudioOn ? <Volume2 className="w-3 h-3" /> : <VolumeX className="w-3 h-3" />}
            <span className="hidden sm:inline">{isAudioOn ? 'AUDIO ON' : 'MUTED'}</span>
          </button>

          <div className="hidden lg:flex items-center gap-2 bg-[#0c101c] px-2 py-0.5 rounded border border-[#1a2336] text-[#8b9bb4]">
            <Clock className="w-3 h-3 text-[#ff9900]" />
            <span className="text-[#e2e8f0] font-bold">{clockTime.est}</span>
            <span className="text-[10px] text-[#556782]">({clockTime.utc})</span>
          </div>
        </div>
      </div>

      {/* Bloomberg Command Prompt Bar */}
      <div className="px-3 py-1.5 flex flex-wrap items-center justify-between gap-3 bg-[#07090e]">
        {/* Command Line Input */}
        <form onSubmit={handleCommandSubmit} className="flex items-center gap-2 flex-1 max-w-xl relative">
          <div className="flex items-center gap-1 bg-[#0b0f1a] border border-[#263550] focus-within:border-[#ff9900] px-2 py-1 rounded w-full shadow-inner">
            <span className="text-[#ff9900] font-bold text-xs select-none">{'>'}</span>
            <input
              ref={inputRef}
              type="text"
              value={commandInput}
              onChange={(e) => {
                setCommandInput(e.target.value);
                setShowSuggestions(e.target.value.length > 0);
              }}
              placeholder={`${selectedTicker.symbol} US Equity ${currentScreen.toUpperCase()} <GO>`}
              className="bg-transparent border-none outline-none text-white text-xs w-full uppercase placeholder:text-[#475569] font-mono tracking-wider"
            />
            {commandInput && (
              <button
                type="button"
                onClick={() => setCommandInput('')}
                className="text-[#64748b] hover:text-white text-xs px-1"
              >
                ✕
              </button>
            )}
          </div>

          <button
            type="submit"
            className="px-3 py-1 bg-[#ff9900] hover:bg-[#ffaa22] text-black font-extrabold text-xs tracking-wider rounded border border-[#ff9900] shadow-[0_0_10px_rgba(255,153,0,0.3)] transition-transform active:scale-95"
          >
            {'<GO>'}
          </button>

          {/* Command Suggestions Popup */}
          {showSuggestions && (
            <div className="absolute top-full left-0 mt-1 w-full bg-[#0a0e18] border border-[#ff9900]/40 rounded shadow-2xl z-50 text-xs overflow-hidden">
              <div className="p-1.5 bg-[#141b2a] text-[#8b9bb4] text-[10px] uppercase font-bold tracking-wider flex justify-between">
                <span>Terminal Shortcuts</span>
                <span>Press Enter to Run</span>
              </div>
              <div className="divide-y divide-[#1e2638] max-h-48 overflow-y-auto">
                {Object.keys(tickers).map((sym) => (
                  <button
                    key={sym}
                    type="button"
                    onClick={() => {
                      playKeyClick();
                      onSelectTicker(sym);
                      setCommandInput('');
                      setShowSuggestions(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-[#1a2336] flex items-center justify-between text-[#e2e8f0]"
                  >
                    <span>
                      <strong className="text-[#ff9900]">{sym}</strong> US Equity
                    </span>
                    <span className="text-[10px] text-[#8b9bb4]">${tickers[sym].price.toFixed(2)}</span>
                  </button>
                ))}
                {['OMON Options Monitor', 'OVME Options Valuation', 'MONITOR Position & Margin Health Blotter', 'CANADIAN MARGIN Canadian Margin Health (CIRO 5300 & CRA)', 'SURF 3D Volatility Surface', 'VOLS Volatility Skews', 'HIVG Historical Volatility Graph', 'CHART / TA Technical Analysis (TECHO)', 'PCR Put/Call Ratio & Sentiment', 'FLOW Unusual Flow', 'SCEN Scenario Matrix', 'PORT Portfolio & Buying Power (BP)'].map(
                  (cmd) => (
                    <button
                      key={cmd}
                      type="button"
                      onClick={() => {
                        playKeyClick();
                        const firstWord = cmd.split(' ')[0].toLowerCase();
                        const code = (firstWord === 'monitor' || firstWord === 'canadian' ? 'monitor' : firstWord) as TerminalScreen;
                        onNavigateScreen(code);
                        setCommandInput('');
                        setShowSuggestions(false);
                      }}
                      className="w-full text-left px-3 py-1.5 hover:bg-[#1a2336] text-[#00d2ff] font-bold"
                    >
                      {cmd}
                    </button>
                  )
                )}
              </div>
            </div>
          )}
        </form>

        {/* Security Quick Bar & Account Quick Readout */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Active Security Badge */}
          <div className="flex items-center gap-2 bg-[#0c101c] border border-[#222d44] px-2.5 py-1 rounded">
            <span className="text-[#8b9bb4] text-[10px]">SECURITY:</span>
            <span className="text-[#ff9900] font-black">{selectedTicker.symbol}</span>
            <span className="text-[#cbd5e1] text-[10px] hidden sm:inline">US EQUITY</span>
            <span className="text-white font-bold ml-1">${selectedTicker.price.toFixed(2)}</span>
            <span
              className={`text-[10px] font-bold ${
                selectedTicker.change >= 0 ? 'text-[#00e676]' : 'text-[#ff334b]'
              }`}
            >
              {selectedTicker.change >= 0 ? '+' : ''}
              {selectedTicker.changePercent.toFixed(2)}%
            </span>
          </div>

          {/* Options Buying Power (BP) Quick Readout */}
          <div className="hidden md:flex items-center gap-1.5 bg-[#0c101c] border border-[#00e5ff]/40 px-2.5 py-1 rounded">
            <span className="text-[#8b9bb4] text-[10px]">BP:</span>
            <span className="text-[#00e5ff] font-black">${optionsBP.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}</span>
          </div>

          {/* Margin Health Quick Readout Button */}
          <button
            type="button"
            onClick={() => {
              playKeyClick();
              onNavigateScreen('monitor');
            }}
            title={`Margin Health Score: ${marginHealth.healthScore}/100 (${marginHealth.status}) - Margin Cushion: ${marginHealth.marginCushionPercent.toFixed(1)}%. Click to open Monitor.`}
            className="hidden sm:flex items-center gap-1.5 bg-[#0c101c] border border-[#1e283d] hover:border-[#38bdf8] px-2.5 py-1 rounded transition-colors cursor-pointer group"
          >
            <Shield className="w-3.5 h-3.5 text-[#38bdf8] group-hover:scale-110 transition-transform" />
            <span className="text-[#8b9bb4] text-[10px]">MARGIN:</span>
            <span
              className="text-xs font-black font-mono"
              style={{ color: marginHealth.statusColor }}
            >
              {marginHealth.healthScore}%
            </span>
          </button>

          {/* Account Net Liq Snapshot */}
          <div className="hidden sm:flex items-center gap-2 bg-[#0c101c] border border-[#222d44] px-2.5 py-1 rounded">
            <span className="text-[#8b9bb4] text-[10px]">NET LIQ:</span>
            <span className="text-white font-bold">${netLiq.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            <span className={`text-[10px] font-bold ${isPnlPositive ? 'text-[#00e676]' : 'text-[#ff334b]'}`}>
              ({isPnlPositive ? '+' : ''}${totalPnL.toFixed(2)})
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

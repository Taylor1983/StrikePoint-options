import React, { useState, useMemo } from 'react';
import {
  Ticker,
  ExpirationOptionChain,
  Position,
  TradeLeg,
} from '../types/options';
import {
  calculateVegaTermStructure,
  calculateAllExpirationsAllStrikesVega,
  ExpirationVegaPoint,
  VegaMaturityBucket,
  StrikeVegaCell,
  AllExpirationsAllStrikesVegaMatrix,
} from '../utils/vegaTermStructure';
import {
  Activity,
  TrendingUp,
  Sparkles,
  Layers,
  Sliders,
  Info,
  Calendar,
  Zap,
  BarChart2,
  DollarSign,
  ArrowRight,
  Maximize2,
  Check,
  Percent,
  Compass,
  Grid,
  Table,
  Search,
  Filter,
  Download,
  Copy,
  ChevronDown,
  ChevronRight,
  Eye,
  SlidersHorizontal,
  Flame,
  Shield,
  Clock,
  Plus,
} from 'lucide-react';
import { playKeyClick, playExecutionChime } from '../utils/terminalSound';

interface VegaTermStructureViewProps {
  ticker: Ticker;
  chains: ExpirationOptionChain[];
  positions?: Position[];
  legs?: TradeLeg[];
  selectedDte?: number;
  onSelectDte?: (dte: number) => void;
  onNavigateToChain?: () => void;
  onNavigateToValuation?: () => void;
  onApplyStrategyTemplate?: (templateId: string) => void;
}

export const VegaTermStructureView: React.FC<VegaTermStructureViewProps> = ({
  ticker,
  chains,
  positions = [],
  legs = [],
  selectedDte,
  onSelectDte,
  onNavigateToChain,
  onNavigateToValuation,
  onApplyStrategyTemplate,
}) => {
  // View mode switcher: 'matrix' (All Expirations x All Strikes Grid), 'blotter' (Multi-Expiration Strike Table), 'curve' (SVG Term Structure)
  const [viewMode, setViewMode] = useState<'matrix' | 'blotter' | 'curve'>('matrix');

  // Matrix metric selector
  const [selectedMetric, setSelectedMetric] = useState<'vega' | 'weighted' | 'vomma' | 'veta' | 'notional' | 'elasticity'>('vega');

  // Strike range filter: 'all' | '5' | '10' | '20' | 'puts' | 'calls'
  const [strikeRange, setStrikeRange] = useState<'all' | '5' | '10' | '20' | 'puts' | 'calls'>('all');

  // Search query for strikes
  const [strikeSearch, setStrikeSearch] = useState<string>('');

  // Selected cell for deep inspection
  const [selectedCell, setSelectedCell] = useState<StrikeVegaCell | null>(null);

  // Copy feedback notification
  const [copiedNotification, setCopiedNotification] = useState<string | null>(null);

  // Expanded tenors in blotter view
  const [expandedTenors, setExpandedTenors] = useState<Record<number, boolean>>(() => {
    const init: Record<number, boolean> = {};
    if (chains && chains.length > 0) {
      init[chains[0].dte] = true;
      if (chains[1]) init[chains[1].dte] = true;
    }
    return init;
  });

  // Curve interactive toggles
  const [showAbsoluteVega, setShowAbsoluteVega] = useState<boolean>(true);
  const [showWeightedVega, setShowWeightedVega] = useState<boolean>(true);
  const [show25DeltaSkew, setShow25DeltaSkew] = useState<boolean>(false);
  const [showVomma, setShowVomma] = useState<boolean>(false);

  // Hovered expiration node
  const [hoveredPoint, setHoveredPoint] = useState<ExpirationVegaPoint | null>(null);

  // Interactive Volatility Shock Simulator
  const [simVolShock, setSimVolShock] = useState<number>(0); // e.g. -5% to +5%
  const [simCurveTwist, setSimCurveTwist] = useState<number>(0); // Front-month extra shock

  // Compute 2D Matrix of All Expirations and All Strikes
  const matrixData: AllExpirationsAllStrikesVegaMatrix = useMemo(() => {
    return calculateAllExpirationsAllStrikesVega(ticker, chains);
  }, [ticker, chains]);

  // Compute Vega Term Structure Analytics
  const analytics = useMemo(() => {
    return calculateVegaTermStructure(ticker, chains, positions, legs);
  }, [ticker, chains, positions, legs]);

  const { points, maturityBuckets, totalPortfolioNetVega, totalPortfolioWeightedVega } = analytics;

  // Active highlighted point: either hovered or selected
  const activePoint = hoveredPoint || (selectedDte ? points.find((p) => p.dte === selectedDte) : points[0]) || points[0];

  // SVG Chart Geometry
  const svgWidth = 860;
  const svgHeight = 290;
  const padding = { top: 30, right: 55, bottom: 45, left: 65 };

  const minDte = points.length > 0 ? Math.min(...points.map((p) => p.dte)) : 1;
  const maxDte = points.length > 0 ? Math.max(...points.map((p) => p.dte)) : 365;

  const maxAbsoluteVega = Math.max(...points.map((p) => p.atmVega100), 10);
  const maxWeightedVega = Math.max(...points.map((p) => p.weightedVega30), 10);
  const yMax = Math.max(maxAbsoluteVega, maxWeightedVega) * 1.15;
  const yMin = 0;

  const getX = (dte: number) => {
    const norm = (dte - minDte) / (maxDte - minDte || 1);
    return padding.left + norm * (svgWidth - padding.left - padding.right);
  };

  const getY = (val: number) => {
    const norm = (val - yMin) / (yMax - yMin || 1);
    return svgHeight - padding.bottom - norm * (svgHeight - padding.top - padding.bottom);
  };

  const createPath = (values: { dte: number; val: number }[]) => {
    return values.reduce((acc, pt, idx) => {
      const x = getX(pt.dte);
      const y = getY(pt.val);
      return `${acc} ${idx === 0 ? 'M' : 'L'} ${x.toFixed(1)} ${y.toFixed(1)}`;
    }, '');
  };

  const absoluteVegaPath = createPath(points.map((p) => ({ dte: p.dte, val: p.atmVega100 })));
  const weightedVegaPath = createPath(points.map((p) => ({ dte: p.dte, val: p.weightedVega30 })));
  const call25Path = createPath(points.map((p) => ({ dte: p.dte, val: p.call25DeltaVega })));
  const put25Path = createPath(points.map((p) => ({ dte: p.dte, val: p.put25DeltaVega })));

  // Filter strikes based on range and search query
  const filteredStrikes = useMemo(() => {
    let result = matrixData.strikes;
    const spot = ticker.price;

    if (strikeSearch.trim()) {
      const q = strikeSearch.trim();
      result = result.filter((s) => String(s).includes(q));
    }

    if (strikeRange === '5') {
      result = result.filter((s) => Math.abs(s - spot) / spot <= 0.05);
    } else if (strikeRange === '10') {
      result = result.filter((s) => Math.abs(s - spot) / spot <= 0.10);
    } else if (strikeRange === '20') {
      result = result.filter((s) => Math.abs(s - spot) / spot <= 0.20);
    } else if (strikeRange === 'puts') {
      result = result.filter((s) => s <= spot * 1.02);
    } else if (strikeRange === 'calls') {
      result = result.filter((s) => s >= spot * 0.98);
    }

    return result;
  }, [matrixData.strikes, ticker.price, strikeRange, strikeSearch]);

  // Color intensity mapper for Vega cells
  const getCellColor = (val: number, max: number, isATM: boolean) => {
    if (val <= 0) return 'bg-[#090d16] text-[#64748b]';
    const ratio = Math.max(0, Math.min(1, val / (max || 1)));

    if (ratio > 0.8) {
      return isATM
        ? 'bg-[#ff9900]/30 text-[#ffaa00] font-black border border-[#ff9900]/60 shadow-[0_0_8px_rgba(255,153,0,0.3)]'
        : 'bg-[#ff9900]/25 text-[#ff9900] font-black border border-[#ff9900]/40';
    }
    if (ratio > 0.6) {
      return 'bg-[#00e5ff]/20 text-[#00e5ff] font-bold border border-[#00e5ff]/30';
    }
    if (ratio > 0.4) {
      return 'bg-[#38bdf8]/15 text-[#38bdf8] font-bold border border-[#38bdf8]/20';
    }
    if (ratio > 0.2) {
      return 'bg-[#0284c7]/10 text-[#93c5fd] border border-[#0284c7]/15';
    }
    return 'bg-[#0b101d] text-[#8b9bb4]';
  };

  // Cell value formatter depending on selected metric
  const formatCellValue = (cell: StrikeVegaCell | undefined) => {
    if (!cell) return '-';
    switch (selectedMetric) {
      case 'vega':
        return `$${cell.avgVega.toFixed(1)}`;
      case 'weighted':
        return `$${cell.weightedVega30.toFixed(1)}`;
      case 'vomma':
        return `+${cell.vomma.toFixed(2)}`;
      case 'veta':
        return `${cell.veta.toFixed(2)}`;
      case 'notional':
        return cell.marketVegaNotional > 1000
          ? `$${(cell.marketVegaNotional / 1000).toFixed(0)}k`
          : `$${cell.marketVegaNotional}`;
      case 'elasticity':
        return `${cell.callVegaPerShare > 0 ? (cell.callVegaPerShare * 100).toFixed(1) : '0'}%`;
      default:
        return `$${cell.avgVega.toFixed(1)}`;
    }
  };

  // CSV export function
  const handleExportCSV = () => {
    playExecutionChime();
    const headers = ['Strike', 'Moneyness%', ...matrixData.expirations.map((e) => `${e.month}_${e.dte}D_Vega`)];
    const rows = matrixData.strikes.map((s) => {
      const rowVals = [
        s.toFixed(1),
        ((s / ticker.price) * 100).toFixed(1) + '%',
        ...matrixData.expirations.map((e) => {
          const cell = matrixData.matrix[s]?.[e.dte];
          return cell ? cell.avgVega.toFixed(2) : '0';
        }),
      ];
      return rowVals.join(',');
    });
    const csv = [headers.join(','), ...rows].join('\n');
    try {
      navigator.clipboard?.writeText(csv);
      setCopiedNotification('Vega matrix (all expirations & all strikes) copied to clipboard as CSV!');
      setTimeout(() => setCopiedNotification(null), 3500);
    } catch {}
  };

  const toggleAllTenors = (expand: boolean) => {
    playKeyClick();
    const updated: Record<number, boolean> = {};
    if (expand) {
      matrixData.expirations.forEach((e) => {
        updated[e.dte] = true;
      });
    }
    setExpandedTenors(updated);
  };

  return (
    <div className="bg-[#07090e] border border-[#1e2638] rounded-lg shadow-2xl p-3 sm:p-4 flex flex-col gap-4 text-xs font-sans select-none">
      {/* 1. Top Header Banner & Fast Navigation */}
      <div className="bg-[#0b101c] border border-[#ff9900]/30 rounded p-3 sm:p-4 flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded bg-[#ff9900]/10 border border-[#ff9900]/40 flex items-center justify-center text-[#ff9900] shadow-sm">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-sm font-black text-white tracking-wide uppercase">
                {ticker.symbol} VEGA ALL EXPIRATIONS &amp; ALL STRIKES ENGINE
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#ff9900]/20 text-[#ff9900] border border-[#ff9900]/40 font-mono font-black">
                {matrixData.expirations.length} TENORS · {matrixData.strikes.length} STRIKES
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-[#00e5ff]/20 text-[#00e5ff] border border-[#00e5ff]/40 font-mono font-bold">
                {analytics.regimeLabel}
              </span>
            </div>
            <div className="text-[11px] text-[#8b9bb4] mt-0.5 flex flex-wrap items-center gap-2">
              <span>Spot: <strong className="text-white font-mono">${ticker.price.toFixed(2)}</strong></span>
              <span>·</span>
              <span>Front-Month ATM: <strong className="text-[#00e5ff]">${analytics.frontMonthVega.toFixed(2)}</strong></span>
              <span>·</span>
              <span>Back-Month ATM: <strong className="text-[#ff9900]">${analytics.backMonthVega.toFixed(2)}</strong></span>
              <span>·</span>
              <span>Term Ratio: <strong className="text-white">{analytics.vegaSlopeRatio}x</strong></span>
              <span>·</span>
              <span>Surface Max Vega: <strong className="text-[#ffd600]">${matrixData.maxVega.toFixed(2)}</strong></span>
            </div>
          </div>
        </div>

        {/* Action Shortcuts & CSV Export */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="px-2.5 py-1.5 bg-[#141b28] hover:bg-[#1e293b] text-[#cbd5e1] hover:text-white border border-[#222d44] rounded text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            title="Export complete Vega Surface matrix to CSV clipboard"
          >
            <Copy className="w-3.5 h-3.5 text-[#00d2ff]" />
            <span className="hidden sm:inline">COPY CSV MATRIX</span>
          </button>

          {onNavigateToValuation && (
            <button
              onClick={() => {
                playKeyClick();
                onNavigateToValuation();
              }}
              className="px-2.5 py-1.5 bg-[#141b28] hover:bg-[#1e293b] text-white border border-[#222d44] hover:border-[#ff9900]/50 rounded text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <span>OVME</span>
              <ArrowRight className="w-3 h-3 text-[#ff9900]" />
            </button>
          )}

          {onNavigateToChain && (
            <button
              onClick={() => {
                playKeyClick();
                onNavigateToChain();
              }}
              className="px-2.5 py-1.5 bg-[#ff9900] hover:bg-[#ffaa22] text-black rounded text-xs font-black transition-all flex items-center gap-1 shadow-sm cursor-pointer"
            >
              <span>OPTION CHAIN</span>
            </button>
          )}
        </div>
      </div>

      {/* Copy notification popup */}
      {copiedNotification && (
        <div className="bg-[#00e676]/20 border border-[#00e676] text-[#00e676] px-3 py-1.5 rounded text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <Check className="w-4 h-4" />
          <span>{copiedNotification}</span>
        </div>
      )}

      {/* 2. Top Summary Metric Cards (5 Columns) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
        <div className="bg-[#090d16] border border-[#1e2638] rounded p-2.5 flex flex-col justify-between">
          <div className="text-[9.5px] text-[#8b9bb4] uppercase font-bold flex items-center gap-1">
            <Calendar className="w-3 h-3 text-[#ef4444]" />
            <span>Front ATM Vega ({analytics.frontMonthDte}D)</span>
          </div>
          <div className="text-base sm:text-lg font-black font-mono text-white mt-1">
            ${analytics.frontMonthVega.toFixed(2)}
            <span className="text-[10px] text-[#8b9bb4] font-normal ml-1">/ 1% IV</span>
          </div>
          <div className="text-[9px] text-[#64748b]">
            Short tenor; rapid theta decay
          </div>
        </div>

        <div className="bg-[#090d16] border border-[#1e2638] rounded p-2.5 flex flex-col justify-between">
          <div className="text-[9.5px] text-[#8b9bb4] uppercase font-bold flex items-center gap-1">
            <Calendar className="w-3 h-3 text-[#a855f7]" />
            <span>Back ATM Vega ({analytics.backMonthDte}D)</span>
          </div>
          <div className="text-base sm:text-lg font-black font-mono text-[#ff9900] mt-1">
            ${analytics.backMonthVega.toFixed(2)}
            <span className="text-[10px] text-[#8b9bb4] font-normal ml-1">/ 1% IV</span>
          </div>
          <div className="text-[9px] text-[#64748b]">
            Structural sensitivity to macro vol
          </div>
        </div>

        <div className="bg-[#090d16] border border-[#1e2638] rounded p-2.5 flex flex-col justify-between">
          <div className="text-[9.5px] text-[#8b9bb4] uppercase font-bold flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-[#00e5ff]" />
            <span>Term Multiplier</span>
          </div>
          <div className="text-base sm:text-lg font-black font-mono text-[#00e5ff] mt-1">
            {analytics.vegaSlopeRatio}x
          </div>
          <div className="text-[9px] text-[#64748b]">
            Ratio of back-month to front-month
          </div>
        </div>

        <div className="bg-[#090d16] border border-[#1e2638] rounded p-2.5 flex flex-col justify-between">
          <div className="text-[9.5px] text-[#8b9bb4] uppercase font-bold flex items-center gap-1">
            <Flame className="w-3 h-3 text-[#ffd600]" />
            <span>Surface Peak Vega</span>
          </div>
          <div className="text-base sm:text-lg font-black font-mono text-[#ffd600] mt-1">
            ${matrixData.maxVega.toFixed(2)}
          </div>
          <div className="text-[9px] text-[#64748b]">
            Maximum Vega across all strikes &amp; tenors
          </div>
        </div>

        <div className="bg-[#090d16] border border-[#1e2638] rounded p-2.5 flex flex-col justify-between">
          <div className="text-[9.5px] text-[#8b9bb4] uppercase font-bold flex items-center gap-1">
            <DollarSign className="w-3 h-3 text-[#00e676]" />
            <span>Portfolio Net Vega</span>
          </div>
          <div className="text-base sm:text-lg font-black font-mono text-[#00e676] mt-1">
            {totalPortfolioNetVega >= 0 ? `+$${totalPortfolioNetVega.toFixed(2)}` : `-$${Math.abs(totalPortfolioNetVega).toFixed(2)}`}
          </div>
          <div className="text-[9px] text-[#64748b]">
            Weighted: ${totalPortfolioWeightedVega.toFixed(2)} (D-Vega)
          </div>
        </div>
      </div>

      {/* 3. Primary View Mode Switcher Pills */}
      <div className="bg-[#0a0f1c] border border-[#1e2638] rounded-lg p-2 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 bg-[#070a12] p-1 border border-[#1a2336] rounded">
          <button
            onClick={() => {
              playKeyClick();
              setViewMode('matrix');
            }}
            className={`px-3 py-1.5 rounded text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
              viewMode === 'matrix'
                ? 'bg-[#ff9900] text-black shadow-[0_0_12px_rgba(255,153,0,0.4)]'
                : 'text-[#8b9bb4] hover:text-white hover:bg-[#141b28]'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span>ALL EXPIRATIONS × ALL STRIKES MATRIX (HEATMAP)</span>
          </button>

          <button
            onClick={() => {
              playKeyClick();
              setViewMode('blotter');
            }}
            className={`px-3 py-1.5 rounded text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
              viewMode === 'blotter'
                ? 'bg-[#00e5ff] text-black shadow-[0_0_12px_rgba(0,229,255,0.4)]'
                : 'text-[#8b9bb4] hover:text-white hover:bg-[#141b28]'
            }`}
          >
            <Table className="w-3.5 h-3.5" />
            <span>MULTI-EXPIRATION STRIKE BLOTTER</span>
          </button>

          <button
            onClick={() => {
              playKeyClick();
              setViewMode('curve');
            }}
            className={`px-3 py-1.5 rounded text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
              viewMode === 'curve'
                ? 'bg-[#a855f7] text-white shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                : 'text-[#8b9bb4] hover:text-white hover:bg-[#141b28]'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>TERM STRUCTURE CURVE &amp; REGIME</span>
          </button>
        </div>

        {/* View Mode Controls: Metric Selector & Strike Search */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Metric Selector */}
          <div className="flex items-center gap-1 bg-[#101726] px-2 py-1 rounded border border-[#1e2a44]">
            <span className="text-[10px] font-bold text-[#8b9bb4]">METRIC:</span>
            <select
              value={selectedMetric}
              onChange={(e) => {
                playKeyClick();
                setSelectedMetric(e.target.value as any);
              }}
              className="bg-transparent text-[#ff9900] font-mono font-bold text-xs outline-none cursor-pointer"
            >
              <option value="vega" className="bg-[#0b101c] text-white">Vega ($ / Contract)</option>
              <option value="weighted" className="bg-[#0b101c] text-white">30D Weighted Vega (D-Vega)</option>
              <option value="vomma" className="bg-[#0b101c] text-white">Vomma (Volga dVega/dIV)</option>
              <option value="veta" className="bg-[#0b101c] text-white">Veta (Daily Decay dVega/dt)</option>
              <option value="notional" className="bg-[#0b101c] text-white">Open Interest Notional Vega</option>
              <option value="elasticity" className="bg-[#0b101c] text-white">Vega Elasticity (% per $1)</option>
            </select>
          </div>

          {/* Strike Range Selector */}
          <div className="flex items-center gap-1 bg-[#101726] px-2 py-1 rounded border border-[#1e2a44]">
            <Filter className="w-3 h-3 text-[#38bdf8]" />
            <select
              value={strikeRange}
              onChange={(e) => {
                playKeyClick();
                setStrikeRange(e.target.value as any);
              }}
              className="bg-transparent text-[#38bdf8] font-mono font-bold text-xs outline-none cursor-pointer"
            >
              <option value="all" className="bg-[#0b101c] text-white">All Strikes ({matrixData.strikes.length})</option>
              <option value="5" className="bg-[#0b101c] text-white">ATM ± 5%</option>
              <option value="10" className="bg-[#0b101c] text-white">ATM ± 10%</option>
              <option value="20" className="bg-[#0b101c] text-white">ATM ± 20%</option>
              <option value="puts" className="bg-[#0b101c] text-white">OTM Puts (&le; Spot)</option>
              <option value="calls" className="bg-[#0b101c] text-white">OTM Calls (&ge; Spot)</option>
            </select>
          </div>

          {/* Quick Search */}
          <div className="flex items-center gap-1 bg-[#101726] px-2 py-1 rounded border border-[#1e2a44]">
            <Search className="w-3 h-3 text-[#8b9bb4]" />
            <input
              type="text"
              placeholder="Filter Strike..."
              value={strikeSearch}
              onChange={(e) => setStrikeSearch(e.target.value)}
              className="bg-transparent text-white font-mono text-xs w-20 outline-none placeholder:text-[#64748b]"
            />
            {strikeSearch && (
              <button
                onClick={() => setStrikeSearch('')}
                className="text-[#8b9bb4] hover:text-white text-[10px]"
              >
                &times;
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 4. VIEW MODE 1: ALL EXPIRATIONS × ALL STRIKES 2D MATRIX (HEATMAP) */}
      {viewMode === 'matrix' && (
        <div className="border border-[#1e2638] rounded-lg overflow-hidden flex flex-col bg-[#080d18]">
          <div className="bg-[#0d1424] px-4 py-2.5 border-b border-[#1e2638] flex flex-wrap items-center justify-between gap-3 font-bold text-white text-xs">
            <div className="flex items-center gap-2">
              <Grid className="w-4 h-4 text-[#ff9900]" />
              <span className="uppercase tracking-wide">
                2D VEGA SURFACE MATRIX: {filteredStrikes.length} STRIKES &times; {matrixData.expirations.length} EXPIRATIONS
              </span>
            </div>

            {/* Heatmap Legend */}
            <div className="flex items-center gap-3 text-[10px] font-mono text-[#8b9bb4]">
              <span>LOW VEGA</span>
              <div className="flex items-center h-2 w-28 rounded bg-gradient-to-r from-[#0284c7]/20 via-[#00e5ff]/50 to-[#ff9900]" />
              <span className="text-[#ff9900] font-bold">PEAK VEGA (${matrixData.maxVega.toFixed(1)})</span>
            </div>
          </div>

          {/* The Scrollable Matrix Table */}
          <div className="overflow-x-auto max-h-[580px] relative">
            <table className="w-full text-left border-collapse text-xs select-none">
              <thead className="sticky top-0 z-20 bg-[#060a12] border-b border-[#1e2638] shadow-sm">
                <tr className="text-[#8b9bb4] uppercase text-[10px] font-mono">
                  {/* Sticky Strike Header */}
                  <th className="sticky left-0 z-30 bg-[#060a12] py-2.5 px-3 border-r border-[#1e2638] w-24">
                    Strike ($)
                  </th>
                  <th className="sticky left-24 z-30 bg-[#060a12] py-2.5 px-2.5 border-r border-[#1e2638] w-20 text-right">
                    Moneyness
                  </th>

                  {/* Expiration Columns */}
                  {matrixData.expirations.map((exp) => (
                    <th
                      key={exp.dte}
                      className="py-2.5 px-2 text-center min-w-[76px] border-r border-[#151f33] hover:bg-[#101726] transition-colors cursor-pointer"
                      onClick={() => {
                        playKeyClick();
                        if (onSelectDte) onSelectDte(exp.dte);
                      }}
                      title={`${exp.month} ${exp.formattedDate} (${exp.dte} Days). Click to filter tenor.`}
                    >
                      <div className="text-white font-bold">{exp.month}</div>
                      <div className="text-[9px] text-[#38bdf8] font-bold">{exp.dte}D</div>
                      <div className="text-[8px] text-[#64748b]">ATM: ${exp.atmVega.toFixed(0)}</div>
                    </th>
                  ))}
                </tr>
              </thead>

              <tbody className="divide-y divide-[#101726] font-mono text-[11px]">
                {filteredStrikes.map((strike) => {
                  const moneyness = Number(((strike / ticker.price) * 100).toFixed(1));
                  const isAtm = Math.abs(strike - ticker.price) / ticker.price < 0.015;

                  return (
                    <tr
                      key={strike}
                      className={`hover:bg-[#0f172a]/60 transition-colors ${
                        isAtm ? 'bg-[#ff9900]/10 font-bold' : ''
                      }`}
                    >
                      {/* Sticky Strike Column */}
                      <td
                        className={`sticky left-0 z-10 py-1.5 px-3 border-r border-[#1e2638] font-bold ${
                          isAtm
                            ? 'bg-[#1a1708] text-[#ff9900] border-l-2 border-l-[#ff9900]'
                            : strike < ticker.price
                            ? 'bg-[#080d18] text-[#ef4444]'
                            : 'bg-[#080d18] text-[#00e676]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span>${strike.toFixed(1)}</span>
                          {isAtm && <span className="text-[8px] px-1 rounded bg-[#ff9900] text-black font-black">ATM</span>}
                        </div>
                      </td>

                      {/* Sticky Moneyness Column */}
                      <td className="sticky left-24 z-10 bg-[#080d18] py-1.5 px-2.5 border-r border-[#1e2638] text-right text-[#8b9bb4]">
                        {moneyness}%
                      </td>

                      {/* Vega Cells for Each Expiration */}
                      {matrixData.expirations.map((exp) => {
                        const cell = matrixData.matrix[strike]?.[exp.dte];
                        const cellVal = cell ? cell.avgVega : 0;
                        const isSelected = selectedCell && selectedCell.strike === strike && selectedCell.dte === exp.dte;
                        const cellColorClass = getCellColor(cellVal, matrixData.maxVega, isAtm);

                        return (
                          <td
                            key={exp.dte}
                            onClick={() => {
                              playKeyClick();
                              if (cell) setSelectedCell(cell);
                            }}
                            className={`py-1.5 px-2 text-center border-r border-[#121929] cursor-pointer transition-all ${cellColorClass} ${
                              isSelected ? 'ring-2 ring-[#ffd600] z-10' : 'hover:scale-105'
                            }`}
                            title={`Strike: $${strike} | ${exp.month} (${exp.dte}D)\nVega: $${cell?.avgVega} / contract\nWeighted: $${cell?.weightedVega30}\nVomma: +${cell?.vomma}\nClick to inspect details`}
                          >
                            {formatCellValue(cell)}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Matrix Footer Note */}
          <div className="bg-[#060a12] p-2.5 border-t border-[#1e2638] flex flex-wrap items-center justify-between gap-3 text-[10px] text-[#8b9bb4] font-mono">
            <span>
              Tip: Values show <strong className="text-white">{selectedMetric.toUpperCase()}</strong>. Hover or click any cell to inspect Greeks and launch trade builder.
            </span>
            <span>
              Showing {filteredStrikes.length} of {matrixData.strikes.length} available strikes across {matrixData.expirations.length} expirations
            </span>
          </div>
        </div>
      )}

      {/* 5. VIEW MODE 2: MULTI-EXPIRATION STRIKE BLOTTER */}
      {viewMode === 'blotter' && (
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between bg-[#0a0f1c] border border-[#1e2638] rounded p-2.5">
            <div className="flex items-center gap-2 font-bold text-white text-xs">
              <Table className="w-4 h-4 text-[#00e5ff]" />
              <span>HIERARCHICAL MULTI-EXPIRATION STRIKE BLOTTER</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => toggleAllTenors(true)}
                className="px-2.5 py-1 bg-[#141b28] hover:bg-[#1e293b] text-[#00e5ff] border border-[#00e5ff]/30 rounded text-[10px] font-bold cursor-pointer"
              >
                + Expand All Tenors
              </button>
              <button
                onClick={() => toggleAllTenors(false)}
                className="px-2.5 py-1 bg-[#141b28] hover:bg-[#1e293b] text-[#8b9bb4] hover:text-white border border-[#222d44] rounded text-[10px] font-bold cursor-pointer"
              >
                - Collapse All
              </button>
            </div>
          </div>

          {/* Tenor Accordions */}
          <div className="flex flex-col gap-2.5">
            {matrixData.expirations.map((exp) => {
              const isExpanded = !!expandedTenors[exp.dte];
              const strikesForTenor = filteredStrikes;

              return (
                <div
                  key={exp.dte}
                  className="bg-[#080d18] border border-[#1e2638] rounded-lg overflow-hidden transition-all shadow-sm"
                >
                  {/* Tenor Accordion Header */}
                  <div
                    onClick={() => {
                      playKeyClick();
                      setExpandedTenors((prev) => ({ ...prev, [exp.dte]: !prev[exp.dte] }));
                    }}
                    className="bg-[#0d1424] hover:bg-[#121c32] p-3 flex flex-wrap items-center justify-between gap-3 cursor-pointer select-none transition-colors border-b border-[#1e2638]"
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-[#38bdf8]">
                        {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-black text-white text-sm">
                          {exp.month} EXPIRATION ({exp.formattedDate})
                        </span>
                        <span className="px-2 py-0.5 rounded bg-[#00e5ff]/15 text-[#00e5ff] border border-[#00e5ff]/30 font-mono text-[10px] font-bold">
                          {exp.dte} DTE
                        </span>
                        <span className="text-[11px] text-[#8b9bb4]">
                          ATM Strike: <strong className="text-white font-mono">${exp.atmStrike.toFixed(1)}</strong>
                        </span>
                        <span className="text-[11px] text-[#8b9bb4]">
                          ATM Vega: <strong className="text-[#ff9900] font-mono">${exp.atmVega.toFixed(2)}</strong>
                        </span>
                      </div>
                    </div>

                    <div className="text-[11px] font-mono text-[#8b9bb4]">
                      {isExpanded ? 'Click to collapse' : `Click to view ${strikesForTenor.length} strikes`}
                    </div>
                  </div>

                  {/* Expanded Strikes Table */}
                  {isExpanded && (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse text-xs select-none">
                        <thead>
                          <tr className="bg-[#060a12] border-b border-[#1e2638] text-[#8b9bb4] uppercase text-[10px] font-mono">
                            <th className="py-2 px-3">Strike ($)</th>
                            <th className="py-2 px-3 text-right">Moneyness</th>
                            <th className="py-2 px-3 text-right text-[#00e5ff]">Call Vega ($)</th>
                            <th className="py-2 px-3 text-right text-[#00e5ff]">Put Vega ($)</th>
                            <th className="py-2 px-3 text-right text-[#ff9900]">Avg Vega / Contract</th>
                            <th className="py-2 px-3 text-right text-[#ffd600]">30D D-Vega</th>
                            <th className="py-2 px-3 text-right text-[#a855f7]">Vomma (Volga)</th>
                            <th className="py-2 px-3 text-right text-[#ff334b]">Veta (Decay/d)</th>
                            <th className="py-2 px-3 text-right text-slate-300">Call / Put IV</th>
                            <th className="py-2 px-3 text-right text-[#8b9bb4]">Open Interest</th>
                            <th className="py-2 px-3 text-center">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-[#121929] font-mono text-[11px]">
                          {strikesForTenor.map((strike) => {
                            const cell = matrixData.matrix[strike]?.[exp.dte];
                            if (!cell) return null;
                            const isAtm = cell.isATM;

                            return (
                              <tr
                                key={strike}
                                onClick={() => {
                                  playKeyClick();
                                  setSelectedCell(cell);
                                }}
                                className={`hover:bg-[#121929] cursor-pointer transition-colors ${
                                  isAtm ? 'bg-[#ff9900]/10 font-bold' : ''
                                }`}
                              >
                                <td className="py-2 px-3 font-bold text-white">
                                  <div className="flex items-center gap-1.5">
                                    <span className={strike < ticker.price ? 'text-[#ef4444]' : 'text-[#00e676]'}>
                                      ${strike.toFixed(1)}
                                    </span>
                                    {isAtm && (
                                      <span className="text-[8px] px-1 bg-[#ff9900] text-black font-black rounded">
                                        ATM
                                      </span>
                                    )}
                                  </div>
                                </td>
                                <td className="py-2 px-3 text-right text-[#8b9bb4]">
                                  {cell.moneynessPct}%
                                </td>
                                <td className="py-2 px-3 text-right text-[#00e5ff] font-bold">
                                  ${cell.callVega.toFixed(2)}
                                </td>
                                <td className="py-2 px-3 text-right text-[#00e5ff] font-bold">
                                  ${cell.putVega.toFixed(2)}
                                </td>
                                <td className="py-2 px-3 text-right text-[#ff9900] font-black">
                                  ${cell.avgVega.toFixed(2)}
                                </td>
                                <td className="py-2 px-3 text-right text-[#ffd600] font-bold">
                                  ${cell.weightedVega30.toFixed(2)}
                                </td>
                                <td className="py-2 px-3 text-right text-[#a855f7]">
                                  +{cell.vomma.toFixed(3)}
                                </td>
                                <td className="py-2 px-3 text-right text-[#ff334b]">
                                  {cell.veta.toFixed(3)}
                                </td>
                                <td className="py-2 px-3 text-right text-slate-300">
                                  {(cell.callIV * 100).toFixed(1)}% / {(cell.putIV * 100).toFixed(1)}%
                                </td>
                                <td className="py-2 px-3 text-right text-[#8b9bb4]">
                                  {cell.totalOI.toLocaleString()}
                                </td>
                                <td className="py-2 px-3 text-center">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      playKeyClick();
                                      if (onApplyStrategyTemplate) {
                                        onApplyStrategyTemplate('call-calendar-spread');
                                      } else if (onNavigateToValuation) {
                                        onNavigateToValuation();
                                      }
                                    }}
                                    className="px-2 py-0.5 rounded bg-[#141b28] hover:bg-[#ff9900] hover:text-black text-[#ff9900] border border-[#ff9900]/40 text-[9px] font-bold transition-all cursor-pointer"
                                  >
                                    TRADE
                                  </button>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 6. VIEW MODE 3: TERM STRUCTURE CURVE & REGIME SIMULATOR */}
      {viewMode === 'curve' && (
        <div className="flex flex-col gap-4">
          {/* Curve Options Bar */}
          <div className="bg-[#0b101c] border border-[#1e2638] rounded p-3 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-bold text-white uppercase">Curve Toggles:</span>
              <button
                onClick={() => setShowAbsoluteVega((prev) => !prev)}
                className={`px-2.5 py-1 rounded text-xs font-bold border transition-colors ${
                  showAbsoluteVega
                    ? 'bg-[#ff9900] text-black border-[#ff9900]'
                    : 'bg-[#141b28] text-[#8b9bb4] border-[#222d44]'
                }`}
              >
                Absolute Vega ($)
              </button>
              <button
                onClick={() => setShowWeightedVega((prev) => !prev)}
                className={`px-2.5 py-1 rounded text-xs font-bold border transition-colors ${
                  showWeightedVega
                    ? 'bg-[#00e5ff] text-black border-[#00e5ff]'
                    : 'bg-[#141b28] text-[#8b9bb4] border-[#222d44]'
                }`}
              >
                30D Weighted Vega (D-Vega)
              </button>
              <button
                onClick={() => setShow25DeltaSkew((prev) => !prev)}
                className={`px-2.5 py-1 rounded text-xs font-bold border transition-colors ${
                  show25DeltaSkew
                    ? 'bg-[#a855f7] text-white border-[#a855f7]'
                    : 'bg-[#141b28] text-[#8b9bb4] border-[#222d44]'
                }`}
              >
                25Δ Call/Put Vega Skew
              </button>
            </div>
          </div>

          {/* SVG Chart */}
          <div className="bg-[#090d16] border border-[#1e2638] rounded-lg p-3 overflow-x-auto">
            <svg viewBox={`0 0 ${svgWidth} ${svgHeight}`} className="w-full h-auto min-w-[700px]">
              {/* Grid Lines */}
              {[0.25, 0.5, 0.75, 1.0].map((frac) => {
                const y = getY(yMax * frac);
                return (
                  <g key={frac}>
                    <line x1={padding.left} y1={y} x2={svgWidth - padding.right} y2={y} stroke="#1b2537" strokeDasharray="3 3" />
                    <text x={padding.left - 8} y={y + 3} fill="#64748b" fontSize="9" textAnchor="end" fontFamily="monospace">
                      ${(yMax * frac).toFixed(0)}
                    </text>
                  </g>
                );
              })}

              {/* Curves */}
              {showAbsoluteVega && <path d={absoluteVegaPath} fill="none" stroke="#ff9900" strokeWidth="2.5" />}
              {showWeightedVega && <path d={weightedVegaPath} fill="none" stroke="#00e5ff" strokeWidth="2" strokeDasharray="4 4" />}
              {show25DeltaSkew && (
                <>
                  <path d={call25Path} fill="none" stroke="#22c55e" strokeWidth="1.5" />
                  <path d={put25Path} fill="none" stroke="#ef4444" strokeWidth="1.5" />
                </>
              )}

              {/* Data Nodes */}
              {points.map((p) => {
                const x = getX(p.dte);
                const y = getY(p.atmVega100);
                const isSelected = selectedDte === p.dte;

                return (
                  <g
                    key={p.dte}
                    onMouseEnter={() => setHoveredPoint(p)}
                    onMouseLeave={() => setHoveredPoint(null)}
                    onClick={() => {
                      playKeyClick();
                      if (onSelectDte) onSelectDte(p.dte);
                    }}
                    className="cursor-pointer"
                  >
                    <circle cx={x} cy={y} r={isSelected ? 6 : 4} fill={isSelected ? '#ffd600' : '#ff9900'} stroke="#000" strokeWidth="1.5" />
                    <text x={x} y={svgHeight - 15} fill="#8b9bb4" fontSize="9" textAnchor="middle" fontFamily="monospace">
                      {p.dte}D
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>
      )}

      {/* 7. Selected Cell Deep Inspector Modal / HUD */}
      {selectedCell && (
        <div className="bg-[#0b101d] border border-[#ff9900]/50 rounded-lg p-3.5 flex flex-col gap-3 shadow-xl animate-in slide-in-from-bottom-2 duration-150">
          <div className="flex items-center justify-between border-b border-[#1e2a44] pb-2">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#ff9900] animate-pulse" />
              <span className="font-black text-white text-xs">
                STRIKE INSPECTOR: ${selectedCell.strike.toFixed(1)} · {selectedCell.month} ({selectedCell.dte} DTE)
              </span>
              <span className="text-[10px] text-[#8b9bb4]">
                Moneyness: <strong className="text-white">{selectedCell.moneynessPct}%</strong>
              </span>
            </div>

            <button
              onClick={() => setSelectedCell(null)}
              className="text-[#8b9bb4] hover:text-white p-1 rounded hover:bg-[#141b28] cursor-pointer"
            >
              &times;
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2 text-xs font-mono">
            <div className="bg-[#070a12] p-2 rounded border border-[#1e2a44]">
              <span className="text-[9px] text-[#8b9bb4] block uppercase">Avg Contract Vega</span>
              <span className="text-sm font-black text-[#ff9900]">${selectedCell.avgVega.toFixed(2)}</span>
            </div>

            <div className="bg-[#070a12] p-2 rounded border border-[#1e2a44]">
              <span className="text-[9px] text-[#8b9bb4] block uppercase">30D Weighted Vega</span>
              <span className="text-sm font-black text-[#00e5ff]">${selectedCell.weightedVega30.toFixed(2)}</span>
            </div>

            <div className="bg-[#070a12] p-2 rounded border border-[#1e2a44]">
              <span className="text-[9px] text-[#8b9bb4] block uppercase">Vomma (Volga)</span>
              <span className="text-sm font-bold text-[#a855f7]">+{selectedCell.vomma.toFixed(3)}</span>
            </div>

            <div className="bg-[#070a12] p-2 rounded border border-[#1e2a44]">
              <span className="text-[9px] text-[#8b9bb4] block uppercase">Veta (Decay/d)</span>
              <span className="text-sm font-bold text-[#ff334b]">{selectedCell.veta.toFixed(3)}</span>
            </div>

            <div className="bg-[#070a12] p-2 rounded border border-[#1e2a44]">
              <span className="text-[9px] text-[#8b9bb4] block uppercase">Call / Put IV</span>
              <span className="text-xs font-bold text-white">
                {(selectedCell.callIV * 100).toFixed(1)}% / {(selectedCell.putIV * 100).toFixed(1)}%
              </span>
            </div>

            <div className="bg-[#070a12] p-2 rounded border border-[#1e2a44]">
              <span className="text-[9px] text-[#8b9bb4] block uppercase">Open Interest</span>
              <span className="text-xs font-bold text-[#cbd5e1]">{selectedCell.totalOI.toLocaleString()}</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-[#1e2a44]">
            <span className="text-[10px] text-[#8b9bb4]">
              Call Quote: Bid ${selectedCell.callBid.toFixed(2)} / Ask ${selectedCell.callAsk.toFixed(2)} · Put Quote: Bid ${selectedCell.putBid.toFixed(2)} / Ask ${selectedCell.putAsk.toFixed(2)}
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  playKeyClick();
                  if (onApplyStrategyTemplate) onApplyStrategyTemplate('call-calendar-spread');
                  else if (onNavigateToValuation) onNavigateToValuation();
                }}
                className="px-3 py-1 bg-[#ff9900] hover:bg-[#ffaa22] text-black font-black text-xs rounded transition-all shadow-sm cursor-pointer"
              >
                TRADE CALENDAR WITH THIS STRIKE
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. Institutional Options Quantitative Derivatives Note */}
      <div className="bg-[#070b14] border border-[#1e2638] rounded-lg p-3.5 flex flex-col gap-2.5 text-xs text-[#8b9bb4]">
        <div className="flex items-center gap-2 font-bold text-white text-xs border-b border-[#1e2638] pb-1.5">
          <Info className="w-4 h-4 text-[#00e5ff]" />
          <span>QUANTITATIVE DERIVATIVES DESK NOTE: FULL VEGA SURFACE DYNAMICS</span>
        </div>
        <p className="leading-relaxed text-[11px]">
          In the Black-Scholes framework, Vega reaches its theoretical maximum at exactly the At-The-Money (ATM) strike where moneyness S/K &approx; 1. Across expirations, absolute Vega expands with &radic;T (square root of time to expiry), which is why back-month LEAPS options possess significantly higher Vega sensitivity than weekly tenors. Traders use this 2D surface to locate vol mispricings, structure calendar spreads (capturing theta decay while balancing Vega risk), and hedge net portfolio Vega exposure.
        </p>
      </div>
    </div>
  );
};

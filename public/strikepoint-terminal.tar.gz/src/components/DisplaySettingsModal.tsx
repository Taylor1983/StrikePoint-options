import React from 'react';
import {
  X,
  Sliders,
  ZoomIn,
  ZoomOut,
  Maximize,
  Minimize,
  Smartphone,
  Tablet,
  Monitor,
  Sparkles,
  RotateCcw,
  Check,
  PanelLeftClose,
  PanelLeftOpen,
  Eye,
  Layers,
  ArrowRight,
  Type,
  Sun,
  Tv,
  MonitorSmartphone,
} from 'lucide-react';
import { playKeyClick, playExecutionChime } from '../utils/terminalSound';

export type DisplayDensity = 'compact' | 'standard' | 'touch';
export type TextLegibility = 'standard' | 'large' | 'xlarge';
export type ContrastMode = 'standard' | 'high-contrast';

export interface DisplaySettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  scale: number;
  onScaleChange: (newScale: number) => void;
  density: DisplayDensity;
  onDensityChange: (newDensity: DisplayDensity) => void;
  isSidebarOpen: boolean;
  onToggleSidebar: () => void;
  onFitToScreen: () => void;
  onResetDefaults: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  textLegibility?: TextLegibility;
  onTextLegibilityChange?: (legibility: TextLegibility) => void;
  contrastMode?: ContrastMode;
  onContrastModeChange?: (mode: ContrastMode) => void;
}

export const DisplaySettingsModal: React.FC<DisplaySettingsModalProps> = ({
  isOpen,
  onClose,
  scale,
  onScaleChange,
  density,
  onDensityChange,
  isSidebarOpen,
  onToggleSidebar,
  onFitToScreen,
  onResetDefaults,
  isFullscreen,
  onToggleFullscreen,
  textLegibility = 'standard',
  onTextLegibilityChange,
  contrastMode = 'standard',
  onContrastModeChange,
}) => {
  if (!isOpen) return null;

  const SCALE_PRESETS = [
    { label: '75%', value: 0.75, desc: 'Ultra-Dense' },
    { label: '85%', value: 0.85, desc: 'Compact' },
    { label: '90%', value: 0.90, desc: 'Condensed' },
    { label: '100%', value: 1.00, desc: 'Default Standard' },
    { label: '110%', value: 1.10, desc: 'Comfortable' },
    { label: '125%', value: 1.25, desc: 'Large Touch' },
    { label: '140%', value: 1.40, desc: 'High Legibility' },
  ];

  const handleStepZoom = (delta: number) => {
    playKeyClick();
    const next = Math.min(1.5, Math.max(0.65, Number((scale + delta).toFixed(2))));
    onScaleChange(next);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#0b101c] border border-[#1e2a44] rounded-lg shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden text-slate-200 font-sans">
        {/* Modal Top Header */}
        <div className="bg-[#0e1628] border-b border-[#1e2a44] px-4 py-3 flex items-center justify-between select-none">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-[#ff9900]/10 border border-[#ff9900]/40 flex items-center justify-center text-[#ff9900]">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-white tracking-wide">
                  DISPLAY SCALING &amp; SCREEN CUSTOMIZATION
                </span>
                <span className="px-1.5 py-0.5 rounded bg-[#ff9900]/20 text-[#ff9900] border border-[#ff9900]/40 text-[9px] font-mono font-bold">
                  {Math.round(scale * 100)}% ZOOM
                </span>
              </div>
              <div className="text-[10px] text-[#8b9bb4]">
                Customize UI scaling, font sizes, touch density, and layouts for mobile, tablets, and desktops
              </div>
            </div>
          </div>

          <button
            onClick={() => {
              playKeyClick();
              onClose();
            }}
            className="p-1 rounded hover:bg-[#18243c] text-[#8b9bb4] hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 text-xs">
          {/* Quick Fit & Fullscreen Actions Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={() => {
                playExecutionChime();
                onFitToScreen();
              }}
              className="bg-[#0e1628] hover:bg-[#152038] border border-[#00d2ff]/40 rounded p-3 text-left flex items-center justify-between gap-2 transition-all group"
            >
              <div>
                <div className="flex items-center gap-1.5 font-bold text-white text-xs">
                  <Sparkles className="w-4 h-4 text-[#00d2ff]" />
                  <span>FIT TO CURRENT SCREEN</span>
                </div>
                <div className="text-[10px] text-[#8b9bb4] mt-0.5">
                  Auto-scale viewport to fit {typeof window !== 'undefined' ? `${window.innerWidth}×${window.innerHeight}` : 'screen'} perfectly
                </div>
              </div>
              <span className="text-[10px] px-2 py-1 bg-[#00d2ff]/15 text-[#00d2ff] border border-[#00d2ff]/30 rounded font-black group-hover:bg-[#00d2ff] group-hover:text-black transition-colors">
                AUTO FIT
              </span>
            </button>

            <button
              onClick={() => {
                playKeyClick();
                onToggleFullscreen();
              }}
              className="bg-[#0e1628] hover:bg-[#152038] border border-[#1e2a44] hover:border-[#ffd600]/40 rounded p-3 text-left flex items-center justify-between gap-2 transition-all group"
            >
              <div>
                <div className="flex items-center gap-1.5 font-bold text-white text-xs">
                  {isFullscreen ? (
                    <Minimize className="w-4 h-4 text-[#ffd600]" />
                  ) : (
                    <Maximize className="w-4 h-4 text-[#ffd600]" />
                  )}
                  <span>{isFullscreen ? 'EXIT FULLSCREEN' : 'TOGGLE FULLSCREEN'}</span>
                </div>
                <div className="text-[10px] text-[#8b9bb4] mt-0.5">
                  Hide browser toolbars for true terminal experience on tablet/mobile
                </div>
              </div>
              <span className="text-[10px] px-2 py-1 bg-[#ffd600]/15 text-[#ffd600] border border-[#ffd600]/30 rounded font-black group-hover:bg-[#ffd600] group-hover:text-black transition-colors">
                {isFullscreen ? 'ON' : 'OFF'}
              </span>
            </button>
          </div>

          {/* Scale / Zoom Stepper & Slider */}
          <div className="bg-[#080d18] border border-[#1e2a44] rounded p-4 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-white text-xs flex items-center gap-1.5">
                <ZoomIn className="w-3.5 h-3.5 text-[#ff9900]" />
                <span>MAGNIFICATION &amp; UI SCALE</span>
              </span>
              <div className="flex items-center gap-1 font-mono">
                <button
                  onClick={() => handleStepZoom(-0.05)}
                  className="w-7 h-7 bg-[#141b28] hover:bg-[#1e293b] text-white rounded border border-[#222d44] font-bold text-sm flex items-center justify-center transition-colors"
                  title="Zoom Out (-5%)"
                >
                  -
                </button>
                <span className="px-3 py-1 bg-[#0b101c] border border-[#ff9900]/50 rounded text-[#ff9900] font-black text-xs min-w-[58px] text-center">
                  {Math.round(scale * 100)}%
                </span>
                <button
                  onClick={() => handleStepZoom(+0.05)}
                  className="w-7 h-7 bg-[#141b28] hover:bg-[#1e293b] text-white rounded border border-[#222d44] font-bold text-sm flex items-center justify-center transition-colors"
                  title="Zoom In (+5%)"
                >
                  +
                </button>
              </div>
            </div>

            {/* Slider */}
            <div className="flex items-center gap-3">
              <span className="text-[10px] text-[#64748b] font-mono">65%</span>
              <input
                type="range"
                min="0.65"
                max="1.50"
                step="0.05"
                value={scale}
                onChange={(e) => {
                  onScaleChange(Number(e.target.value));
                }}
                className="flex-1 accent-[#ff9900] cursor-pointer"
              />
              <span className="text-[10px] text-[#64748b] font-mono">150%</span>
            </div>

            {/* Quick Presets Pills */}
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-1.5 pt-1">
              {SCALE_PRESETS.map((p) => {
                const isSelected = Math.abs(scale - p.value) < 0.02;
                return (
                  <button
                    key={p.value}
                    onClick={() => {
                      playKeyClick();
                      onScaleChange(p.value);
                    }}
                    className={`px-2 py-1.5 rounded text-center transition-all ${
                      isSelected
                        ? 'bg-[#ff9900] text-black font-black shadow-md'
                        : 'bg-[#0e1628] hover:bg-[#18243c] text-[#8b9bb4] hover:text-white border border-[#1e2a44]'
                    }`}
                  >
                    <div className="text-xs font-mono font-bold leading-tight">{p.label}</div>
                    <div className={`text-[8.5px] truncate ${isSelected ? 'text-black/80' : 'text-[#64748b]'}`}>
                      {p.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Density & Tap Target Optimization */}
          <div className="bg-[#080d18] border border-[#1e2a44] rounded p-4 flex flex-col gap-3">
            <span className="font-extrabold text-white text-xs flex items-center gap-1.5">
              <Eye className="w-3.5 h-3.5 text-[#00e676]" />
              <span>TOUCH TARGETS &amp; TYPOGRAPHY DENSITY</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                onClick={() => {
                  playKeyClick();
                  onDensityChange('compact');
                }}
                className={`p-3 rounded border text-left flex flex-col justify-between gap-2 transition-all ${
                  density === 'compact'
                    ? 'bg-[#00e676]/10 border-[#00e676] text-white'
                    : 'bg-[#0e1628] border-[#1e2a44] text-[#8b9bb4] hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs">Compact Dense</span>
                  {density === 'compact' && <Check className="w-3.5 h-3.5 text-[#00e676]" />}
                </div>
                <p className="text-[10px] text-[#64748b] leading-tight">
                  Maximum data density. Tight table rows, 11px font for Bloomberg pros on high-res monitors.
                </p>
              </button>

              <button
                onClick={() => {
                  playKeyClick();
                  onDensityChange('standard');
                }}
                className={`p-3 rounded border text-left flex flex-col justify-between gap-2 transition-all ${
                  density === 'standard'
                    ? 'bg-[#ff9900]/10 border-[#ff9900] text-white'
                    : 'bg-[#0e1628] border-[#1e2a44] text-[#8b9bb4] hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs">Standard (Balanced)</span>
                  {density === 'standard' && <Check className="w-3.5 h-3.5 text-[#ff9900]" />}
                </div>
                <p className="text-[10px] text-[#64748b] leading-tight">
                  Balanced institutional readability for laptops and external monitors. Default terminal setting.
                </p>
              </button>

              <button
                onClick={() => {
                  playKeyClick();
                  onDensityChange('touch');
                }}
                className={`p-3 rounded border text-left flex flex-col justify-between gap-2 transition-all ${
                  density === 'touch'
                    ? 'bg-[#00d2ff]/10 border-[#00d2ff] text-white'
                    : 'bg-[#0e1628] border-[#1e2a44] text-[#8b9bb4] hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs">Touch &amp; Comfort</span>
                  {density === 'touch' && <Check className="w-3.5 h-3.5 text-[#00d2ff]" />}
                </div>
                <p className="text-[10px] text-[#64748b] leading-tight">
                  Larger fonts (13-14px), 42px+ tap targets, spacious buttons for phones, iPads, and touchscreens.
                </p>
              </button>
            </div>
          </div>

          {/* Text Legibility & Font Scale ("See It Better") */}
          <div className="bg-[#080d18] border border-[#1e2a44] rounded p-4 flex flex-col gap-3">
            <span className="font-extrabold text-white text-xs flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5 text-[#ff9900]" />
              <span>TEXT VISIBILITY &amp; FONT SCALE ("SEE IT BETTER")</span>
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <button
                onClick={() => {
                  playKeyClick();
                  if (onTextLegibilityChange) onTextLegibilityChange('standard');
                }}
                className={`p-3 rounded border text-left flex flex-col justify-between gap-1.5 transition-all ${
                  textLegibility === 'standard'
                    ? 'bg-[#ff9900]/10 border-[#ff9900] text-white'
                    : 'bg-[#0e1628] border-[#1e2a44] text-[#8b9bb4] hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs">Standard Text (100%)</span>
                  {textLegibility === 'standard' && <Check className="w-3.5 h-3.5 text-[#ff9900]" />}
                </div>
                <p className="text-[10px] text-[#64748b]">
                  Default 12px font for standard computer monitors and high density blotters.
                </p>
              </button>

              <button
                onClick={() => {
                  playExecutionChime();
                  if (onTextLegibilityChange) onTextLegibilityChange('large');
                }}
                className={`p-3 rounded border text-left flex flex-col justify-between gap-1.5 transition-all ${
                  textLegibility === 'large'
                    ? 'bg-[#00d2ff]/10 border-[#00d2ff] text-white'
                    : 'bg-[#0e1628] border-[#1e2a44] text-[#8b9bb4] hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-[#00d2ff]">Enlarged Text (+15%)</span>
                  {textLegibility === 'large' && <Check className="w-3.5 h-3.5 text-[#00d2ff]" />}
                </div>
                <p className="text-[10px] text-[#64748b]">
                  13.5px base font. Crisp &amp; readable on tablets, small laptops, and phones.
                </p>
              </button>

              <button
                onClick={() => {
                  playExecutionChime();
                  if (onTextLegibilityChange) onTextLegibilityChange('xlarge');
                }}
                className={`p-3 rounded border text-left flex flex-col justify-between gap-1.5 transition-all ${
                  textLegibility === 'xlarge'
                    ? 'bg-[#ffd600]/10 border-[#ffd600] text-white'
                    : 'bg-[#0e1628] border-[#1e2a44] text-[#8b9bb4] hover:text-white'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-[#ffd600]">Maximum Legibility (+30%)</span>
                  {textLegibility === 'xlarge' && <Check className="w-3.5 h-3.5 text-[#ffd600]" />}
                </div>
                <p className="text-[10px] text-[#64748b]">
                  15px large font with heavy weights. Maximum visibility from a distance or on phones.
                </p>
              </button>
            </div>

            {/* Contrast Mode Selector */}
            <div className="pt-2 border-t border-[#1e2a44] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sun className="w-3.5 h-3.5 text-[#ffd600]" />
                <span className="text-[11px] font-bold text-white">Ultra-High Contrast OLED Black:</span>
                <span className="text-[10px] text-[#8b9bb4] hidden sm:inline">Boosts font luminance &amp; border sharpness</span>
              </div>
              <button
                onClick={() => {
                  playKeyClick();
                  if (onContrastModeChange) {
                    onContrastModeChange(contrastMode === 'standard' ? 'high-contrast' : 'standard');
                  }
                }}
                className={`px-2.5 py-1 rounded text-[10px] font-bold border transition-colors ${
                  contrastMode === 'high-contrast'
                    ? 'bg-[#ffd600] text-black border-[#ffd600]'
                    : 'bg-[#141b28] text-[#8b9bb4] border-[#222d44] hover:text-white'
                }`}
              >
                {contrastMode === 'high-contrast' ? 'HIGH CONTRAST ON' : 'STANDARD CONTRAST'}
              </button>
            </div>
          </div>

          {/* Device Quick Presets */}
          <div className="bg-[#080d18] border border-[#1e2a44] rounded p-4 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-white text-xs flex items-center gap-1.5">
                <Monitor className="w-3.5 h-3.5 text-[#38bdf8]" />
                <span>OPTIMIZE FOR HARDWARE DEVICE &amp; SCREEN SIZE</span>
              </span>
              <span className="text-[9.5px] font-mono text-[#8b9bb4]">
                {typeof window !== 'undefined' ? `${window.innerWidth}×${window.innerHeight}px` : ''}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              {/* Phone */}
              <button
                onClick={() => {
                  playExecutionChime();
                  onScaleChange(0.80);
                  onDensityChange('touch');
                  if (onTextLegibilityChange) onTextLegibilityChange('large');
                  if (isSidebarOpen) onToggleSidebar();
                }}
                className="bg-[#0e1628] hover:bg-[#162238] border border-[#1e2a44] rounded p-2.5 text-left flex items-start gap-2 transition-colors group cursor-pointer"
              >
                <div className="w-7 h-7 rounded bg-[#38bdf8]/10 border border-[#38bdf8]/30 flex items-center justify-center text-[#38bdf8] shrink-0 mt-0.5">
                  <Smartphone className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-bold text-white text-[11px] group-hover:text-[#38bdf8] transition-colors">
                    Mobile (375-430px)
                  </div>
                  <div className="text-[9.5px] text-[#8b9bb4] mt-0.5">
                    80% scale, touch targets, hides sidebar, large text
                  </div>
                </div>
              </button>

              {/* Tablet Portrait */}
              <button
                onClick={() => {
                  playExecutionChime();
                  onScaleChange(0.88);
                  onDensityChange('touch');
                  if (onTextLegibilityChange) onTextLegibilityChange('large');
                  if (isSidebarOpen) onToggleSidebar();
                }}
                className="bg-[#0e1628] hover:bg-[#162238] border border-[#1e2a44] rounded p-2.5 text-left flex items-start gap-2 transition-colors group cursor-pointer"
              >
                <div className="w-7 h-7 rounded bg-[#ffd600]/10 border border-[#ffd600]/30 flex items-center justify-center text-[#ffd600] shrink-0 mt-0.5">
                  <Tablet className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-bold text-white text-[11px] group-hover:text-[#ffd600] transition-colors">
                    Tablet Portrait (768-834px)
                  </div>
                  <div className="text-[9.5px] text-[#8b9bb4] mt-0.5">
                    88% scale, iPad Mini/Air portrait fit
                  </div>
                </div>
              </button>

              {/* Tablet Landscape */}
              <button
                onClick={() => {
                  playExecutionChime();
                  onScaleChange(0.95);
                  onDensityChange('standard');
                }}
                className="bg-[#0e1628] hover:bg-[#162238] border border-[#1e2a44] rounded p-2.5 text-left flex items-start gap-2 transition-colors group cursor-pointer"
              >
                <div className="w-7 h-7 rounded bg-[#a855f7]/10 border border-[#a855f7]/30 flex items-center justify-center text-[#a855f7] shrink-0 mt-0.5">
                  <MonitorSmartphone className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-bold text-white text-[11px] group-hover:text-[#a855f7] transition-colors">
                    Tablet Landscape (1024-1180px)
                  </div>
                  <div className="text-[9.5px] text-[#8b9bb4] mt-0.5">
                    95% scale, iPad Pro &amp; Surface landscape
                  </div>
                </div>
              </button>

              {/* Laptop & Desktop */}
              <button
                onClick={() => {
                  playExecutionChime();
                  onScaleChange(1.0);
                  onDensityChange('standard');
                  if (!isSidebarOpen) onToggleSidebar();
                }}
                className="bg-[#0e1628] hover:bg-[#162238] border border-[#1e2a44] rounded p-2.5 text-left flex items-start gap-2 transition-colors group cursor-pointer"
              >
                <div className="w-7 h-7 rounded bg-[#00e676]/10 border border-[#00e676]/30 flex items-center justify-center text-[#00e676] shrink-0 mt-0.5">
                  <Monitor className="w-3.5 h-3.5" />
                </div>
                <div>
                  <div className="font-bold text-white text-[11px] group-hover:text-[#00e676] transition-colors">
                    Desktop / Laptop (1280px+)
                  </div>
                  <div className="text-[9.5px] text-[#8b9bb4] mt-0.5">
                    100% scale, native dual-blotter layout
                  </div>
                </div>
              </button>
            </div>
          </div>

          {/* Left Sidebar Toggle Card */}
          <div className="bg-[#080d18] border border-[#1e2a44] rounded p-3.5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              {isSidebarOpen ? (
                <PanelLeftClose className="w-4 h-4 text-[#ff9900]" />
              ) : (
                <PanelLeftOpen className="w-4 h-4 text-[#8b9bb4]" />
              )}
              <div>
                <div className="font-bold text-white text-xs">
                  LEFT WATCHLIST &amp; STRATEGY SIDEBAR
                </div>
                <div className="text-[10px] text-[#8b9bb4]">
                  {isSidebarOpen
                    ? 'Sidebar is currently VISIBLE. Collapse it to give 100% full width to charts and options matrix.'
                    : 'Sidebar is currently HIDDEN. Maximizing trading surface.'}
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                playKeyClick();
                onToggleSidebar();
              }}
              className={`px-3 py-1.5 rounded font-black text-xs border transition-all ${
                isSidebarOpen
                  ? 'bg-[#ff9900]/15 text-[#ff9900] border-[#ff9900]/40 hover:bg-[#ff9900]/25'
                  : 'bg-[#141b28] text-white border-[#222d44] hover:bg-[#1e293b]'
              }`}
            >
              {isSidebarOpen ? 'COLLAPSE SIDEBAR' : 'EXPAND SIDEBAR'}
            </button>
          </div>
        </div>

        {/* Modal Bottom Footer */}
        <div className="bg-[#0e1628] border-t border-[#1e2a44] px-4 py-3 flex items-center justify-between text-xs">
          <button
            onClick={() => {
              playExecutionChime();
              onResetDefaults();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#141b28] hover:bg-[#ff334b]/20 text-[#8b9bb4] hover:text-[#ff334b] border border-[#222d44] rounded font-bold transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET TO DEFAULTS</span>
          </button>

          <button
            onClick={() => {
              playKeyClick();
              onClose();
            }}
            className="px-4 py-1.5 bg-[#ff9900] hover:bg-[#ffaa22] text-black font-black rounded text-xs transition-colors shadow-sm"
          >
            APPLY &amp; CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};

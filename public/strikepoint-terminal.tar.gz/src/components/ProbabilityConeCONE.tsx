import React, { useState, useMemo } from 'react';
import { Ticker, TradeLeg, ExpirationOptionChain } from '../types/options';
import {
  calculateProbabilityConeSeries,
  calculateStrikeProbability,
  ProbabilityConePoint,
  StrikeProbabilityMetrics,
} from '../utils/blackScholes';
import { playKeyClick } from '../utils/terminalSound';
import {
  TrendingUp,
  Percent,
  Sliders,
  Crosshair,
  Layers,
  Calendar,
  ShieldCheck,
  Target,
  Info,
} from 'lucide-react';

interface ProbabilityConeCONEProps {
  ticker: Ticker;
  chain: ExpirationOptionChain;
  legs: TradeLeg[];
  onNavigateToBuilder: () => void;
  onNavigateToChain: () => void;
}

export const ProbabilityConeCONE: React.FC<ProbabilityConeCONEProps> = ({
  ticker,
  chain,
  legs,
  onNavigateToBuilder,
  onNavigateToChain,
}) => {
  const [coneHorizon, setConeHorizon] = useState<number>(180);
  const [volAdjustment, setVolAdjustment] = useState<number>(0); // +/- IV shift
  const [show2Sigma, setShow2Sigma] = useState<boolean>(true);
  const [show3Sigma, setShow3Sigma] = useState<boolean>(true);
  const [showLegsOverlay, setShowLegsOverlay] = useState<boolean>(true);

  // Target price calculator state
  const [calcStrike, setCalcStrike] = useState<number>(() => {
    return Number((ticker.price * 1.05).toFixed(2));
  });
  const [calcDays, setCalcDays] = useState<number>(30);
  const [hoveredConePoint, setHoveredConePoint] = useState<ProbabilityConePoint | null>(null);

  const effectiveIV = Math.max(0.05, ticker.currentIV + volAdjustment / 100);

  // Generate Cone Series
  const coneSeries = useMemo(() => {
    return calculateProbabilityConeSeries(ticker.price, effectiveIV, coneHorizon);
  }, [ticker.price, effectiveIV, coneHorizon]);

  // Compute Calculator Metrics
  const strikeMetrics: StrikeProbabilityMetrics = useMemo(() => {
    return calculateStrikeProbability(ticker.price, calcStrike, calcDays, effectiveIV);
  }, [ticker.price, calcStrike, calcDays, effectiveIV]);

  // SVG dimensions
  const svgWidth = 740;
  const svgHeight = 290;
  const padding = { top: 25, right: 75, bottom: 40, left: 65 };

  // Calculate chart boundaries
  const { minPrice, maxPrice } = useMemo(() => {
    const lastPoint = coneSeries[coneSeries.length - 1];
    const top = show3Sigma ? lastPoint.upper3Sigma : show2Sigma ? lastPoint.upper2Sigma : lastPoint.upper1Sigma;
    const btm = show3Sigma ? lastPoint.lower3Sigma : show2Sigma ? lastPoint.lower2Sigma : lastPoint.lower1Sigma;

    // Check if any strategy leg is outside
    let highest = top;
    let lowest = btm;
    if (showLegsOverlay && legs.length > 0) {
      legs.forEach((l) => {
        if (l.strike > highest) highest = l.strike;
        if (l.strike < lowest) lowest = l.strike;
      });
    }

    const range = highest - lowest;
    return {
      minPrice: Math.max(1, lowest - range * 0.08),
      maxPrice: highest + range * 0.08,
    };
  }, [coneSeries, show2Sigma, show3Sigma, showLegsOverlay, legs]);

  const getX = (days: number) => {
    return (
      padding.left +
      (days / coneHorizon) * (svgWidth - padding.left - padding.right)
    );
  };

  const getY = (price: number) => {
    return (
      svgHeight -
      padding.bottom -
      ((price - minPrice) / (maxPrice - minPrice || 1)) *
        (svgHeight - padding.top - padding.bottom)
    );
  };

  // Build SVG path areas for cones
  const path1SigmaArea = useMemo(() => {
    if (coneSeries.length === 0) return '';
    let topPath = '';
    let btmPath = '';
    coneSeries.forEach((p, idx) => {
      const x = getX(p.days).toFixed(1);
      const yTop = getY(p.upper1Sigma).toFixed(1);
      const yBtm = getY(p.lower1Sigma).toFixed(1);
      topPath += `${idx === 0 ? 'M' : 'L'} ${x} ${yTop} `;
      btmPath = `L ${x} ${yBtm} ` + btmPath;
    });
    return `${topPath} ${btmPath} Z`;
  }, [coneSeries, minPrice, maxPrice]);

  const path2SigmaArea = useMemo(() => {
    if (coneSeries.length === 0) return '';
    let topPath = '';
    let btmPath = '';
    coneSeries.forEach((p, idx) => {
      const x = getX(p.days).toFixed(1);
      const yTop = getY(p.upper2Sigma).toFixed(1);
      const yBtm = getY(p.lower2Sigma).toFixed(1);
      topPath += `${idx === 0 ? 'M' : 'L'} ${x} ${yTop} `;
      btmPath = `L ${x} ${yBtm} ` + btmPath;
    });
    return `${topPath} ${btmPath} Z`;
  }, [coneSeries, minPrice, maxPrice]);

  const path3SigmaArea = useMemo(() => {
    if (coneSeries.length === 0) return '';
    let topPath = '';
    let btmPath = '';
    coneSeries.forEach((p, idx) => {
      const x = getX(p.days).toFixed(1);
      const yTop = getY(p.upper3Sigma).toFixed(1);
      const yBtm = getY(p.lower3Sigma).toFixed(1);
      topPath += `${idx === 0 ? 'M' : 'L'} ${x} ${yTop} `;
      btmPath = `L ${x} ${yBtm} ` + btmPath;
    });
    return `${topPath} ${btmPath} Z`;
  }, [coneSeries, minPrice, maxPrice]);

  const centerDriftPath = useMemo(() => {
    if (coneSeries.length === 0) return '';
    return coneSeries.reduce((acc, p, idx) => {
      const x = getX(p.days).toFixed(1);
      const y = getY(p.expectedPrice).toFixed(1);
      return `${acc} ${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
    }, '');
  }, [coneSeries, minPrice, maxPrice]);

  // Key expirations along timeline
  const keyMilestones = [
    { label: '7D', days: 7 },
    { label: '14D', days: 14 },
    { label: '30D', days: 30 },
    { label: '60D', days: 60 },
    { label: '90D', days: 90 },
    { label: '180D', days: 180 },
  ].filter((m) => m.days <= coneHorizon);

  return (
    <div className="p-3 lg:p-5 max-w-7xl mx-auto flex flex-col gap-4 font-mono text-xs">
      {/* Screen Header Bar */}
      <div className="bg-[#07090e] border border-[#1e2638] rounded p-4 flex flex-wrap items-center justify-between gap-3 shadow-2xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[#ff9900] font-black text-sm">
              {ticker.symbol} US Equity CONE
            </span>
            <span className="text-[#8b9bb4] text-[11px]">
              // PROBABILITY OF EXPIRING & EXPECTED MOVE CONE
            </span>
            <span className="bg-[#00e676]/20 text-[#00e676] px-2 py-0.5 rounded text-[10px] font-bold">
              LOG-NORMAL BSM
            </span>
          </div>
          <div className="text-[11px] text-[#8b9bb4] mt-1 flex flex-wrap items-center gap-3">
            <span>
              Spot: <strong className="text-white">${ticker.price.toFixed(2)}</strong>
            </span>
            <span>·</span>
            <span>
              Base IV: <strong className="text-[#00d2ff]">{(effectiveIV * 100).toFixed(1)}%</strong>
            </span>
            <span>·</span>
            <span>
              1-Year 1σ Cone Range: <strong className="text-[#ffd600]">±${(ticker.price * effectiveIV).toFixed(2)}</strong>
            </span>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          {/* Horizon toggle */}
          <div className="flex items-center bg-[#0b0f1a] border border-[#1e2638] rounded p-0.5 text-[10px]">
            {[
              { label: '60D', days: 60 },
              { label: '90D', days: 90 },
              { label: '180D', days: 180 },
            ].map((h) => (
              <button
                key={h.days}
                onClick={() => {
                  playKeyClick();
                  setConeHorizon(h.days);
                }}
                className={`px-2 py-0.5 rounded font-bold ${
                  coneHorizon === h.days ? 'bg-[#ff9900] text-black font-black' : 'text-[#8b9bb4] hover:text-white'
                }`}
              >
                {h.label}
              </button>
            ))}
          </div>

          {/* Sigma Band Toggles */}
          <button
            onClick={() => {
              playKeyClick();
              setShow2Sigma(!show2Sigma);
            }}
            className={`px-2 py-1 rounded text-[10px] font-bold border transition-colors ${
              show2Sigma
                ? 'bg-[#00d2ff]/20 text-[#00d2ff] border-[#00d2ff]/50'
                : 'bg-[#0b0f1a] text-[#8b9bb4] border-[#1e2638]'
            }`}
          >
            2σ (95.4%)
          </button>

          <button
            onClick={() => {
              playKeyClick();
              setShow3Sigma(!show3Sigma);
            }}
            className={`px-2 py-1 rounded text-[10px] font-bold border transition-colors ${
              show3Sigma
                ? 'bg-[#ffd600]/20 text-[#ffd600] border-[#ffd600]/50'
                : 'bg-[#0b0f1a] text-[#8b9bb4] border-[#1e2638]'
            }`}
          >
            3σ (99.7%)
          </button>
        </div>
      </div>

      {/* Main Grid: SVG Probability Cone (Left 8 cols) + Instant Calculator (Right 4 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left: SVG Probability Cone Diagram */}
        <div className="lg:col-span-8 bg-[#07090e] border border-[#1e2638] rounded overflow-hidden shadow-2xl flex flex-col justify-between">
          <div className="bg-[#090d16] px-4 py-2 border-b border-[#1e2638] flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <span className="font-bold text-white uppercase text-xs">
                Forward Probability Cone Envelope
              </span>
              <div className="flex items-center gap-3 text-[10px]">
                <div className="flex items-center gap-1">
                  <span className="w-2.5 h-2.5 bg-[#ff9900]/40 border border-[#ff9900] rounded-xs" />
                  <span className="text-[#e2e8f0]">1σ (68.3%)</span>
                </div>
                {show2Sigma && (
                  <div className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 bg-[#00d2ff]/20 border border-[#00d2ff] rounded-xs" />
                    <span className="text-[#8b9bb4]">2σ (95.5%)</span>
                  </div>
                )}
                {show3Sigma && (
                  <div className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 bg-[#ffd600]/10 border border-[#ffd600]/60 rounded-xs" />
                    <span className="text-[#8b9bb4]">3σ (99.7%)</span>
                  </div>
                )}
              </div>
            </div>

            {/* Hovered point readout */}
            {hoveredConePoint ? (
              <div className="text-[11px] bg-[#0c101c] px-2 py-0.5 rounded border border-[#1e2638] text-white">
                <span className="text-[#ff9900] font-bold">{hoveredConePoint.days}D</span>: ±$
                {hoveredConePoint.expectedMoveDollar.toFixed(2)} (±
                {hoveredConePoint.expectedMovePercent}%) · 1σ [${hoveredConePoint.lower1Sigma} – $
                {hoveredConePoint.upper1Sigma}]
              </div>
            ) : (
              <div className="text-[10px] text-[#64748b]">Hover over cone to inspect expected moves</div>
            )}
          </div>

          {/* SVG Viewport */}
          <div className="relative p-2 bg-[#05070a] select-none">
            <svg
              viewBox={`0 0 ${svgWidth} ${svgHeight}`}
              className="w-full h-72 cursor-crosshair select-none"
              onMouseLeave={() => setHoveredConePoint(null)}
              onMouseMove={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const mouseX = e.clientX - rect.left;
                const svgX = (mouseX / rect.width) * svgWidth;
                const ratio = Math.max(0, Math.min(1, (svgX - padding.left) / (svgWidth - padding.left - padding.right)));
                const daysAtCursor = ratio * coneHorizon;

                // Find closest point in series
                let closest = coneSeries[0];
                let minDiff = Infinity;
                coneSeries.forEach((p) => {
                  const diff = Math.abs(p.days - daysAtCursor);
                  if (diff < minDiff) {
                    minDiff = diff;
                    closest = p;
                  }
                });
                setHoveredConePoint(closest);
              }}
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const mouseX = e.clientX - rect.left;
                const mouseY = e.clientY - rect.top;
                const svgX = (mouseX / rect.width) * svgWidth;
                const svgY = (mouseY / rect.height) * svgHeight;

                const daysRatio = Math.max(0, Math.min(1, (svgX - padding.left) / (svgWidth - padding.left - padding.right)));
                const clickedDays = Math.max(1, Math.round(daysRatio * coneHorizon));

                const priceRatio = (svgHeight - padding.bottom - svgY) / (svgHeight - padding.top - padding.bottom);
                const clickedPrice = Number((minPrice + priceRatio * (maxPrice - minPrice)).toFixed(2));

                playKeyClick();
                setCalcDays(clickedDays);
                setCalcStrike(clickedPrice);
              }}
            >
              <defs>
                {/* 1 Sigma Glowing Gradient */}
                <linearGradient id="coneGrad1" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#ff9900" stopOpacity="0.45" />
                  <stop offset="100%" stopColor="#ff9900" stopOpacity="0.15" />
                </linearGradient>

                {/* 2 Sigma Gradient */}
                <linearGradient id="coneGrad2" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#00d2ff" stopOpacity="0.25" />
                  <stop offset="100%" stopColor="#00d2ff" stopOpacity="0.08" />
                </linearGradient>

                {/* 3 Sigma Gradient */}
                <linearGradient id="coneGrad3" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#ffd600" stopOpacity="0.15" />
                  <stop offset="100%" stopColor="#ffd600" stopOpacity="0.04" />
                </linearGradient>
              </defs>

              {/* Price Grid Lines */}
              {[0, 0.25, 0.5, 0.75, 1].map((pct, idx) => {
                const p = minPrice + (maxPrice - minPrice) * pct;
                const y = getY(p);
                return (
                  <g key={idx}>
                    <line
                      x1={padding.left}
                      y1={y}
                      x2={svgWidth - padding.right}
                      y2={y}
                      stroke="#141c2c"
                      strokeWidth="1"
                      strokeDasharray="2 2"
                    />
                    <text
                      x={svgWidth - padding.right + 6}
                      y={y + 3}
                      fill="#64748b"
                      fontSize="9"
                      fontFamily="JetBrains Mono"
                    >
                      ${p.toFixed(2)}
                    </text>
                  </g>
                );
              })}

              {/* Expiration Milestone Vertical Lines */}
              {keyMilestones.map((m) => {
                const x = getX(m.days);
                return (
                  <g key={m.days}>
                    <line
                      x1={x}
                      y1={padding.top}
                      x2={x}
                      y2={svgHeight - padding.bottom}
                      stroke="#1e293b"
                      strokeWidth="1"
                      strokeDasharray="3 3"
                    />
                    <text
                      x={x}
                      y={svgHeight - padding.bottom + 16}
                      fill="#8b9bb4"
                      fontSize="9"
                      fontFamily="JetBrains Mono"
                      textAnchor="middle"
                    >
                      {m.label}
                    </text>
                  </g>
                );
              })}

              {/* Outer 3-Sigma Cone (99.73%) */}
              {show3Sigma && (
                <path
                  d={path3SigmaArea}
                  fill="url(#coneGrad3)"
                  stroke="#ffd600"
                  strokeWidth="1"
                  strokeOpacity="0.5"
                  strokeDasharray="4 2"
                />
              )}

              {/* Middle 2-Sigma Cone (95.45%) */}
              {show2Sigma && (
                <path
                  d={path2SigmaArea}
                  fill="url(#coneGrad2)"
                  stroke="#00d2ff"
                  strokeWidth="1.2"
                  strokeOpacity="0.7"
                />
              )}

              {/* Inner 1-Sigma Cone (68.27%) */}
              <path
                d={path1SigmaArea}
                fill="url(#coneGrad1)"
                stroke="#ff9900"
                strokeWidth="2"
              />

              {/* Center Mean Drift Line */}
              <path
                d={centerDriftPath}
                fill="none"
                stroke="#ffffff"
                strokeWidth="1.5"
                strokeDasharray="3 3"
              />

              {/* Current Spot Price Marker */}
              {(() => {
                const ySpot = getY(ticker.price);
                return (
                  <g>
                    <circle cx={padding.left} cy={ySpot} r="4" fill="#ff9900" stroke="#ffffff" strokeWidth="1.5" />
                    <text
                      x={padding.left - 8}
                      y={ySpot + 3}
                      fill="#ff9900"
                      fontSize="10"
                      fontFamily="JetBrains Mono"
                      fontWeight="bold"
                      textAnchor="end"
                    >
                      ${ticker.price.toFixed(2)}
                    </text>
                  </g>
                );
              })()}

              {/* Active Strategy Legs Overlay */}
              {showLegsOverlay &&
                legs.map((leg) => {
                  const legY = getY(leg.strike);
                  const isStock = leg.type === 'stock';
                  const isCall = leg.type === 'call';
                  const strokeColor = isStock ? '#00d2ff' : isCall ? '#00e676' : '#ff334b';
                  const labelText = isStock
                    ? `${leg.action.toUpperCase()} 100 SH @ $${leg.strike}`
                    : `${leg.action.toUpperCase()} $${leg.strike} ${leg.type.toUpperCase()}`;

                  return (
                    <g key={leg.id}>
                      <line
                        x1={padding.left}
                        y1={legY}
                        x2={svgWidth - padding.right}
                        y2={legY}
                        stroke={strokeColor}
                        strokeWidth="1.5"
                        strokeDasharray="4 2"
                      />
                      <rect
                        x={padding.left + 5}
                        y={legY - 9}
                        width={isStock ? 130 : 85}
                        height="16"
                        fill="#0b0f1a"
                        stroke={strokeColor}
                        strokeWidth="1"
                        rx="2"
                      />
                      <text
                        x={padding.left + 8}
                        y={legY + 3}
                        fill={strokeColor}
                        fontSize="9"
                        fontFamily="JetBrains Mono"
                        fontWeight="bold"
                      >
                        {labelText}
                      </text>
                    </g>
                  );
                })}

              {/* Target Calculator Crosshair */}
              {(() => {
                const targetX = getX(calcDays);
                const targetY = getY(calcStrike);
                return (
                  <g>
                    <line
                      x1={targetX}
                      y1={padding.top}
                      x2={targetX}
                      y2={svgHeight - padding.bottom}
                      stroke="#ffd600"
                      strokeWidth="1.5"
                      strokeDasharray="2 2"
                    />
                    <line
                      x1={padding.left}
                      y1={targetY}
                      x2={svgWidth - padding.right}
                      y2={targetY}
                      stroke="#ffd600"
                      strokeWidth="1.5"
                      strokeDasharray="2 2"
                    />
                    <circle cx={targetX} cy={targetY} r="5" fill="#ffd600" stroke="#000000" strokeWidth="2" />
                  </g>
                );
              })()}
            </svg>
          </div>

          {/* Cone Timeline Summary Bar */}
          <div className="bg-[#090d16] border-t border-[#1e2638] p-2.5 flex flex-wrap items-center justify-between text-[11px] text-[#8b9bb4]">
            <div className="flex items-center gap-4">
              <span>
                30D Expected Move: <strong className="text-white">±${(ticker.price * effectiveIV * Math.sqrt(30 / 365)).toFixed(2)}</strong> (±{(effectiveIV * Math.sqrt(30 / 365) * 100).toFixed(1)}%)
              </span>
              <span>·</span>
              <span>
                90D Expected Move: <strong className="text-white">±${(ticker.price * effectiveIV * Math.sqrt(90 / 365)).toFixed(2)}</strong> (±{(effectiveIV * Math.sqrt(90 / 365) * 100).toFixed(1)}%)
              </span>
            </div>

            <div className="text-[10px] text-[#64748b]">
              Click anywhere on chart to reposition target probe
            </div>
          </div>
        </div>

        {/* Right: Instant Probability Calculator */}
        <div className="lg:col-span-4 bg-[#07090e] border border-[#1e2638] rounded overflow-hidden shadow-2xl flex flex-col justify-between p-4">
          <div className="flex items-center gap-2 border-b border-[#1e2638] pb-3 mb-3">
            <Target className="w-4 h-4 text-[#ffd600]" />
            <span className="font-bold text-white text-xs uppercase">
              Strike Probability Calculator
            </span>
          </div>

          {/* Interactive Inputs */}
          <div className="flex flex-col gap-3">
            {/* Target Strike Input */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[#8b9bb4] text-[10px] uppercase font-bold">
                <span>Target Strike Price:</span>
                <span className={calcStrike >= ticker.price ? 'text-[#00e676]' : 'text-[#ff334b]'}>
                  {calcStrike >= ticker.price ? '+' : ''}{strikeMetrics.percentMove}%
                </span>
              </div>
              <div className="flex items-center bg-[#0b0f1a] border border-[#222d44] rounded px-2 py-1">
                <span className="text-[#ff9900] font-bold mr-1">$</span>
                <input
                  type="number"
                  step="0.5"
                  value={calcStrike}
                  onChange={(e) => setCalcStrike(parseFloat(e.target.value) || ticker.price)}
                  className="bg-transparent border-none outline-none text-white font-bold w-full font-mono text-xs"
                />
              </div>
              <input
                type="range"
                min={ticker.price * 0.7}
                max={ticker.price * 1.3}
                step="0.5"
                value={calcStrike}
                onChange={(e) => setCalcStrike(parseFloat(e.target.value))}
                className="w-full accent-[#ffd600] h-1.5 bg-[#141b28] rounded cursor-pointer mt-1"
              />
            </div>

            {/* Target Days to Expiration Input */}
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[#8b9bb4] text-[10px] uppercase font-bold">
                <span>Expiration Horizon:</span>
                <span className="text-[#00d2ff] font-bold">{calcDays} Days</span>
              </div>
              <input
                type="range"
                min="1"
                max={coneHorizon}
                value={calcDays}
                onChange={(e) => setCalcDays(parseInt(e.target.value, 10))}
                className="w-full accent-[#00d2ff] h-1.5 bg-[#141b28] rounded cursor-pointer mt-1"
              />
            </div>

            {/* Probability Output Dashboard */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-[#1e2638]">
              {/* Expiring Above */}
              <div className="bg-[#0b0f1a] p-2.5 rounded border border-[#1e2638]">
                <div className="text-[10px] text-[#8b9bb4] uppercase font-bold">P(Expiring Above)</div>
                <div className="text-xl font-black text-[#00e676]">
                  {strikeMetrics.probExpiringAbove}%
                </div>
                <div className="text-[9px] text-[#64748b]">ITM Call / OTM Put</div>
              </div>

              {/* Expiring Below */}
              <div className="bg-[#0b0f1a] p-2.5 rounded border border-[#1e2638]">
                <div className="text-[10px] text-[#8b9bb4] uppercase font-bold">P(Expiring Below)</div>
                <div className="text-xl font-black text-[#ff334b]">
                  {strikeMetrics.probExpiringBelow}%
                </div>
                <div className="text-[9px] text-[#64748b]">ITM Put / OTM Call</div>
              </div>

              {/* Probability of Touch */}
              <div className="bg-[#0b0f1a] p-2.5 rounded border border-[#1e2638]">
                <div className="text-[10px] text-[#8b9bb4] uppercase font-bold">P(Touch Before Exp)</div>
                <div className="text-xl font-black text-[#ffd600]">
                  {strikeMetrics.probOfTouch}%
                </div>
                <div className="text-[9px] text-[#64748b]">Intraday boundary breach</div>
              </div>

              {/* Distance in Sigma */}
              <div className="bg-[#0b0f1a] p-2.5 rounded border border-[#1e2638]">
                <div className="text-[10px] text-[#8b9bb4] uppercase font-bold">Distance (Z-Score)</div>
                <div className="text-xl font-black text-[#00d2ff]">
                  {strikeMetrics.standardDeviations > 0 ? '+' : ''}
                  {strikeMetrics.standardDeviations}σ
                </div>
                <div className="text-[9px] text-[#64748b]">Standard deviations</div>
              </div>
            </div>

            {/* Quick Strategy Suggestion based on Probability */}
            <div className="bg-[#0b0f1a] p-2.5 rounded border border-[#222d44] text-[11px] leading-relaxed">
              <span className="text-[#ff9900] font-bold">QUANT REGIME: </span>
              {strikeMetrics.standardDeviations >= 1.5 ? (
                <span className="text-[#cbd5e1]">
                  Strike ${calcStrike} sits beyond the 1.5σ boundary ({strikeMetrics.probExpiringAbove}% chance of being exceeded). High probability location for credit spread or Iron Condor short wings.
                </span>
              ) : strikeMetrics.standardDeviations <= -1.5 ? (
                <span className="text-[#cbd5e1]">
                  Strike ${calcStrike} sits below the -1.5σ downside boundary ({strikeMetrics.probExpiringBelow}% chance). Favorable zone for cash-secured put selling or bull put credit spreads.
                </span>
              ) : (
                <span className="text-[#cbd5e1]">
                  Strike ${calcStrike} is inside the 1σ primary expected move cone. High gamma and delta sensitivity zone.
                </span>
              )}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex gap-2 mt-4 pt-3 border-t border-[#1e2638]">
            <button
              onClick={() => {
                playKeyClick();
                onNavigateToChain();
              }}
              className="flex-1 py-1.5 bg-[#141b28] hover:bg-[#ff9900] text-[#cbd5e1] hover:text-black font-bold rounded text-center transition-colors border border-[#222d44]"
            >
              VIEW ON OMON
            </button>
            <button
              onClick={() => {
                playKeyClick();
                onNavigateToBuilder();
              }}
              className="flex-1 py-1.5 bg-[#ff9900] hover:bg-[#ffaa22] text-black font-black rounded text-center transition-all shadow-md"
            >
              PRICE IN OVME
            </button>
          </div>
        </div>
      </div>

      {/* Multi-Expiration Cone Matrix Table */}
      <div className="bg-[#07090e] border border-[#1e2638] rounded overflow-hidden shadow-2xl">
        <div className="bg-[#090d16] px-4 py-2 border-b border-[#1e2638] flex items-center justify-between text-[11px]">
          <span className="font-bold text-white uppercase">
            Institutional Expiration Probability Bands Table
          </span>
          <span className="text-[#8b9bb4]">
            Term structure calculated with Black-Scholes square root of time $\sqrt{'{'}t{'}'}$ scaling
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs select-none">
            <thead>
              <tr className="bg-[#0b0f1a] border-b border-[#1e2638] text-[#8b9bb4] uppercase text-[10px]">
                <th className="py-2.5 px-3">Horizon (DTE)</th>
                <th className="py-2.5 px-3">Target Date</th>
                <th className="py-2.5 px-3 text-right">Expected Move ($)</th>
                <th className="py-2.5 px-3 text-right">Expected Move (%)</th>
                <th className="py-2.5 px-3 text-center text-[#ff9900]">1σ Range (68.3%)</th>
                <th className="py-2.5 px-3 text-center text-[#00d2ff]">2σ Range (95.5%)</th>
                <th className="py-2.5 px-3 text-center text-[#ffd600]">3σ Range (99.7%)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#141b28]">
              {coneSeries
                .filter((p) => [7, 14, 21, 30, 45, 60, 90, 120, 180].includes(p.days))
                .map((row) => (
                  <tr key={row.days} className="hover:bg-[#121929] transition-colors">
                    <td className="py-2.5 px-3 font-bold text-white">
                      {row.days} Days to Exp
                    </td>
                    <td className="py-2.5 px-3 text-[#8b9bb4]">{row.dateStr}</td>
                    <td className="py-2.5 px-3 text-right font-black text-white">
                      ±${row.expectedMoveDollar.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-bold text-[#ffd600]">
                      ±{row.expectedMovePercent}%
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold text-[#ff9900]">
                      ${row.lower1Sigma.toFixed(2)} – ${row.upper1Sigma.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold text-[#00d2ff]">
                      ${row.lower2Sigma.toFixed(2)} – ${row.upper2Sigma.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-center font-bold text-[#ffd600]">
                      ${row.lower3Sigma.toFixed(2)} – ${row.upper3Sigma.toFixed(2)}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Ticker,
  TradeLeg,
  Order,
  Position,
  AccountState,
  ExpirationOptionChain,
  TerminalScreen,
  MacroIndexQuote,
  UnusualFlowItem,
} from './types/options';
import {
  INITIAL_TICKERS,
  INITIAL_MACRO_INDICES,
  INITIAL_FLOW_SEED,
  INITIAL_PORTFOLIO_POSITIONS,
  generateRandomFlowItem,
  generateOptionsChainForTicker,
  generateAllOptionChainsForTicker,
  EXPIRATION_PRESETS,
} from './services/marketData';
import { OptionsMatrixOMON } from './components/OptionsMatrixOMON';
import { OptionsValuationOVME } from './components/OptionsValuationOVME';
import { RiskProfileView } from './components/RiskProfileView';
import { ProbabilityConeCONE } from './components/ProbabilityConeCONE';
import { ScenarioMatrixSCEN } from './components/ScenarioMatrixSCEN';
import { UnusualFlowTapeFLOW } from './components/UnusualFlowTapeFLOW';
import { VolatilityLabView } from './components/VolatilityLabView';
import { VolatilitySurface3D } from './components/VolatilitySurface3D';
import { HistoricalImpliedVolChart } from './components/HistoricalImpliedVolChart';
import { TechnicalsChart } from './components/TechnicalsChart';
import { PositionsPortfolioView } from './components/PositionsPortfolioView';
import { PositionMonitorView } from './components/PositionMonitorView';
import { PutCallRatioView } from './components/PutCallRatioView';
import { HelpTerminalModal } from './components/HelpTerminalModal';
import { EarningsCalendarSidebar } from './components/EarningsCalendarSidebar';
import { StockTradeModal } from './components/StockTradeModal';
import { OPECMeetingsView } from './components/OPECMeetingsView';
import { TariffTrackerView } from './components/TariffTrackerView';
import { OptionsAnalysisSidebarGadget } from './components/OptionsAnalysisSidebarGadget';
import { CountryRiskModal } from './components/CountryRiskModal';
import { ExpectedMoveModal } from './components/ExpectedMoveModal';
import { StrategyCatalogModal } from './components/StrategyCatalogModal';
import { DefconLevelView } from './components/DefconLevelView';
import { CanadianAccountsModal } from './components/CanadianAccountsModal';
import { NetGammaModal } from './components/NetGammaModal';
import { GitHubSyncModal } from './components/GitHubSyncModal';
import { DisplaySettingsModal, DisplayDensity, TextLegibility, ContrastMode } from './components/DisplaySettingsModal';
import { VegaTermStructureView } from './components/VegaTermStructureView';
import { FloatingDisplayWidget } from './components/FloatingDisplayWidget';
import { INITIAL_CANADIAN_ACCOUNTS, CanadianAccount } from './services/canadianAccounts';
import { ALL_OPTIONS_STRATEGIES, generateStrategyLegs } from './services/optionsStrategies';
import { calculateNetGammaAnalysis } from './services/gammaAnalytics';
import { calculateBSM } from './utils/blackScholes';
import { playTickBlip, playKeyClick, playExecutionChime, isTerminalAudioEnabled, setTerminalAudioEnabled } from './utils/terminalSound';
import {
  Volume2,
  VolumeX,
  TrendingUp,
  TrendingDown,
  DollarSign,
  ShieldAlert,
  Github,
  Sliders,
  PanelLeftClose,
  PanelLeftOpen,
  ZoomIn,
  ZoomOut,
  Maximize,
  Minimize,
  X,
} from 'lucide-react';

const STORAGE_KEY_ACCOUNT = 'bloomberg_options_account_v1';

export default function App() {
  const [tickers, setTickers] = useState<Record<string, Ticker>>(INITIAL_TICKERS);
  const [macroIndices, setMacroIndices] = useState<MacroIndexQuote[]>(INITIAL_MACRO_INDICES);
  const [flowItems, setFlowItems] = useState<UnusualFlowItem[]>(INITIAL_FLOW_SEED);
  const [selectedSymbol, setSelectedSymbol] = useState<string>('SPY');
  const [currentScreen, setCurrentScreen] = useState<TerminalScreen>('omon');
  const [activeDte, setActiveDte] = useState<number>(17);
  const [selectedExpMonth, setSelectedExpMonth] = useState<string>('ALL');
  const [builderLegs, setBuilderLegs] = useState<TradeLeg[]>([]);
  const [isLiveTickActive, setIsLiveTickActive] = useState<boolean>(true);
  const [isHelpOpen, setIsHelpOpen] = useState<boolean>(false);
  const [isGitHubOpen, setIsGitHubOpen] = useState<boolean>(false);
  const [isDisplaySettingsOpen, setIsDisplaySettingsOpen] = useState<boolean>(false);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);

  // Screen Scaling & Display Customization State
  const [scale, setScale] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('strikepoint_ui_scale');
      if (saved) return Number(saved);
      if (typeof window !== 'undefined') {
        if (window.innerWidth < 480) return 0.82;
        if (window.innerWidth < 768) return 0.88;
        if (window.innerWidth < 1024) return 0.95;
      }
    } catch {}
    return 1.0;
  });

  const [density, setDensity] = useState<DisplayDensity>(() => {
    try {
      const saved = localStorage.getItem('strikepoint_density');
      if (saved === 'compact' || saved === 'standard' || saved === 'touch') return saved;
      if (typeof window !== 'undefined' && window.innerWidth < 768) return 'touch';
    } catch {}
    return 'standard';
  });

  const [textLegibility, setTextLegibility] = useState<TextLegibility>(() => {
    try {
      const saved = localStorage.getItem('strikepoint_text_legibility');
      if (saved === 'standard' || saved === 'large' || saved === 'xlarge') return saved;
      if (typeof window !== 'undefined' && window.innerWidth < 768) return 'large';
    } catch {}
    return 'standard';
  });

  const [contrastMode, setContrastMode] = useState<ContrastMode>(() => {
    try {
      const saved = localStorage.getItem('strikepoint_contrast_mode');
      if (saved === 'standard' || saved === 'high-contrast') return saved;
    } catch {}
    return 'standard';
  });

  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= 1024;
    }
    return true;
  });

  const [isCountryRiskOpen, setIsCountryRiskOpen] = useState<boolean>(false);
  const [isStockTradeOpen, setIsStockTradeOpen] = useState<boolean>(false);
  const [isExpectedMoveOpen, setIsExpectedMoveOpen] = useState<boolean>(false);
  const [isStrategyCatalogOpen, setIsStrategyCatalogOpen] = useState<boolean>(false);
  const [isCanadianSuiteOpen, setIsCanadianSuiteOpen] = useState<boolean>(false);
  const [isNetGammaOpen, setIsNetGammaOpen] = useState<boolean>(false);
  const [canadianAccounts, setCanadianAccounts] = useState<CanadianAccount[]>(INITIAL_CANADIAN_ACCOUNTS);
  const [activeCanadianAccountId, setActiveCanadianAccountId] = useState<string>('act-tfsa');
  const [watchlistCategory, setWatchlistCategory] = useState<'all' | 'equity' | 'future'>('all');
  const [commandInput, setCommandInput] = useState<string>('SPY US Equity OMON');
  const [isAudioOn, setIsAudioOn] = useState<boolean>(true);
  const [clockTime, setClockTime] = useState({ est: '', utc: '' });

  // Initialize Account from LocalStorage or default
  const [account, setAccount] = useState<AccountState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ACCOUNT);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && Array.isArray(parsed.positions) && parsed.positions.length > 0) {
          return parsed;
        }
        // If saved account had no positions, seed initial stock & futures positions
        return {
          ...parsed,
          positions: INITIAL_PORTFOLIO_POSITIONS,
        };
      }
    } catch {
      // fallback
    }
    return {
      cashBalance: 100000.0,
      startingBalance: 100000.0,
      realizedPnL: 0,
      positions: INITIAL_PORTFOLIO_POSITIONS,
      orders: [],
    };
  });

  // Save account changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_ACCOUNT, JSON.stringify(account));
    } catch {
      // ignore
    }
  }, [account]);

  // Apply scale and density to root document and localStorage
  useEffect(() => {
    try {
      document.documentElement.style.setProperty('--ui-scale', String(scale));
      localStorage.setItem('strikepoint_ui_scale', String(scale));
    } catch {}
  }, [scale]);

  useEffect(() => {
    try {
      document.body.classList.remove('density-compact', 'density-touch');
      if (density !== 'standard') {
        document.body.classList.add(`density-${density}`);
      }
      localStorage.setItem('strikepoint_density', density);
    } catch {}
  }, [density]);

  // Apply text legibility (font scaling) to body class
  useEffect(() => {
    try {
      document.body.classList.remove('font-large', 'font-xlarge');
      if (textLegibility === 'large') document.body.classList.add('font-large');
      if (textLegibility === 'xlarge') document.body.classList.add('font-xlarge');
      localStorage.setItem('strikepoint_text_legibility', textLegibility);
    } catch {}
  }, [textLegibility]);

  // Apply high contrast OLED black mode
  useEffect(() => {
    try {
      document.body.classList.remove('high-contrast');
      if (contrastMode === 'high-contrast') document.body.classList.add('high-contrast');
      localStorage.setItem('strikepoint_contrast_mode', contrastMode);
    } catch {}
  }, [contrastMode]);

  // Fullscreen change listener
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const handleStepZoom = (delta: number) => {
    playKeyClick();
    setScale((prev) => Math.min(1.5, Math.max(0.65, Number((prev + delta).toFixed(2)))));
  };

  const handleFitToScreen = () => {
    if (typeof window === 'undefined') return;
    const w = window.innerWidth;
    let target = 1.0;
    if (w < 380) target = 0.78;
    else if (w < 480) target = 0.82;
    else if (w < 768) target = 0.88;
    else if (w < 1024) target = 0.95;
    else if (w < 1440) target = 1.0;
    else target = 1.05;

    setScale(target);
    if (w < 768) {
      setDensity('touch');
      setIsSidebarOpen(false);
    }
  };

  const handleResetDefaults = () => {
    setScale(1.0);
    setDensity('standard');
    setTextLegibility('standard');
    setContrastMode('standard');
    setIsSidebarOpen(typeof window !== 'undefined' ? window.innerWidth >= 1024 : true);
  };

  const handleToggleFullscreen = () => {
    try {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(() => {});
      } else {
        document.exitFullscreen().catch(() => {});
      }
    } catch {}
  };

  // Update terminal clock every second
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const utcStr = now.toUTCString().split(' ')[4] + ' UTC';
      const estStr = now.toLocaleTimeString('en-US', {
        timeZone: 'America/New_York',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      }) + ' EST';
      setClockTime({ utc: utcStr, est: estStr });
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleAudioToggle = () => {
    const next = !isAudioOn;
    setIsAudioOn(next);
    setTerminalAudioEnabled(next);
    if (next) playKeyClick();
  };

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    playKeyClick();
    const trimmed = commandInput.trim().toUpperCase();
    if (!trimmed) return;

    if (trimmed.includes('OMON')) setCurrentScreen('omon');
    else if (trimmed.includes('OVME') || trimmed.includes('CALC') || trimmed.includes('STRAT')) setCurrentScreen('ovme');
    else if (trimmed.includes('RISK') || trimmed.includes('PROF') || trimmed.includes('PAYOFF')) setCurrentScreen('risk');
    else if (trimmed.includes('CONE') || trimmed.includes('PROB')) setCurrentScreen('cone');
    else if (trimmed.includes('FLOW')) setCurrentScreen('flow');
    else if (trimmed.includes('SCEN')) setCurrentScreen('scen');
    else if (trimmed.includes('HIVG') || trimmed.includes('HVIV')) setCurrentScreen('hivg');
    else if (trimmed.includes('SURF') || trimmed.includes('3D')) setCurrentScreen('surf');
    else if (trimmed.includes('VOL') || trimmed.includes('SKEW')) setCurrentScreen('vols');
    else if (trimmed.includes('CHART') || trimmed.includes('TECH') || trimmed === 'TA') setCurrentScreen('chart');
    else if (trimmed.includes('MONITOR') || trimmed === 'MON' || trimmed === 'WATCH' || trimmed === 'BLOTTER') setCurrentScreen('monitor');
    else if (trimmed.includes('PORT') || trimmed.includes('POS')) setCurrentScreen('port');
    else if (trimmed.includes('PCR') || trimmed.includes('RATIO')) setCurrentScreen('pcr');
    else if (
      trimmed.includes('OPEC') ||
      trimmed.includes('JMMC') ||
      trimmed.includes('OVX') ||
      trimmed.includes('OIL EVENT') ||
      trimmed.includes('OIL VOL')
    ) {
      setCurrentScreen('opec');
    } else if (
      trimmed.includes('TARIFF') ||
      trimmed === 'TRFF' ||
      trimmed.includes('TRADE WAR') ||
      trimmed.includes('DUTY') ||
      trimmed.includes('CUSTOMS')
    ) {
      setCurrentScreen('tariff');
    } else if (
      trimmed.includes('GEO') ||
      trimmed.includes('COUNTRY') ||
      trimmed.includes('HEATMAP') ||
      trimmed.includes('WAR')
    ) {
      setIsCountryRiskOpen(true);
    } else if (trimmed.includes('MOVE') || trimmed.includes('EXP MOVE') || trimmed.includes('EXPECTED')) {
      setIsExpectedMoveOpen(true);
    } else if (trimmed.includes('CATALOG') || trimmed.includes('ALL STRAT') || trimmed.includes('PRESETS')) {
      setIsStrategyCatalogOpen(true);
    } else if (
      trimmed.includes('GAMMA') ||
      trimmed.includes('GEX') ||
      trimmed.includes('NET GAMMA') ||
      trimmed.includes('CONVEXITY')
    ) {
      setIsNetGammaOpen(true);
    } else if (
      trimmed.includes('DEFCON') ||
      trimmed.includes('DEFCONLEVEL') ||
      trimmed.includes('MILITARY') ||
      trimmed.includes('ROUND HOUSE')
    ) {
      setCurrentScreen('defcon');
    } else if (
      trimmed.includes('TFSA') ||
      trimmed.includes('RRSP') ||
      trimmed.includes('FHSA') ||
      trimmed.includes('RESP') ||
      trimmed.includes('CANADIAN') ||
      trimmed.includes('CRA') ||
      trimmed.includes('NORBERT')
    ) {
      setIsCanadianSuiteOpen(true);
    } else if (trimmed.includes('GITHUB') || trimmed === 'GIT' || trimmed === 'REPO') {
      setIsGitHubOpen(true);
    } else if (
      trimmed.includes('SCALE') ||
      trimmed.includes('ZOOM') ||
      trimmed.includes('DISPLAY') ||
      trimmed.includes('FIT') ||
      trimmed.includes('SCREEN')
    ) {
      setIsDisplaySettingsOpen(true);
    } else if (
      trimmed.includes('VEGA') ||
      trimmed.includes('TERM STRUCT') ||
      trimmed === 'VTS' ||
      trimmed.includes('VOLGA') ||
      trimmed.includes('VOMMA')
    ) {
      setCurrentScreen('vega');
    } else if (trimmed.includes('BORROW') || trimmed.includes('INTEREST') || trimmed.includes('FINANCING') || trimmed.includes('HTB')) {
      setCurrentScreen('port');
    } else if (trimmed.includes('MARGIN DEBT') || trimmed === 'DEBT' || trimmed.includes('GDP')) {
      setCurrentScreen('chart');
    } else if (trimmed.includes('HELP')) setIsHelpOpen(true);

    const words = trimmed.split(' ');
    for (const w of words) {
      if (tickers[w]) {
        setSelectedSymbol(w);
        break;
      }
    }
  };

  useEffect(() => {
    setCommandInput(`${selectedSymbol} US Equity ${currentScreen.toUpperCase()}`);
  }, [selectedSymbol, currentScreen]);

  // Global Keyboard shortcuts (F1..F8, ESC)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F1') {
        e.preventDefault();
        setIsHelpOpen(true);
      } else if (e.key === 'F2') {
        e.preventDefault();
        setCurrentScreen('omon');
      } else if (e.key === 'F3') {
        e.preventDefault();
        setCurrentScreen('ovme');
      } else if (e.key === 'F4') {
        e.preventDefault();
        setCurrentScreen('cone');
      } else if (e.key === 'F5') {
        e.preventDefault();
        setCurrentScreen('scen');
      } else if (e.key === 'F6') {
        e.preventDefault();
        setCurrentScreen('flow');
      } else if (e.key === 'F7') {
        e.preventDefault();
        setCurrentScreen('vols');
      } else if (e.key === 'F8') {
        e.preventDefault();
        setCurrentScreen('chart');
      } else if (e.key === 'F9') {
        e.preventDefault();
        setCurrentScreen('port');
      } else if (e.key === 'F10') {
        e.preventDefault();
        setCurrentScreen('chart');
      } else if (e.key === 'F11') {
        e.preventDefault();
        setCurrentScreen('pcr');
      } else if (e.key === 'F12') {
        e.preventDefault();
        setCurrentScreen('opec');
      } else if (e.key === 'Escape') {
        setIsHelpOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const selectedTicker = tickers[selectedSymbol] || tickers['SPY'];

  // Generate current option chain for selected ticker and DTE
  const currentChain: ExpirationOptionChain = useMemo(() => {
    return generateOptionsChainForTicker(selectedTicker, activeDte);
  }, [selectedTicker, activeDte]);

  // Generate all option chains across all standard expirations
  const allChains: ExpirationOptionChain[] = useMemo(() => {
    return generateAllOptionChainsForTicker(selectedTicker);
  }, [selectedTicker]);

  // Aggregate Put/Call ratio for current ticker
  const currentTickerPcr = useMemo(() => {
    let callVol = 0;
    let putVol = 0;
    allChains.forEach((c) => {
      c.calls.forEach((cl) => { callVol += cl.volume; });
      c.puts.forEach((pt) => { putVol += pt.volume; });
    });
    return callVol > 0 ? Number((putVol / callVol).toFixed(2)) : 0.85;
  }, [allChains]);

  // Market Maker Net Gamma Exposure (GEX) Analysis for current ticker
  const netGammaData = useMemo(() => {
    return calculateNetGammaAnalysis(selectedTicker, allChains);
  }, [selectedTicker, allChains]);

  // Simulate tick for tickers, macro indices and occasional unusual flow sweeps
  const simulatePriceTick = useCallback(() => {
    // 1. Tick tickers
    const updatedTickers: Record<string, Ticker> = { ...tickers };
    Object.keys(updatedTickers).forEach((sym) => {
      const t = updatedTickers[sym];
      const deltaPct = (Math.random() - 0.49) * 0.003;
      const newPrice = Number(Math.max(1, t.price * (1 + deltaPct)).toFixed(2));
      const diff = Number((newPrice - t.previousClose).toFixed(2));
      const pct = Number(((diff / t.previousClose) * 100).toFixed(2));

      const newHigh = Math.max(t.high, newPrice);
      const newLow = Math.min(t.low, newPrice);

      const candles = [...t.candles];
      if (candles.length > 0) {
        const lastCandle = { ...candles[candles.length - 1] };
        lastCandle.close = newPrice;
        lastCandle.high = Math.max(lastCandle.high, newPrice);
        lastCandle.low = Math.min(lastCandle.low, newPrice);
        candles[candles.length - 1] = lastCandle;
      }

      updatedTickers[sym] = {
        ...t,
        price: newPrice,
        change: diff,
        changePercent: pct,
        high: newHigh,
        low: newLow,
        candles,
      };
    });
    setTickers(updatedTickers);

    // 2. Tick macro indices
    setMacroIndices((prev) =>
      prev.map((idx) => {
        const nudge = (Math.random() - 0.49) * (idx.isRateOrYield ? 0.005 : 0.001);
        const nextVal = Math.max(0.1, idx.value * (1 + nudge));
        return {
          ...idx,
          value: Number(nextVal.toFixed(idx.isRateOrYield ? 3 : 2)),
          changePct: Number((idx.changePct + (Math.random() - 0.49) * 0.08).toFixed(2)),
        };
      })
    );

    // Helper: Mark to market any position list using live updated ticker quotes
    const updatePositionsMTM = (positions: Position[]) => {
      return positions.map((pos) => {
        const tick = updatedTickers[pos.ticker] || tickers[pos.ticker];
        if (!tick) return pos;

        let totalCurrentMark = 0;
        pos.legs.forEach((leg) => {
          let markPrice = 0;
          if (leg.type === 'stock' || leg.type === 'future') {
            markPrice = tick.price;
          } else {
            const bsm = calculateBSM(
              tick.price,
              leg.strike,
              Math.max(0.001, leg.dte / 365),
              leg.iv,
              leg.type === 'put' ? 'put' : 'call'
            );
            markPrice = bsm.price;
          }
          const sign = leg.action === 'buy' ? 1 : -1;
          const shareMultiplier = leg.multiplier || (leg.type === 'stock' ? 1 : (tick.multiplier || 100));
          totalCurrentMark += sign * markPrice * shareMultiplier * leg.contracts;
        });

        const unrealizedPnL = totalCurrentMark - pos.entryCost;
        const unrealizedPnLPercent =
          pos.entryCost !== 0 ? (unrealizedPnL / Math.abs(pos.entryCost)) * 100 : 0;

        return {
          ...pos,
          currentMark: Number(totalCurrentMark.toFixed(2)),
          unrealizedPnL: Number(unrealizedPnL.toFixed(2)),
          unrealizedPnLPercent: Number(unrealizedPnLPercent.toFixed(2)),
        };
      });
    };

    // 3. Mark to market open positions in main account
    setAccount((prevAcc) => {
      if (prevAcc.positions.length === 0) return prevAcc;
      return {
        ...prevAcc,
        positions: updatePositionsMTM(prevAcc.positions),
      };
    });

    // 4. Mark to market Canadian accounts positions
    setCanadianAccounts((prevAccs) =>
      prevAccs.map((acc) => ({
        ...acc,
        positions: updatePositionsMTM(acc.positions),
      }))
    );

    // 5. Occasional unusual flow trigger (approx every 3-4 ticks)
    if (Math.random() > 0.65) {
      const newFlow = generateRandomFlowItem(updatedTickers);
      setFlowItems((prev) => [newFlow, ...prev.slice(0, 40)]);
    }
  }, [tickers, selectedSymbol]);

  // Live tick interval
  useEffect(() => {
    if (!isLiveTickActive) return;
    const interval = setInterval(() => {
      simulatePriceTick();
    }, 2400);

    return () => clearInterval(interval);
  }, [isLiveTickActive, simulatePriceTick]);

  // Builder leg actions
  const handleAddLeg = (newLeg: TradeLeg) => {
    setBuilderLegs((prev) => [...prev, newLeg]);
  };

  const handleUpdateLeg = (updatedLeg: TradeLeg) => {
    setBuilderLegs((prev) =>
      prev.map((l) => (l.id === updatedLeg.id ? updatedLeg : l))
    );
  };

  const handleRemoveLeg = (legId: string) => {
    setBuilderLegs((prev) => prev.filter((l) => l.id !== legId));
  };

  const handleClearLegs = () => {
    setBuilderLegs([]);
  };

  // Pre-built Strategy Templates - supports ALL 45+ institutional strategies
  const handleApplyStrategyTemplate = (templateName: string) => {
    // Normalize aliases
    let stratId = templateName.toLowerCase().trim().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');

    // Common alias mappings
    if (stratId === 'vertical-spread') stratId = 'bull-call-spread';
    else if (stratId === 'straddle') stratId = 'long-straddle';
    else if (stratId === 'strangle') stratId = 'long-strangle';
    else if (stratId === 'butterfly') stratId = 'long-call-butterfly';
    else if (stratId === 'calendar-spread' || stratId === 'calendar') stratId = 'call-calendar-spread';
    else if (stratId === 'covered' || stratId === 'cc') stratId = 'covered-call';
    else if (stratId === 'protective-put' || stratId === 'married-put') stratId = 'protective-put';
    else if (stratId === 'pmcc') stratId = 'poor-mans-covered-call';
    else if (stratId === 'pmcp') stratId = 'poor-mans-covered-put';
    else if (stratId === 'iron-fly') stratId = 'iron-butterfly';
    else if (stratId === 'bwb') stratId = 'broken-wing-call-butterfly';
    else if (stratId === 'box') stratId = 'box-spread';

    const newLegs = generateStrategyLegs(stratId, selectedTicker, currentChain, allChains);
    setBuilderLegs(newLegs);
  };

  // Mirror trade from unusual flow
  const handleMirrorTrade = (leg: TradeLeg, tickerSymbol: string) => {
    setSelectedSymbol(tickerSymbol);
    setBuilderLegs([leg]);
    setCurrentScreen('ovme');
  };

  // Order execution handler
  const handleExecuteTrade = (order: Order, position: Position) => {
    setAccount((prev) => {
      const isDebit = order.netDebitCredit > 0;
      const newCash = isDebit
        ? prev.cashBalance - Math.abs(order.totalCost)
        : prev.cashBalance + Math.abs(order.totalCost);

      return {
        ...prev,
        cashBalance: Number(newCash.toFixed(2)),
        orders: [order, ...prev.orders],
        positions: [position, ...prev.positions],
      };
    });
  };

  // Close position handler
  const handleClosePosition = (positionId: string) => {
    // Check main account
    setAccount((prev) => {
      const targetPos = prev.positions.find((p) => p.id === positionId);
      if (!targetPos) return prev;

      const closeCashImpact = targetPos.currentMark;
      const realizedChange = targetPos.unrealizedPnL;

      const closingOrder: Order = {
        id: `BLOT-CLOSE-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
        ticker: targetPos.ticker,
        strategyName: `Close ${targetPos.strategyName}`,
        type: 'market',
        limitPrice: 0,
        legs: targetPos.legs,
        contracts: targetPos.contracts,
        netDebitCredit: -closeCashImpact,
        totalCost: Math.abs(closeCashImpact),
        status: 'filled',
      };

      return {
        ...prev,
        cashBalance: Number((prev.cashBalance + closeCashImpact).toFixed(2)),
        realizedPnL: Number((prev.realizedPnL + realizedChange).toFixed(2)),
        positions: prev.positions.filter((p) => p.id !== positionId),
        orders: [closingOrder, ...prev.orders],
      };
    });

    // Also check Canadian accounts if target position is in one
    setCanadianAccounts((prevAccounts) => {
      return prevAccounts.map((acc) => {
        const found = acc.positions.find((p) => p.id === positionId);
        if (!found) return acc;
        return {
          ...acc,
          cashBalance: Number((acc.cashBalance + found.currentMark).toFixed(2)),
          realizedPnL: Number((acc.realizedPnL + found.unrealizedPnL).toFixed(2)),
          positions: acc.positions.filter((p) => p.id !== positionId),
        };
      });
    });
  };

  const handleResetAccount = () => {
    const freshAccount: AccountState = {
      cashBalance: 100000.0,
      startingBalance: 100000.0,
      realizedPnL: 0,
      positions: [],
      orders: [],
    };
    setAccount(freshAccount);
    setCanadianAccounts(INITIAL_CANADIAN_ACCOUNTS);
    localStorage.removeItem(STORAGE_KEY_ACCOUNT);
  };

  const isUp = selectedTicker.change >= 0;
  const positionsMark = account.positions.reduce((acc, p) => acc + p.currentMark, 0);
  const netLiq = account.cashBalance + positionsMark;
  const marginRequirement = account.positions.reduce((acc, p) => {
    if (p.entryCost < 0) return acc + Math.abs(p.entryCost) * 1.5;
    if (p.ticker.startsWith('/')) return acc + p.contracts * 5000;
    return acc;
  }, 0);
  const optionsBP = Math.max(0, account.cashBalance - marginRequirement);
  const isMarginWarning = account.cashBalance > 0 && (marginRequirement / account.cashBalance) > 0.8;
  const marginUsagePct = account.cashBalance > 0 ? (marginRequirement / account.cashBalance) * 100 : 0;

  const activeTosTab = useMemo(() => {
    if (currentScreen === 'omon') return 'monitor';
    if (currentScreen === 'ovme') return 'trade';
    if (currentScreen === 'cone' || currentScreen === 'scen' || currentScreen === 'risk') return 'analyze';
    if (currentScreen === 'flow' || currentScreen === 'pcr') return 'scan';
    return 'marketwatch';
  }, [currentScreen]);

  const quickScreens: { label: string; screen: TerminalScreen }[] = [
    { label: 'OMON', screen: 'omon' },
    { label: 'OVME', screen: 'ovme' },
    { label: 'RISK', screen: 'risk' },
    { label: 'CONE', screen: 'cone' },
    { label: 'SCEN', screen: 'scen' },
    { label: 'FLOW', screen: 'flow' },
    { label: 'VOLS', screen: 'vols' },
    { label: 'SURF', screen: 'surf' },
    { label: 'HIVG', screen: 'hivg' },
    { label: 'CHART', screen: 'chart' },
    { label: 'PORT', screen: 'port' },
    { label: 'PCR', screen: 'pcr' },
    { label: 'VEGA', screen: 'vega' },
  ];

  const atmMetrics = useMemo(() => {
    if (!currentChain.calls.length) {
      return { straddleCost: 15.09, movePct: 2.67 };
    }
    const currentPrice = selectedTicker.price;
    let closestIdx = 0;
    let minDiff = Infinity;
    currentChain.calls.forEach((c, idx) => {
      const diff = Math.abs(c.strike - currentPrice);
      if (diff < minDiff) {
        minDiff = diff;
        closestIdx = idx;
      }
    });
    const callAtm = currentChain.calls[closestIdx];
    const putAtm = currentChain.puts[closestIdx] || callAtm;
    const straddleCost = callAtm.last + putAtm.last;
    const movePct = currentPrice > 0 ? (straddleCost / currentPrice) * 100 : 2.67;
    return {
      straddleCost: Number(straddleCost.toFixed(2)),
      movePct: Number(movePct.toFixed(2)),
    };
  }, [currentChain, selectedTicker.price]);

  // Common screen renderer
  const renderScreenContent = () => (
    <>
      {/* SCREEN 1: OMON (Options Monitor Chain) */}
      {currentScreen === 'omon' && (
        <div className="flex-1 flex flex-col gap-3 max-w-[1600px] w-full mx-auto">
          <OptionsMatrixOMON
            ticker={selectedTicker}
            chain={currentChain}
            allChains={allChains}
            activeDte={activeDte}
            onSelectDte={(dte) => setActiveDte(dte)}
            builderLegs={builderLegs}
            portfolioPositions={account.positions}
            onOpenMonitorScreen={() => setCurrentScreen('monitor')}
            onAddLeg={handleAddLeg}
            onRemoveLeg={handleRemoveLeg}
            onApplyStrategyTemplate={handleApplyStrategyTemplate}
            onOpenValuationScreen={() => setCurrentScreen('ovme')}
            onOpenConeScreen={() => setCurrentScreen('cone')}
            onOpenVolsScreen={() => setCurrentScreen('vols')}
            onOpenPcrScreen={() => setCurrentScreen('pcr')}
            onOpenRiskProfile={() => setCurrentScreen('risk')}
            onSelectTicker={(sym) => setSelectedSymbol(sym)}
            onOpenStockTrade={() => setIsStockTradeOpen(true)}
            onOpenOpecScreen={() => setCurrentScreen('opec')}
            onOpenExpectedMove={() => setIsExpectedMoveOpen(true)}
            onOpenNetGamma={() => setIsNetGammaOpen(true)}
            onOpenVegaScreen={() => setCurrentScreen('vega')}
          />

          {builderLegs.length > 0 && (
            <div className="mt-2">
              <OptionsValuationOVME
                currentStockPrice={selectedTicker.price}
                tickerSymbol={selectedTicker.symbol}
                legs={builderLegs}
                onUpdateLeg={handleUpdateLeg}
                onRemoveLeg={handleRemoveLeg}
                onClearLegs={handleClearLegs}
                onExecuteTrade={handleExecuteTrade}
                cashBalance={account.cashBalance}
                onNavigateToScenario={() => setCurrentScreen('scen')}
                onNavigateToCone={() => setCurrentScreen('cone')}
                onApplyStrategyTemplate={handleApplyStrategyTemplate}
                onOpenStrategyCatalog={() => setIsStrategyCatalogOpen(true)}
              />
            </div>
          )}
        </div>
      )}

      {/* SCREEN 2: OVME (Options Valuation & Greeks Engine) */}
      {currentScreen === 'ovme' && (
        <div className="max-w-7xl w-full mx-auto">
          <OptionsValuationOVME
            currentStockPrice={selectedTicker.price}
            tickerSymbol={selectedTicker.symbol}
            legs={builderLegs}
            onUpdateLeg={handleUpdateLeg}
            onRemoveLeg={handleRemoveLeg}
            onClearLegs={handleClearLegs}
            onExecuteTrade={handleExecuteTrade}
            cashBalance={account.cashBalance}
            onNavigateToScenario={() => setCurrentScreen('scen')}
            onNavigateToCone={() => setCurrentScreen('cone')}
            onApplyStrategyTemplate={handleApplyStrategyTemplate}
            onOpenStrategyCatalog={() => setIsStrategyCatalogOpen(true)}
          />
        </div>
      )}

      {/* SCREEN: RISK (Dedicated Standalone Risk Profile & Bigger Picture Payoff Engine) */}
      {currentScreen === 'risk' && (
        <div className="flex-1 flex flex-col gap-3 max-w-[1600px] w-full mx-auto">
          <RiskProfileView
            ticker={selectedTicker}
            chain={currentChain}
            allChains={allChains}
            builderLegs={builderLegs}
            portfolioPositions={account.positions}
            onAddLeg={handleAddLeg}
            onOpenStockTrade={() => setIsStockTradeOpen(true)}
            onSelectTicker={(sym: string) => setSelectedSymbol(sym)}
            onSeedPositions={() => {
              setAccount((prev) => ({
                ...prev,
                positions: INITIAL_PORTFOLIO_POSITIONS,
              }));
            }}
            onUpdateLeg={handleUpdateLeg}
            onRemoveLeg={handleRemoveLeg}
            onClearLegs={handleClearLegs}
            onApplyStrategyTemplate={handleApplyStrategyTemplate}
            onNavigateToChain={() => setCurrentScreen('omon')}
            onNavigateToValuation={() => setCurrentScreen('ovme')}
            onNavigateToCone={() => setCurrentScreen('cone')}
            onNavigateToScenario={() => setCurrentScreen('scen')}
            onOpenExpectedMove={() => setIsExpectedMoveOpen(true)}
            onOpenStrategyCatalog={() => setIsStrategyCatalogOpen(true)}
          />
        </div>
      )}

      {/* SCREEN: CONE (Probability of Expiring Cones & Expected Move Bands) */}
      {currentScreen === 'cone' && (
        <ProbabilityConeCONE
          ticker={selectedTicker}
          chain={currentChain}
          legs={builderLegs}
          onNavigateToBuilder={() => setCurrentScreen('ovme')}
          onNavigateToChain={() => setCurrentScreen('omon')}
        />
      )}

      {/* SCREEN 3: SCEN (2D Scenario Matrix) */}
      {currentScreen === 'scen' && (
        <ScenarioMatrixSCEN
          ticker={selectedTicker}
          legs={builderLegs}
          onNavigateToBuilder={() => setCurrentScreen('ovme')}
          onApplyStrategyTemplate={handleApplyStrategyTemplate}
        />
      )}

      {/* SCREEN 4: FLOW (Unusual Options Flow Tape) */}
      {currentScreen === 'flow' && (
        <UnusualFlowTapeFLOW
          flowItems={flowItems}
          onMirrorTrade={handleMirrorTrade}
          tickers={tickers}
          onNavigateToPcr={() => setCurrentScreen('pcr')}
        />
      )}

      {/* SCREEN 5: VOLS (Volatility Surface & Skew Smirk) */}
      {currentScreen === 'vols' && (
        <VolatilityLabView
          ticker={selectedTicker}
          chain={currentChain}
          allChains={allChains}
          selectedDte={activeDte}
          onSelectDte={(dte) => setActiveDte(dte)}
          onNavigateToChain={() => setCurrentScreen('omon')}
          onNavigateToCone={() => setCurrentScreen('cone')}
          onNavigateToValuation={() => setCurrentScreen('ovme')}
          onNavigateToVega={() => setCurrentScreen('vega')}
        />
      )}

      {/* SCREEN: SURF (3D Volatility Surface Engine) */}
      {currentScreen === 'surf' && (
        <VolatilitySurface3D
          ticker={selectedTicker}
          allChains={allChains}
          onNavigateToChain={() => setCurrentScreen('omon')}
          onNavigateToHIVG={() => setCurrentScreen('hivg')}
          onNavigateToSkews={() => setCurrentScreen('vols')}
          onNavigateToValuation={() => setCurrentScreen('ovme')}
        />
      )}

      {/* SCREEN: HIVG (Historical & Implied Volatility Chart & Cones) */}
      {currentScreen === 'hivg' && (
        <HistoricalImpliedVolChart
          ticker={selectedTicker}
          allChains={allChains}
          onNavigateToChain={() => setCurrentScreen('omon')}
          onNavigateToValuation={() => setCurrentScreen('ovme')}
          onNavigateToCone={() => setCurrentScreen('cone')}
          onNavigateToSkews={() => setCurrentScreen('vols')}
        />
      )}

      {/* SCREEN 6: CHART / TA (Technical Analysis & Quantitative Indicators Suite) */}
      {currentScreen === 'chart' && (
        <TechnicalsChart
          ticker={selectedTicker}
          chain={currentChain}
          allChains={allChains}
          onNavigateToHIVG={() => setCurrentScreen('hivg')}
          onNavigateToOMON={() => setCurrentScreen('omon')}
          onNavigateToPCR={() => setCurrentScreen('pcr')}
        />
      )}

      {/* SCREEN 7: PORT (Institutional Portfolio & Canadian Accounts Suite) */}
      {currentScreen === 'port' && (
        <PositionsPortfolioView
          account={account}
          onClosePosition={handleClosePosition}
          onResetAccount={handleResetAccount}
          onNavigateToChain={() => setCurrentScreen('omon')}
          canadianAccounts={canadianAccounts}
          activeAccountId={activeCanadianAccountId}
          onSelectAccount={(accId) => setActiveCanadianAccountId(accId)}
          onOpenCanadianSuite={() => setIsCanadianSuiteOpen(true)}
          tickers={tickers}
          isLiveTickActive={isLiveTickActive}
          onToggleLiveTick={() => setIsLiveTickActive((prev) => !prev)}
          onNavigateToRisk={(pos) => {
            if (pos && pos.legs.length > 0) {
              setBuilderLegs(pos.legs);
            }
            setCurrentScreen('risk');
          }}
          onSelectTicker={(sym) => setSelectedSymbol(sym)}
          onSimulateTick={simulatePriceTick}
          onSeedPortfolio={() => {
            setAccount((prev) => ({
              ...prev,
              positions: INITIAL_PORTFOLIO_POSITIONS,
            }));
          }}
        />
      )}

      {/* SCREEN: MONITOR (Institutional Real-Time Positions & Margin Health Monitor) */}
      {currentScreen === 'monitor' && (
        <PositionMonitorView
          account={account}
          canadianAccounts={canadianAccounts}
          activeAccountId={activeCanadianAccountId}
          onSelectAccount={(accId) => setActiveCanadianAccountId(accId)}
          tickers={tickers}
          isLiveTickActive={isLiveTickActive}
          onToggleLiveTick={() => setIsLiveTickActive((prev) => !prev)}
          onSimulateTick={simulatePriceTick}
          onNavigateToRisk={(pos) => {
            if (pos && pos.legs.length > 0) {
              setBuilderLegs(pos.legs);
            }
            setCurrentScreen('risk');
          }}
          onNavigateToChain={(sym) => {
            setSelectedSymbol(sym);
            setCurrentScreen('omon');
          }}
          onClosePosition={handleClosePosition}
          onSeedPortfolio={() => {
            setAccount((prev) => ({
              ...prev,
              positions: INITIAL_PORTFOLIO_POSITIONS,
            }));
          }}
        />
      )}

      {/* SCREEN 8: PCR (Put/Call Ratio & Institutional Sentiment Engine) */}
      {currentScreen === 'pcr' && (
        <PutCallRatioView
          ticker={selectedTicker}
          allChains={allChains}
          onNavigateToChain={(dte) => {
            if (dte !== undefined) setActiveDte(dte);
            setCurrentScreen('omon');
          }}
          onNavigateToFlow={() => setCurrentScreen('flow')}
          onNavigateToVols={() => setCurrentScreen('vols')}
          onNavigateToValuation={() => setCurrentScreen('ovme')}
          onOpenNetGamma={() => setIsNetGammaOpen(true)}
        />
      )}

      {/* SCREEN: OPEC (OPEC+ Meetings, Energy Events & Implied Volatility Intelligence) */}
      {currentScreen === 'opec' && (
        <OPECMeetingsView
          currentTicker={selectedTicker}
          onSelectTicker={(sym) => setSelectedSymbol(sym)}
          onNavigateToChain={() => setCurrentScreen('omon')}
          onNavigateToValuation={() => setCurrentScreen('ovme')}
          onApplyStrategyLegs={(newLegs) => setBuilderLegs(newLegs)}
        />
      )}

      {/* SCREEN: TARIFF (Global Tariffs, Trade War Protectionism & Skew Monitor) */}
      {currentScreen === 'tariff' && (
        <TariffTrackerView
          currentTicker={selectedTicker}
          onSelectTicker={(sym) => setSelectedSymbol(sym)}
          onNavigateToChain={() => setCurrentScreen('omon')}
          onNavigateToValuation={() => setCurrentScreen('ovme')}
          onApplyStrategyLegs={(newLegs) => setBuilderLegs(newLegs)}
        />
      )}

      {/* SCREEN: DEFCON (defconlevel.com OSINT & Geopolitical Threat Level Engine) */}
      {currentScreen === 'defcon' && (
        <DefconLevelView
          onSelectTicker={(sym) => {
            if (tickers[sym]) setSelectedSymbol(sym);
          }}
          onNavigateToRisk={() => setCurrentScreen('risk')}
          onNavigateToOptions={() => setCurrentScreen('omon')}
        />
      )}

      {/* SCREEN: VEGA (Institutional Vega Term Structure, Vol-of-Vol & Constant Maturity Analyzer) */}
      {currentScreen === 'vega' && (
        <VegaTermStructureView
          ticker={selectedTicker}
          chains={allChains}
          positions={account.positions}
          legs={builderLegs}
          selectedDte={activeDte}
          onSelectDte={(dte) => setActiveDte(dte)}
          onNavigateToChain={() => setCurrentScreen('omon')}
          onNavigateToValuation={() => setCurrentScreen('ovme')}
          onApplyStrategyTemplate={handleApplyStrategyTemplate}
        />
      )}
    </>
  );

  return (
    <div className="tos-app-shell">
      {/* Top Utility Bar */}
      <div className="system-nav">
        <div className="f-keys">
          <button onClick={() => setIsHelpOpen(true)} className="hover:opacity-80">
            <span className="f-key">F1</span> HELP
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('omon')} className={`hover:opacity-80 ${currentScreen === 'omon' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F2</span> OMON
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('ovme')} className={`hover:opacity-80 ${currentScreen === 'ovme' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F3</span> OVME
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('risk')} className={`hover:opacity-80 ${currentScreen === 'risk' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F4</span> RISK
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('cone')} className={`hover:opacity-80 ${currentScreen === 'cone' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F5</span> CONE
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('scen')} className={`hover:opacity-80 ${currentScreen === 'scen' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F6</span> SCEN
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('flow')} className={`hover:opacity-80 ${currentScreen === 'flow' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F7</span> FLOW
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('vols')} className={`hover:opacity-80 ${currentScreen === 'vols' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F8</span> VOLS
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('hivg')} className={`hover:opacity-80 ${currentScreen === 'hivg' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F9</span> HIVG
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('chart')} className={`hover:opacity-80 ${currentScreen === 'chart' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F10</span> CHART
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('port')} className={`hover:opacity-80 ${currentScreen === 'port' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F11</span> PORT
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('monitor')} className={`hover:opacity-80 ${currentScreen === 'monitor' ? 'text-[#38bdf8] font-bold' : ''}`}>
            <span className="f-key text-[#38bdf8]">MON</span> MONITOR {account.positions.length > 0 ? `(${account.positions.length})` : ''}
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('pcr')} className={`hover:opacity-80 ${currentScreen === 'pcr' ? 'text-white font-bold' : ''}`}>
            <span className="f-key">F12</span> PCR
          </button>
          &nbsp;
          <button onClick={() => setCurrentScreen('opec')} className={`hover:opacity-80 ${currentScreen === 'opec' ? 'text-[#ff9900] font-bold' : ''}`}>
            <span className="f-key text-[#ff9900]">OPEC</span> &amp; IV
          </button>
          &nbsp;
          <button
            onClick={() => {
              playKeyClick();
              setCurrentScreen('tariff');
            }}
            className={`hover:opacity-80 ${currentScreen === 'tariff' ? 'text-[#ff9900] font-bold' : ''}`}
            title="Open Global Tariff & Trade War Protectionism Monitor"
          >
            <span className="f-key text-[#ff9900]">TRFF</span> TARIFF
          </button>
          &nbsp;
          <button
            onClick={() => {
              playKeyClick();
              setIsCountryRiskOpen(true);
            }}
            className="hover:opacity-80 text-[#ef4444] font-bold"
            title="Open Country & Geo-Political Risk Heatmap Terminal"
          >
            <span className="f-key text-[#ef4444]">GEO</span> RISK
          </button>
          &nbsp;
          <button
            onClick={() => {
              playKeyClick();
              setCurrentScreen('defcon');
            }}
            className={`hover:opacity-80 ${currentScreen === 'defcon' ? 'text-[#ffd600] font-bold' : ''}`}
            title="defconlevel.com OSINT & US Military Alert Threat System"
          >
            <span className="f-key text-[#ffd600]">DEFCON</span> 3
          </button>
          &nbsp;
          <button
            onClick={() => {
              playKeyClick();
              setIsCanadianSuiteOpen(true);
            }}
            className="hover:opacity-80 text-[#00d2ff] font-bold"
            title="Canadian Accounts & CRA Tax Suite (TFSA, RRSP, FHSA, RESP, Norbert's Gambit)"
          >
            <span className="f-key text-[#00d2ff]">🇨🇦 TFSA</span> / RRSP
          </button>
          &nbsp;
          <button
            onClick={() => {
              playKeyClick();
              setIsGitHubOpen(true);
            }}
            className="hover:opacity-80 text-[#00e676] font-bold"
            title="Open GitHub Repository Synchronization & Export Terminal"
          >
            <span className="f-key text-[#00e676]">GIT</span> GITHUB
          </button>
          &nbsp;
          <button
            onClick={() => {
              playKeyClick();
              setCurrentScreen('vega');
            }}
            className={`hover:opacity-80 ${currentScreen === 'vega' ? 'text-[#00e5ff] font-bold' : ''}`}
            title="Open Institutional Vega Term Structure & Constant Maturity Analysis"
          >
            <span className="f-key text-[#00e5ff]">VEGA</span> VTS
          </button>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {/* Quick Screen Zoom Controls */}
          <div className="flex items-center gap-1 bg-[#141b28] px-1.5 py-0.5 rounded border border-[#222d44] text-[10px] select-none">
            <button
              onClick={() => handleStepZoom(-0.05)}
              className="px-1 text-[#8b9bb4] hover:text-white font-mono font-bold cursor-pointer"
              title="Zoom Out (-5%)"
            >
              -
            </button>
            <button
              onClick={() => {
                playKeyClick();
                setIsDisplaySettingsOpen(true);
              }}
              className="text-[#ff9900] font-mono font-black hover:underline px-1 cursor-pointer"
              title="Click to customize screen scale & fit device"
            >
              {Math.round(scale * 100)}%
            </button>
            <button
              onClick={() => handleStepZoom(+0.05)}
              className="px-1 text-[#8b9bb4] hover:text-white font-mono font-bold cursor-pointer"
              title="Zoom In (+5%)"
            >
              +
            </button>
          </div>

          {/* Quick Fit to Screen Button - visible on all screens */}
          <button
            onClick={() => {
              playExecutionChime();
              handleFitToScreen();
            }}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#00d2ff]/10 hover:bg-[#00d2ff]/20 text-[#00d2ff] border border-[#00d2ff]/30 text-[10px] font-bold transition-all cursor-pointer"
            title="Auto-Fit Terminal to current window dimensions"
          >
            <span>FIT</span>
          </button>

          {/* Scale & Display Settings Modal Button */}
          <button
            onClick={() => {
              playKeyClick();
              setIsDisplaySettingsOpen(true);
            }}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#38bdf8]/10 hover:bg-[#38bdf8]/20 text-[#38bdf8] border border-[#38bdf8]/40 text-[10px] font-bold transition-all cursor-pointer"
            title="Open Display Scaling, Font Sizes & Device Settings"
          >
            <Sliders className="w-3 h-3 text-[#38bdf8]" />
            <span className="hidden sm:inline">SCALE</span>
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => {
              playKeyClick();
              handleToggleFullscreen();
            }}
            className="hidden md:flex items-center gap-1 px-1.5 py-0.5 rounded bg-[#ffd600]/10 hover:bg-[#ffd600]/20 text-[#ffd600] border border-[#ffd600]/30 text-[10px] font-bold transition-all cursor-pointer"
            title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
          >
            {isFullscreen ? <Minimize className="w-3 h-3" /> : <Maximize className="w-3 h-3" />}
          </button>

          <button
            onClick={handleAudioToggle}
            className="tos-btn hidden sm:inline-block"
            title={isAudioOn ? 'Mute terminal audio' : 'Enable terminal audio'}
          >
            {isAudioOn ? 'AUDIO ON' : 'MUTED'}
          </button>
          <span className="hidden xl:inline text-[#64748b]">BLOOMBERG v26.4</span>
          <button
            onClick={() => setCurrentScreen('monitor')}
            className="hidden lg:flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#101726] border border-[#1e2a40] hover:border-[#38bdf8] text-[10px] text-[#cbd5e1] font-mono cursor-pointer transition-colors"
            title="Real-Time Margin Health Telemetry. Click to view Monitor Blotter."
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#00e676] animate-pulse" />
            <span className="text-[#8b9bb4]">MARGIN:</span>
            <span className="font-bold text-[#00e676]">
              {account.cashBalance > 0 ? `${(Math.max(0, 100 - (marginRequirement / account.cashBalance) * 100)).toFixed(0)}%` : '100%'}
            </span>
          </button>
        </div>
      </div>

      {/* Search Header */}
      <header className="top-header">
        {/* Sidebar Toggle Button */}
        <button
          type="button"
          onClick={() => {
            playKeyClick();
            setIsSidebarOpen((prev) => !prev);
          }}
          className={`px-2 py-1 rounded text-xs font-bold border transition-colors flex items-center gap-1.5 shrink-0 cursor-pointer ${
            isSidebarOpen
              ? 'bg-[#ff9900]/15 text-[#ff9900] border-[#ff9900]/40'
              : 'bg-[#1e2638] text-white border-[#2e3c54] hover:border-[#ff9900]/60'
          }`}
          title={isSidebarOpen ? 'Collapse Left Sidebar' : 'Expand Left Sidebar (Watchlist & Strategy Templates)'}
        >
          {isSidebarOpen ? <PanelLeftClose className="w-3.5 h-3.5" /> : <PanelLeftOpen className="w-3.5 h-3.5" />}
          <span className="hidden md:inline">{isSidebarOpen ? 'COLLAPSE' : 'WATCHLIST'}</span>
        </button>

        <form onSubmit={handleCommandSubmit} className="symbol-input-group">
          <span style={{ color: 'var(--accent)', fontWeight: 'bold' }}>&gt;</span>
          <input
            type="text"
            value={commandInput}
            onChange={(e) => setCommandInput(e.target.value)}
            placeholder="SPY US Equity OMON"
          />
          <button type="submit" className="btn-go" style={{ marginRight: '4px' }}>
            &lt;GO&gt;
          </button>
        </form>

        <div className="quote-summary">
          <div>
            <span style={{ color: 'var(--ink-muted)', fontSize: '10px' }} className="flex items-center gap-1.5">
              <span className="font-bold">{selectedTicker.symbol}</span>
              {selectedTicker.symbol.startsWith('/') || selectedTicker.assetType === 'future' ? (
                <span className="text-[#ffd600] font-black bg-[#ffd600]/20 px-1 py-0.5 rounded border border-[#ffd600]/40 text-[9px]">
                  FUTURES & FOP
                </span>
              ) : (
                <span>US EQUITY</span>
              )}
            </span>
          </div>
          <div className="quote-val">
            ${selectedTicker.price.toFixed(selectedTicker.symbol === '/6E' ? 4 : selectedTicker.symbol === '/NG' ? 3 : 2)}
          </div>
          <div className={`quote-delta ${isUp ? 'pos' : 'neg'}`}>
            {isUp ? '▲ +' : '▼ '}
            {selectedTicker.change.toFixed(selectedTicker.symbol === '/6E' ? 4 : selectedTicker.symbol === '/NG' ? 3 : 2)} (
            {isUp ? '+' : ''}
            {selectedTicker.changePercent.toFixed(2)}%)
          </div>
          <div className="quote-delta" style={{ color: '#64748b' }}>
            Prev: {selectedTicker.previousClose.toFixed(selectedTicker.symbol === '/6E' ? 4 : selectedTicker.symbol === '/NG' ? 3 : 2)}
          </div>
          {(selectedTicker.symbol.startsWith('/') || selectedTicker.assetType === 'future') && (
            <div className="hidden lg:flex items-center gap-1.5 text-[9px] font-bold text-[#ffd600] bg-[#ffd600]/10 px-1.5 py-0.5 rounded border border-[#ffd600]/30">
              <span>MULT: {selectedTicker.multiplier || 50}x</span>
              <span className="text-[#8c8c8c]">·</span>
              <span>TICK: {selectedTicker.tickSize || 0.25}</span>
            </div>
          )}

          {/* Expected Price Move Header Metric */}
          <button
            onClick={() => {
              playKeyClick();
              setIsExpectedMoveOpen(true);
            }}
            title="Click to view comprehensive Expected Price Move Matrix across all expirations"
            className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-[#0b101d] border border-[#1e293b] hover:border-[#00d2ff]/60 transition-all text-left cursor-pointer group"
          >
            <div>
              <div className="text-[8.5px] text-[#8b9bb4] uppercase tracking-wider flex items-center gap-1 group-hover:text-[#00d2ff]">
                <span>EXP MOVE</span>
                <span className="text-[#ffd600] font-bold">±1σ</span>
              </div>
              <div className="font-mono font-bold text-[11px] text-white flex items-center gap-1">
                <span className="text-[#00e676]">
                  ±${(selectedTicker.price * (selectedTicker.currentIV || 0.25) * Math.sqrt(Math.max(1, activeDte) / 365)).toFixed(2)}
                </span>
                <span className="text-[10px] text-[#00d2ff]">
                  (±{(((selectedTicker.price * (selectedTicker.currentIV || 0.25) * Math.sqrt(Math.max(1, activeDte) / 365)) / selectedTicker.price) * 100).toFixed(1)}%)
                </span>
              </div>
            </div>
          </button>
        </div>

        <div className="ml-auto flex items-center gap-1.5 flex-wrap sm:flex-nowrap shrink-0">
          {/* Quick Display & Scale Button */}
          <button
            onClick={() => {
              playKeyClick();
              setIsDisplaySettingsOpen(true);
            }}
            className="px-2.5 py-1 bg-[#38bdf8]/15 hover:bg-[#38bdf8]/25 text-[#38bdf8] border border-[#38bdf8]/40 rounded font-black text-xs flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
            title="Display Scaling & Screen Layout Customizer (Fit Screen, Mobile, Tablet, Zoom)"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">SCALE</span>
          </button>

          {/* DEFCON Threat Gauge Live Header Button */}
          <button
            onClick={() => {
              playKeyClick();
              setCurrentScreen('defcon');
            }}
            className="hidden sm:flex px-2.5 py-1 bg-[#ffd600]/15 hover:bg-[#ffd600]/25 text-[#ffd600] border border-[#ffd600]/40 rounded font-black text-xs items-center gap-1.5 transition-all shadow-sm cursor-pointer"
            title="defconlevel.com OSINT: Currently DEFCON 3 (ROUND HOUSE) - US Armed Forces on high alert"
          >
            <span className="w-2 h-2 rounded-full bg-[#ffd600] animate-pulse" />
            <span>DEFCON 3</span>
          </button>

          {/* Canadian Accounts Quick Access Button */}
          <button
            onClick={() => {
              playKeyClick();
              setIsCanadianSuiteOpen(true);
            }}
            className="hidden md:flex px-2.5 py-1 bg-[#00d2ff]/15 hover:bg-[#00d2ff]/25 text-[#00d2ff] border border-[#00d2ff]/40 rounded font-black text-xs items-center gap-1.5 transition-all shadow-sm cursor-pointer"
            title="Open Canadian Registered Accounts (TFSA, RRSP, FHSA, RESP) & Norbert's Gambit"
          >
            <span>🇨🇦</span>
            <span>TFSA / RRSP</span>
          </button>

          {/* GitHub Sync & Export Repository Button */}
          <button
            onClick={() => {
              playKeyClick();
              setIsGitHubOpen(true);
            }}
            className="hidden lg:flex px-2.5 py-1 bg-[#00e676]/15 hover:bg-[#00e676]/25 text-[#00e676] border border-[#00e676]/40 rounded font-black text-xs items-center gap-1.5 transition-all shadow-sm cursor-pointer"
            title="Export repository & sync changes to GitHub"
          >
            <Github className="w-3.5 h-3.5" />
            <span>GITHUB</span>
          </button>

          {/* All Options Strategies Directory Button */}
          <button
            onClick={() => {
              playKeyClick();
              setIsStrategyCatalogOpen(true);
            }}
            className="hidden sm:flex px-2.5 py-1 bg-[#ff9900]/15 hover:bg-[#ff9900]/25 text-[#ff9900] border border-[#ff9900]/40 rounded font-bold text-xs items-center gap-1 transition-all shadow-sm cursor-pointer"
            title="Browse all 45+ Institutional Options Strategies Directory"
          >
            <span>STRATEGIES</span>
            <span className="text-[10px] bg-[#ff9900]/30 px-1 rounded font-mono font-black">45+</span>
          </button>

          {/* Quick Stock & Futures Trade Execution Button */}
          <button
            onClick={() => {
              playKeyClick();
              setIsStockTradeOpen(true);
            }}
            className="px-3 py-1 bg-[var(--bull)]/20 hover:bg-[var(--bull)]/30 text-[var(--bull)] border border-[var(--bull)]/50 rounded font-black text-xs flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
            title={`Trade shares of ${selectedTicker.symbol} or futures contracts`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>TRADE</span>
          </button>

          {/* Visual Margin Call Warning in Header */}
          {isMarginWarning && (
            <div
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#ff334b] text-white font-black text-[10px] animate-pulse border border-white/40 shadow-[0_0_10px_rgba(255,51,75,0.9)]"
              title={`Margin required ($${marginRequirement.toFixed(0)}) exceeds 80% of settled cash ($${account.cashBalance.toFixed(0)})`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">MARGIN WARNING: {marginUsagePct.toFixed(0)}%</span>
            </div>
          )}

          <div className="gadget-header font-mono" style={{ background: 'transparent', border: '1px solid var(--border)' }}>
            BP: <span style={{ color: 'cyan', marginLeft: '4px' }}>${optionsBP > 100000 ? `${(optionsBP / 1000).toFixed(0)}k` : optionsBP.toLocaleString('en-US', { maximumFractionDigits: 0 })}</span>
          </div>
          <div className="gadget-header font-mono hidden sm:flex" style={{ background: 'transparent', border: '1px solid var(--border)' }}>
            NET LIQ: <span style={{ color: '#fff', marginLeft: '4px' }}>${netLiq.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
          </div>
        </div>
      </header>

      {/* Main Workspace Layout */}
      <div className={`main-workspace ${!isSidebarOpen ? 'sidebar-collapsed' : ''}`}>
        {/* Mobile Backdrop when sidebar drawer is open on mobile */}
        {isSidebarOpen && (
          <div
            className="md:hidden mobile-sidebar-backdrop"
            onClick={() => setIsSidebarOpen(false)}
          />
        )}

        {/* Sidebar Panels */}
        <aside className={`left-sidebar ${isSidebarOpen ? 'drawer-open' : 'drawer-closed'}`}>
          {/* Mobile Drawer Header with Close Button */}
          <div className="md:hidden flex items-center justify-between p-2.5 bg-[#202020] border-b border-[#3c3c3c]">
            <span className="font-bold text-white text-xs flex items-center gap-1.5">
              <span>WATCHLIST &amp; STRATEGY SUITE</span>
            </span>
            <button
              onClick={() => setIsSidebarOpen(false)}
              className="p-1 rounded text-[#8b9bb4] hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          {/* Gadget 1: Watchlist with Equities & Futures Filter */}
          <div className="gadget">
            <div className="gadget-header flex items-center justify-between">
              <span>Watchlist</span>
              <div className="flex items-center gap-1 text-[9px]">
                <button
                  onClick={() => setWatchlistCategory('all')}
                  className={`px-1.5 py-0.5 rounded font-bold transition-all ${
                    watchlistCategory === 'all'
                      ? 'bg-[var(--accent)] text-black'
                      : 'text-[#8c8c8c] hover:text-white'
                  }`}
                >
                  ALL
                </button>
                <button
                  onClick={() => setWatchlistCategory('equity')}
                  className={`px-1.5 py-0.5 rounded font-bold transition-all ${
                    watchlistCategory === 'equity'
                      ? 'bg-[var(--accent)] text-black'
                      : 'text-[#8c8c8c] hover:text-white'
                  }`}
                >
                  EQ
                </button>
                <button
                  onClick={() => setWatchlistCategory('future')}
                  className={`px-1.5 py-0.5 rounded font-bold transition-all ${
                    watchlistCategory === 'future'
                      ? 'bg-[#ffd600] text-black'
                      : 'text-[#ffd600] hover:text-white'
                  }`}
                >
                  /FUT
                </button>
              </div>
            </div>
            <div className="gadget-content" style={{ padding: 0 }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '10px', fontFamily: 'JetBrains Mono, monospace' }}>
                <tbody>
                  {Object.keys(tickers)
                    .filter((sym) => {
                      const isFut = sym.startsWith('/');
                      if (watchlistCategory === 'future') return isFut;
                      if (watchlistCategory === 'equity') return !isFut;
                      return true;
                    })
                    .map((sym) => {
                      const t = tickers[sym];
                      const isSelected = sym === selectedSymbol;
                      const isPositive = t.change >= 0;
                      const isFut = sym.startsWith('/');
                      return (
                        <tr
                          key={sym}
                          onClick={() => {
                            playKeyClick();
                            setSelectedSymbol(sym);
                          }}
                          style={{
                            borderBottom: '1px solid #333',
                            cursor: 'pointer',
                            backgroundColor: isSelected ? '#373e47' : 'transparent',
                          }}
                          className="hover:bg-[#333]"
                        >
                          <td style={{ textAlign: 'left', color: '#fff', padding: '4px 8px', fontWeight: isSelected ? 'bold' : 'normal' }}>
                            <span className={isFut ? 'text-[#ffd600] font-bold' : ''}>{sym}</span>
                          </td>
                          <td style={{ textAlign: 'right', padding: '4px 8px' }}>
                            <span style={{ color: isPositive ? 'var(--bull)' : 'var(--bear)', fontWeight: 'bold' }}>
                              {isPositive ? '+' : ''}{t.changePercent.toFixed(1)}%
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Gadget 2: Options Analysis with IV Rank 20/80 Alerts, 30D Sparkline, Country & Geo-Political Risk Heatmap, and Yield Curve */}
          <OptionsAnalysisSidebarGadget
            selectedTicker={selectedTicker}
            atmMetrics={atmMetrics}
            currentTickerPcr={currentTickerPcr}
            onSelectTicker={(sym) => setSelectedSymbol(sym)}
            onOpenFullGeoRiskModal={() => setIsCountryRiskOpen(true)}
            onNavigateToTariff={() => setCurrentScreen('tariff')}
          />

          {/* Gadget: Earnings Calendar Panel with 5-Day IV Sparkline */}
          <EarningsCalendarSidebar
            tickers={tickers}
            selectedSymbol={selectedSymbol}
            onSelectTicker={(sym) => setSelectedSymbol(sym)}
            onNavigateToOpec={() => setCurrentScreen('opec')}
          />

          {/* Gadget 3: Quick Templates */}
          <div className="gadget" style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
            <div className="gadget-header flex items-center justify-between">
              <span>Quick Templates</span>
              <button
                onClick={() => {
                  playKeyClick();
                  setIsStrategyCatalogOpen(true);
                }}
                className="text-[#ff9900] hover:underline font-bold text-[9px]"
                title="Open Institutional Options Strategy Directory"
              >
                + Catalog ({ALL_OPTIONS_STRATEGIES.length})
              </button>
            </div>
            <div className="gadget-content" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <select
                onChange={(e) => {
                  if (e.target.value) {
                    handleApplyStrategyTemplate(e.target.value);
                  }
                }}
                defaultValue=""
                style={{ width: '100%', background: '#222', border: '1px solid #444', color: '#ccc', padding: '4px', fontSize: '10px' }}
              >
                <option value="" disabled>Apply Strategy Template...</option>
                <optgroup label="Single Leg Options">
                  <option value="long-call">Long Call (Bullish)</option>
                  <option value="short-call">Short Call (Naked)</option>
                  <option value="long-put">Long Put (Bearish)</option>
                  <option value="cash-secured-put">Cash-Secured Put</option>
                </optgroup>
                <optgroup label="Vertical Spreads">
                  <option value="bull-call-spread">Bull Call Spread (+Δ)</option>
                  <option value="bear-call-spread">Bear Call Spread (+Θ)</option>
                  <option value="bull-put-spread">Bull Put Spread (+Θ)</option>
                  <option value="bear-put-spread">Bear Put Spread (-Δ)</option>
                </optgroup>
                <optgroup label="Straddles & Strangles">
                  <option value="long-straddle">Long Straddle (Vol)</option>
                  <option value="short-straddle">Short Straddle (Theta)</option>
                  <option value="long-strangle">Long Strangle (OTM)</option>
                  <option value="short-strangle">Short Strangle</option>
                </optgroup>
                <optgroup label="Wings / Condors & Butterflies">
                  <option value="iron-condor">Iron Condor (4-Leg)</option>
                  <option value="reverse-iron-condor">Reverse Iron Condor</option>
                  <option value="iron-butterfly">Iron Butterfly (ATM)</option>
                  <option value="long-call-butterfly">Call Butterfly (1-2-1)</option>
                  <option value="long-put-butterfly">Put Butterfly (1-2-1)</option>
                  <option value="broken-wing-call-butterfly">Broken Wing Butterfly</option>
                </optgroup>
                <optgroup label="Calendars & Diagonals">
                  <option value="call-calendar-spread">Call Calendar Spread</option>
                  <option value="put-calendar-spread">Put Calendar Spread</option>
                  <option value="double-calendar-spread">Double Calendar Spread</option>
                  <option value="double-diagonal-spread">Double Diagonal Spread</option>
                  <option value="poor-mans-covered-call">Poor Man's Covered Call (PMCC)</option>
                  <option value="poor-mans-covered-put">Poor Man's Covered Put (PMCP)</option>
                </optgroup>
                <optgroup label="Covered & Synthetics">
                  <option value="covered-call">Covered Call (Buy-Write)</option>
                  <option value="protective-put">Protective Put (Hedge)</option>
                  <option value="collar">Collar (Zero-Cost)</option>
                  <option value="synthetic-long-stock">Synthetic Long Stock</option>
                </optgroup>
                <optgroup label="Ratios & Exotics">
                  <option value="jade-lizard">Jade Lizard</option>
                  <option value="reverse-jade-lizard">Reverse Jade Lizard</option>
                  <option value="call-ratio-backspread">Call Ratio Backspread</option>
                  <option value="put-ratio-backspread">Put Ratio Backspread</option>
                  <option value="box-spread">Box Spread (Arbitrage)</option>
                </optgroup>
              </select>

              <button
                onClick={() => {
                  playKeyClick();
                  setIsStrategyCatalogOpen(true);
                }}
                className="tos-btn w-full py-1 text-center font-bold text-[#ff9900] bg-[#ff9900]/10 hover:bg-[#ff9900]/20 border border-[#ff9900]/40 flex items-center justify-center gap-1"
              >
                <span>+ BROWSE ALL 45+ STRATEGIES</span>
              </button>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px' }}>
                {[
                  { label: 'Covered Call', id: 'covered-call' },
                  { label: 'Bull Call', id: 'bull-call-spread' },
                  { label: 'Iron Condor', id: 'iron-condor' },
                  { label: 'Straddle', id: 'long-straddle' },
                  { label: 'Butterfly', id: 'long-call-butterfly' },
                  { label: 'Calendar', id: 'call-calendar-spread' },
                ].map((tpl) => (
                  <button
                    key={tpl.id}
                    onClick={() => handleApplyStrategyTemplate(tpl.id)}
                    className="tos-btn truncate"
                    style={{ fontSize: '9px', padding: '3px 4px' }}
                  >
                    {tpl.label}
                  </button>
                ))}
              </div>

              {builderLegs.length > 0 && (
                <div className="mt-2 pt-2 border-t border-[#3c3c3c] text-[10px]">
                  <div className="flex justify-between text-[#8c8c8c]">
                    <span>Active Legs:</span>
                    <strong className="text-white">{builderLegs.length}</strong>
                  </div>
                  <button
                    onClick={() => setCurrentScreen('ovme')}
                    className="tos-btn w-full mt-1.5 text-center text-[#ff9900]"
                  >
                    Evaluate in OVME &gt;
                  </button>
                </div>
              )}
            </div>

            <div className="mt-auto p-2 border-t border-[#3c3c3c] flex justify-between items-center text-[10px] text-[#8c8c8c]">
              <span>Pos: {account.positions.length}</span>
              <button onClick={handleResetAccount} className="tos-btn hover:text-white">
                Reset Acct
              </button>
            </div>
          </div>
        </aside>

        {/* Content Area */}
        <main className="content-area">
          <div className="tab-bar">
            <div
              className={`tab ${currentScreen === 'omon' ? 'active' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('omon');
              }}
            >
              OPTION CHAIN
            </div>
            <div
              className={`tab ${currentScreen === 'ovme' ? 'active' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('ovme');
              }}
            >
              GREEKS (OVME)
            </div>
            <div
              className={`tab ${currentScreen === 'risk' ? 'active' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('risk');
              }}
            >
              RISK PROFILE
            </div>
            <div
              className={`tab ${currentScreen === 'cone' ? 'active' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('cone');
              }}
            >
              PROBABILITY CONE
            </div>
            <div
              className={`tab ${currentScreen === 'scen' ? 'active' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('scen');
              }}
            >
              SCENARIO MATRIX
            </div>
            <div
              className={`tab ${currentScreen === 'flow' ? 'active' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('flow');
              }}
            >
              FLOW TAPE
            </div>
            <div
              className={`tab ${currentScreen === 'vols' || currentScreen === 'surf' || currentScreen === 'hivg' ? 'active' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('vols');
              }}
            >
              VOLATILITY
            </div>
            <div
              className={`tab ${currentScreen === 'vega' ? 'active text-[#00e5ff] font-extrabold' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('vega');
              }}
              title="Open Institutional Vega Term Structure & Constant Maturity Analysis"
            >
              VEGA TERM STRUCTURE
            </div>
            <div
              className={`tab ${currentScreen === 'chart' ? 'active' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('chart');
              }}
            >
              CHART
            </div>
            <div
              className={`tab ${currentScreen === 'port' ? 'active' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('port');
              }}
            >
              PORTFOLIO
            </div>
            <div
              className={`tab ${currentScreen === 'pcr' ? 'active' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('pcr');
              }}
            >
              PCR ENGINE
            </div>
            <div
              className={`tab ${currentScreen === 'opec' ? 'active text-[#ff9900] font-extrabold' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('opec');
              }}
            >
              OPEC &amp; ENERGY IV
            </div>
            <div
              className={`tab ${currentScreen === 'tariff' ? 'active text-[#ef4444] font-extrabold' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('tariff');
              }}
            >
              TARIFF TRACKER
            </div>
            <div
              className={`tab ${currentScreen === 'defcon' ? 'active text-[#ffd600] font-extrabold' : ''}`}
              onClick={() => {
                playKeyClick();
                setCurrentScreen('defcon');
              }}
              title="defconlevel.com live threat level monitoring & defense prime options"
            >
              DEFCON LEVEL 3
            </div>
            <div
              className="tab text-[#00d2ff] hover:text-white"
              onClick={() => {
                playKeyClick();
                setIsCanadianSuiteOpen(true);
              }}
              title="Open Canadian Accounts & Tax Suite (TFSA, RRSP, FHSA, RESP, Norbert's Gambit)"
            >
              🇨🇦 TFSA · RRSP
            </div>
          </div>

          <div style={{ background: '#252525', padding: '4px 12px', display: 'flex', gap: '10px', alignItems: 'center', borderBottom: '1px solid #333', overflowX: 'auto' }} className="no-scrollbar">
            {/* Expiration Month Dropdown */}
            <div className="flex items-center gap-1.5 shrink-0">
              <span style={{ fontSize: '10px', fontWeight: 'bold', color: 'var(--accent)' }}>EXP MONTH:</span>
              <select
                value={selectedExpMonth}
                onChange={(e) => {
                  playKeyClick();
                  const m = e.target.value;
                  setSelectedExpMonth(m);
                  if (m !== 'ALL') {
                    const found = EXPIRATION_PRESETS.find((p) => p.month.toUpperCase() === m.toUpperCase());
                    if (found) setActiveDte(found.days);
                  }
                }}
                className="tos-btn"
                style={{ fontSize: '10px', padding: '2px 4px', fontWeight: 'bold' }}
              >
                <option value="ALL">ALL EXPIRATION MONTHS (18 Cycles)</option>
                <option value="SEP">SEP '26 (Sep 29 - Front Month)</option>
                <option value="OCT">OCT '26 (Oct 02 - Oct 30)</option>
                <option value="NOV">NOV '26 (Nov 06 - Nov 20)</option>
                <option value="DEC">DEC '26 (Dec 18 - Quarterly)</option>
                <option value="JAN">JAN '27 (Jan 15 - Monthly)</option>
                <option value="FEB">FEB '27 (Feb 19 - Monthly)</option>
                <option value="MAR">MAR '27 (Mar 19 - Quarterly)</option>
                <option value="APR">APR '27 (Apr 16 - Monthly)</option>
                <option value="MAY">MAY '27 (May 21 - Monthly)</option>
                <option value="JUN">JUN '27 (Jun 18 - Quarterly)</option>
                <option value="SEP">SEP '27 (Sep 17 - LEAPS)</option>
                <option value="DEC">DEC '27 (Dec 17 - LEAPS)</option>
              </select>
            </div>

            {/* Quick Month Filter Pills */}
            <div className="flex items-center gap-1 shrink-0">
              {['ALL', 'SEP', 'OCT', 'NOV', 'DEC', 'JAN', 'MAR', 'JUN'].map((m) => (
                <button
                  key={m}
                  onClick={() => {
                    playKeyClick();
                    setSelectedExpMonth(m);
                    if (m !== 'ALL') {
                      const found = EXPIRATION_PRESETS.find((p) => p.month.toUpperCase() === m.toUpperCase());
                      if (found) setActiveDte(found.days);
                    }
                  }}
                  className={`tos-btn ${
                    selectedExpMonth === m ? 'bg-[#ff9900] text-black font-extrabold border-[#ff9900]' : ''
                  }`}
                  style={{ fontSize: '9px', padding: '2px 6px' }}
                >
                  {m}
                </button>
              ))}
            </div>

            <div style={{ height: '14px', width: '1px', background: '#444' }} className="shrink-0" />

            {/* Expiration Date Pills with Month and Days */}
            <div className="flex items-center gap-1 shrink-0 overflow-x-auto no-scrollbar">
              {EXPIRATION_PRESETS.filter(
                (p) => selectedExpMonth === 'ALL' || p.month.toUpperCase() === selectedExpMonth.toUpperCase()
              ).map((p) => (
                <button
                  key={p.days}
                  onClick={() => {
                    playKeyClick();
                    setActiveDte(p.days);
                  }}
                  className={`tos-btn shrink-0 flex items-center gap-1 ${
                    activeDte === p.days ? 'bg-[#ff9900] text-black font-extrabold border-[#ff9900]' : ''
                  }`}
                  style={{ fontSize: '10px', padding: '2px 6px' }}
                  title={`${p.label} - ${p.category}`}
                >
                  <span className="font-extrabold">{p.dateLabel}</span>
                  <span className="opacity-75 text-[9px]">({p.days}d)</span>
                </button>
              ))}
            </div>

            <div style={{ color: 'var(--ink-muted)', fontSize: '10px', marginLeft: 'auto' }} className="shrink-0 hidden md:block">
              Implied Move: <span style={{ color: '#00d2ff', fontWeight: 'bold' }}>±{atmMetrics.movePct.toFixed(2)}%</span>
            </div>
            <div style={{ color: 'var(--ink-muted)', fontSize: '10px' }} className="shrink-0 hidden md:block">
              ATM Straddle: <span style={{ color: '#ffd600', fontWeight: 'bold' }}>${atmMetrics.straddleCost.toFixed(2)}</span>
            </div>
          </div>

          <div className="options-chain-wrapper p-2">
            {renderScreenContent()}
          </div>
        </main>
      </div>

      {/* Bottom Status Bar */}
      <footer className="status-footer">
        <div className="ticker-tape">
          {macroIndices.map((idx) => {
            const isPositive = idx.change >= 0;
            return (
              <div key={idx.symbol} className="ticker-item">
                <span>{idx.symbol}</span>
                {idx.isRateOrYield
                  ? `${idx.value.toFixed(3)}%`
                  : idx.value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                {' '}
                <span style={{ color: isPositive ? 'var(--bull)' : 'var(--bear)' }}>
                  {isPositive ? '+' : ''}{idx.changePct.toFixed(2)}%
                </span>
              </div>
            );
          })}
        </div>
        {/* Footer BP and Net Liq status area with visual margin warning */}
        <div className="flex items-center gap-2.5 font-mono text-[11px] shrink-0 border-l border-[#333] pl-3">
          <span style={{ color: 'var(--ink-muted)' }}>BP:</span>
          <span style={{ color: 'cyan', fontWeight: 'bold' }}>
            ${optionsBP.toLocaleString('en-US', { maximumFractionDigits: 0 })}
          </span>
          <span style={{ color: 'var(--ink-muted)' }}>NET LIQ:</span>
          <span style={{ color: '#fff', fontWeight: 'bold' }}>
            ${netLiq.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>

          {isMarginWarning && (
            <span
              className="bg-[#ff334b] text-white font-black px-2 py-0.5 rounded text-[10px] animate-pulse border border-red-300 shadow-[0_0_8px_rgba(255,51,75,0.9)] flex items-center gap-1"
              title={`Margin requirement ($${marginRequirement.toFixed(0)}) exceeds 80% of cash balance ($${account.cashBalance.toFixed(0)})`}
            >
              <span>⚠️ MARGIN &gt; 80% ({marginUsagePct.toFixed(0)}%)</span>
            </span>
          )}
        </div>

        <div style={{ fontWeight: 'bold', color: 'var(--accent)' }}>
          {clockTime.est || '03:16:26 EST'}
        </div>
        <div style={{ color: 'var(--ink-muted)' }}>
          MARKET DATA: REAL-TIME (CBOE BZX)
        </div>
      </footer>

      {/* Stock & Futures Order Ticket Modal */}
      <StockTradeModal
        isOpen={isStockTradeOpen}
        onClose={() => setIsStockTradeOpen(false)}
        ticker={selectedTicker}
        cashBalance={account.cashBalance}
        onExecuteTrade={handleExecuteTrade}
      />

      {/* Help Modal (<F1 HELP>) */}
      <HelpTerminalModal
        isOpen={isHelpOpen}
        onClose={() => setIsHelpOpen(false)}
      />

      {/* Expected Price Move Matrix Modal */}
      <ExpectedMoveModal
        isOpen={isExpectedMoveOpen}
        onClose={() => setIsExpectedMoveOpen(false)}
        ticker={selectedTicker}
        currentChain={currentChain}
        allChains={allChains}
        onOpenRiskProfile={() => {
          setIsExpectedMoveOpen(false);
          setCurrentScreen('risk');
        }}
        onOpenCone={() => {
          setIsExpectedMoveOpen(false);
          setCurrentScreen('cone');
        }}
      />

      {/* Institutional Strategy Catalog Directory Modal */}
      <StrategyCatalogModal
        isOpen={isStrategyCatalogOpen}
        onClose={() => setIsStrategyCatalogOpen(false)}
        activeTickerSymbol={selectedTicker.symbol}
        onSelectStrategy={(strategyId, destination) => {
          handleApplyStrategyTemplate(strategyId);
          if (destination === 'risk') {
            setCurrentScreen('risk');
          } else {
            setCurrentScreen('ovme');
          }
        }}
      />

      {/* Country & Geo-Political Risk Modal */}
      <CountryRiskModal
        isOpen={isCountryRiskOpen}
        onClose={() => setIsCountryRiskOpen(false)}
        onSelectTicker={(sym) => setSelectedSymbol(sym)}
        onNavigateToScreen={(scr) => setCurrentScreen(scr as TerminalScreen)}
      />

      {/* Canadian Accounts & CRA Tax Suite Modal (TFSA, RRSP, FHSA, RESP, Norbert's Gambit) */}
      <CanadianAccountsModal
        isOpen={isCanadianSuiteOpen}
        onClose={() => setIsCanadianSuiteOpen(false)}
        accounts={canadianAccounts}
        activeAccountId={activeCanadianAccountId}
        onSelectAccount={(accId) => {
          setActiveCanadianAccountId(accId);
          setCurrentScreen('port');
        }}
      />

      {/* GitHub Repository Synchronization & Export Terminal Modal */}
      <GitHubSyncModal
        isOpen={isGitHubOpen}
        onClose={() => setIsGitHubOpen(false)}
      />

      {/* Display Scaling, Device Fit & Density Settings Modal */}
      <DisplaySettingsModal
        isOpen={isDisplaySettingsOpen}
        onClose={() => setIsDisplaySettingsOpen(false)}
        scale={scale}
        onScaleChange={(s) => setScale(s)}
        density={density}
        onDensityChange={(d) => setDensity(d)}
        isSidebarOpen={isSidebarOpen}
        onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
        onFitToScreen={handleFitToScreen}
        onResetDefaults={handleResetDefaults}
        isFullscreen={isFullscreen}
        onToggleFullscreen={handleToggleFullscreen}
        textLegibility={textLegibility}
        onTextLegibilityChange={(tl) => setTextLegibility(tl)}
        contrastMode={contrastMode}
        onContrastModeChange={(cm) => setContrastMode(cm)}
      />

      {/* Floating Quick Scale & Fit Widget for Mobile / Tablet */}
      <FloatingDisplayWidget
        scale={scale}
        onScaleChange={(s) => setScale(s)}
        onFitToScreen={handleFitToScreen}
        onOpenSettings={() => setIsDisplaySettingsOpen(true)}
        isFullscreen={isFullscreen}
        onToggleFullscreen={handleToggleFullscreen}
        textLegibility={textLegibility}
        onCycleLegibility={() => {
          setTextLegibility((prev) => {
            if (prev === 'standard') return 'large';
            if (prev === 'large') return 'xlarge';
            return 'standard';
          });
        }}
      />
    </div>
  );
}

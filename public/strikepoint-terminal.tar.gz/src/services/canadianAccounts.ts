import { Position, Order, TradeLeg } from '../types/options';

export type CanadianAccountType =
  | 'TFSA'
  | 'RRSP'
  | 'FHSA'
  | 'RESP'
  | 'MARGIN_CAD'
  | 'MARGIN_USD'
  | 'CORPORATE';

export interface CRAContributionRoom {
  annualLimit: number;
  usedThisYear: number;
  availableRoom: number;
  lifetimeLimit?: number;
  notes: string;
}

export interface CanadianAccount {
  id: string;
  name: string;
  code: CanadianAccountType;
  accountNumber: string;
  institution: string; // e.g. Questrade, TD Direct Investing, Wealthsimple, RBC Direct Investing, Interactive Brokers
  currency: 'CAD' | 'USD';
  cashBalance: number;
  startingBalance: number;
  realizedPnL: number;
  positions: Position[];
  orders: Order[];
  optionsLevel: 1 | 2 | 3 | 4;
  optionsLevelLabel: string;
  isRegistered: boolean;
  marginAllowed: boolean;
  craContributionRoom?: CRAContributionRoom;
  taxStatusDescription: string;
  usWithholdingTaxNote: string;
  color: string;
  badge: string;
}

/**
 * Standard CAD/USD Foreign Exchange Rate
 * 1 USD = 1.3650 CAD (or 1 CAD = 0.7326 USD)
 */
export const USDCAD_EXCHANGE_RATE = 1.3650;

/**
 * Convert amounts between CAD and USD
 */
export function convertCurrency(
  amount: number,
  from: 'CAD' | 'USD',
  to: 'CAD' | 'USD',
  rate: number = USDCAD_EXCHANGE_RATE
): number {
  if (from === to) return amount;
  if (from === 'USD' && to === 'CAD') return amount * rate;
  return amount / rate;
}

/**
 * Initial Multi-Account Suite for Canadian Investors
 */
export const INITIAL_CANADIAN_ACCOUNTS: CanadianAccount[] = [
  // 1. TFSA - Tax-Free Savings Account
  {
    id: 'act-tfsa',
    name: 'Tax-Free Savings Account (TFSA)',
    code: 'TFSA',
    accountNumber: 'TFA-984-2104',
    institution: 'Questrade Canada',
    currency: 'CAD',
    cashBalance: 14850.0,
    startingBalance: 65000.0,
    realizedPnL: 3450.0,
    optionsLevel: 2,
    optionsLevelLabel: 'Level 2: Long Calls, Long Puts & Covered Calls (CRA Cash Account)',
    isRegistered: true,
    marginAllowed: false,
    color: '#00d2ff',
    badge: '🇨🇦 TFSA · TAX-FREE',
    craContributionRoom: {
      annualLimit: 7000,
      usedThisYear: 4500,
      availableRoom: 2500,
      lifetimeLimit: 95000,
      notes: '2026 CRA annual limit: $7,000 CAD. Cumulative room: $95,000 CAD. 100% tax-free growth and withdrawals.',
    },
    taxStatusDescription: '100% Tax-Exempt on capital gains, Canadian dividends, and covered call option premiums under Section 146.2 of the Income Tax Act.',
    usWithholdingTaxNote: '15% IRS non-resident withholding tax applies to US dividends (unrecoverable in TFSA as foreign tax credit cannot be claimed).',
    orders: [
      {
        id: 'ord-tfsa-1',
        timestamp: '09:32:15',
        ticker: 'RY.TO',
        strategyName: 'Covered Call (RY.TO)',
        type: 'limit',
        limitPrice: 2.15,
        legs: [
          {
            id: 'leg-tfsa-ry-call',
            type: 'call',
            action: 'sell',
            strike: 170.0,
            expiration: 'NOV 26',
            dte: 45,
            iv: 0.16,
            premium: 2.15,
            contracts: 1,
            multiplier: 100,
            underlyingSymbol: 'RY.TO',
          },
        ],
        contracts: 1,
        netDebitCredit: -215.0,
        totalCost: 215.0,
        status: 'filled',
        assetCategory: 'option',
      },
    ],
    positions: [
      {
        id: 'pos-tfsa-ry',
        ticker: 'RY.TO',
        strategyName: 'Covered Call (150 shs + Short 170C)',
        openedAt: '09:32:15',
        contracts: 150,
        entryCost: 24200.0,
        currentMark: 25150.0,
        unrealizedPnL: 950.0,
        unrealizedPnLPercent: 3.93,
        assetCategory: 'stock',
        sharesOrContracts: 150,
        legs: [
          {
            id: 'leg-tfsa-ry-stk',
            type: 'stock',
            action: 'buy',
            strike: 161.33,
            expiration: 'Perpetual',
            dte: 0,
            iv: 0,
            premium: 161.33,
            contracts: 150,
            multiplier: 1,
            underlyingSymbol: 'RY.TO',
          },
          {
            id: 'leg-tfsa-ry-c',
            type: 'call',
            action: 'sell',
            strike: 170.0,
            expiration: 'NOV 26',
            dte: 45,
            iv: 0.16,
            premium: 2.15,
            contracts: 1,
            multiplier: 100,
            underlyingSymbol: 'RY.TO',
          },
        ],
      },
      {
        id: 'pos-tfsa-enb',
        ticker: 'ENB.TO',
        strategyName: 'Long Stock (200 shs)',
        openedAt: '10:05:40',
        contracts: 200,
        entryCost: 10600.0,
        currentMark: 10960.0,
        unrealizedPnL: 360.0,
        unrealizedPnLPercent: 3.4,
        assetCategory: 'stock',
        sharesOrContracts: 200,
        legs: [
          {
            id: 'leg-tfsa-enb-stk',
            type: 'stock',
            action: 'buy',
            strike: 53.0,
            expiration: 'Perpetual',
            dte: 0,
            iv: 0,
            premium: 53.0,
            contracts: 200,
            multiplier: 1,
            underlyingSymbol: 'ENB.TO',
          },
        ],
      },
      {
        id: 'pos-tfsa-shop',
        ticker: 'SHOP.TO',
        strategyName: 'Long Call Option (100 shs exposure)',
        openedAt: '11:15:20',
        contracts: 1,
        entryCost: 680.0,
        currentMark: 920.0,
        unrealizedPnL: 240.0,
        unrealizedPnLPercent: 35.29,
        assetCategory: 'option',
        sharesOrContracts: 1,
        legs: [
          {
            id: 'leg-tfsa-shop-c',
            type: 'call',
            action: 'buy',
            strike: 110.0,
            expiration: 'DEC 26',
            dte: 78,
            iv: 0.42,
            premium: 6.8,
            contracts: 1,
            multiplier: 100,
            underlyingSymbol: 'SHOP.TO',
          },
        ],
      },
    ],
  },

  // 2. RRSP - Registered Retirement Savings Plan
  {
    id: 'act-rrsp',
    name: 'Registered Retirement Savings Plan (RRSP)',
    code: 'RRSP',
    accountNumber: 'RSP-714-3829',
    institution: 'TD Direct Investing',
    currency: 'USD',
    cashBalance: 32400.0,
    startingBalance: 120000.0,
    realizedPnL: 5800.0,
    optionsLevel: 2,
    optionsLevelLabel: 'Level 2: Long Calls, Long Puts & Covered Calls (US-Canada Treaty Optimized)',
    isRegistered: true,
    marginAllowed: false,
    color: '#00e676',
    badge: '🇨🇦 RRSP · RETIREMENT',
    craContributionRoom: {
      annualLimit: 31560,
      usedThisYear: 12000,
      availableRoom: 19560,
      notes: '2026 CRA maximum deduction limit: $31,560 CAD (or 18% of previous year earned income). Tax-deferred growth.',
    },
    taxStatusDescription: 'Tax-deferred until withdrawal. Contributions reduce taxable income in contribution year. Withdrawals taxed as regular income.',
    usWithholdingTaxNote: '✅ 0% Withholding Tax: US dividends are completely EXEMPT from 15% IRS withholding under US-Canada Income Tax Treaty (Article XXI). Ideal for US dividend stocks!',
    orders: [],
    positions: [
      {
        id: 'pos-rrsp-msft',
        ticker: 'MSFT',
        strategyName: 'Long Stock (100 shs)',
        openedAt: '09:35:00',
        contracts: 100,
        entryCost: 41500.0,
        currentMark: 42800.0,
        unrealizedPnL: 1300.0,
        unrealizedPnLPercent: 3.13,
        assetCategory: 'stock',
        sharesOrContracts: 100,
        legs: [
          {
            id: 'leg-rrsp-msft-stk',
            type: 'stock',
            action: 'buy',
            strike: 415.0,
            expiration: 'Perpetual',
            dte: 0,
            iv: 0,
            premium: 415.0,
            contracts: 100,
            multiplier: 1,
            underlyingSymbol: 'MSFT',
          },
        ],
      },
      {
        id: 'pos-rrsp-aapl',
        ticker: 'AAPL',
        strategyName: 'Covered Call (100 shs + Short 235C)',
        openedAt: '10:20:10',
        contracts: 100,
        entryCost: 22100.0,
        currentMark: 22780.0,
        unrealizedPnL: 680.0,
        unrealizedPnLPercent: 3.08,
        assetCategory: 'stock',
        sharesOrContracts: 100,
        legs: [
          {
            id: 'leg-rrsp-aapl-stk',
            type: 'stock',
            action: 'buy',
            strike: 225.0,
            expiration: 'Perpetual',
            dte: 0,
            iv: 0,
            premium: 225.0,
            contracts: 100,
            multiplier: 1,
            underlyingSymbol: 'AAPL',
          },
          {
            id: 'leg-rrsp-aapl-c',
            type: 'call',
            action: 'sell',
            strike: 235.0,
            expiration: 'NOV 26',
            dte: 45,
            iv: 0.22,
            premium: 4.0,
            contracts: 1,
            multiplier: 100,
            underlyingSymbol: 'AAPL',
          },
        ],
      },
      {
        id: 'pos-rrsp-spy',
        ticker: 'SPY',
        strategyName: 'Bull Call Debit Spread (+Δ)',
        openedAt: '11:45:00',
        contracts: 2,
        entryCost: 1420.0,
        currentMark: 1860.0,
        unrealizedPnL: 440.0,
        unrealizedPnLPercent: 30.99,
        assetCategory: 'option',
        sharesOrContracts: 2,
        legs: [
          {
            id: 'leg-rrsp-spy-c1',
            type: 'call',
            action: 'buy',
            strike: 565.0,
            expiration: 'DEC 26',
            dte: 78,
            iv: 0.145,
            premium: 12.5,
            contracts: 2,
            multiplier: 100,
            underlyingSymbol: 'SPY',
          },
          {
            id: 'leg-rrsp-spy-c2',
            type: 'call',
            action: 'sell',
            strike: 580.0,
            expiration: 'DEC 26',
            dte: 78,
            iv: 0.138,
            premium: 5.4,
            contracts: 2,
            multiplier: 100,
            underlyingSymbol: 'SPY',
          },
        ],
      },
    ],
  },

  // 3. FHSA - First Home Savings Account
  {
    id: 'act-fhsa',
    name: 'First Home Savings Account (FHSA)',
    code: 'FHSA',
    accountNumber: 'FHS-319-8472',
    institution: 'Wealthsimple Trade',
    currency: 'CAD',
    cashBalance: 8400.0,
    startingBalance: 24000.0,
    realizedPnL: 820.0,
    optionsLevel: 1,
    optionsLevelLabel: 'Level 1: Conservative Hedging & Covered Calls (Capital Preservation)',
    isRegistered: true,
    marginAllowed: false,
    color: '#ff9900',
    badge: '🇨🇦 FHSA · FIRST HOME',
    craContributionRoom: {
      annualLimit: 8000,
      usedThisYear: 8000,
      availableRoom: 0,
      lifetimeLimit: 40000,
      notes: 'Annual limit: $8,000 CAD | Lifetime limit: $40,000 CAD. Tax-deductible in, 100% tax-free out for qualifying home purchase.',
    },
    taxStatusDescription: 'Best of RRSP & TFSA: Contributions are tax-deductible, and qualifying withdrawals for down payment are 100% tax-free.',
    usWithholdingTaxNote: 'Subject to 15% IRS dividend withholding (similar to TFSA). Best held in Canadian index ETFs or high-yield cash instruments.',
    orders: [],
    positions: [
      {
        id: 'pos-fhsa-cash',
        ticker: 'CASH.TO',
        strategyName: 'High Interest Savings ETF (300 shs)',
        openedAt: '09:30:10',
        contracts: 300,
        entryCost: 15000.0,
        currentMark: 15060.0,
        unrealizedPnL: 60.0,
        unrealizedPnLPercent: 0.4,
        assetCategory: 'stock',
        sharesOrContracts: 300,
        legs: [
          {
            id: 'leg-fhsa-cash-stk',
            type: 'stock',
            action: 'buy',
            strike: 50.0,
            expiration: 'Perpetual',
            dte: 0,
            iv: 0,
            premium: 50.0,
            contracts: 300,
            multiplier: 1,
            underlyingSymbol: 'CASH.TO',
          },
        ],
      },
      {
        id: 'pos-fhsa-vfv',
        ticker: 'VFV.TO',
        strategyName: 'S&P 500 Index ETF CAD (50 shs)',
        openedAt: '10:12:00',
        contracts: 50,
        entryCost: 6750.0,
        currentMark: 6912.5,
        unrealizedPnL: 162.5,
        unrealizedPnLPercent: 2.41,
        assetCategory: 'stock',
        sharesOrContracts: 50,
        legs: [
          {
            id: 'leg-fhsa-vfv-stk',
            type: 'stock',
            action: 'buy',
            strike: 135.0,
            expiration: 'Perpetual',
            dte: 0,
            iv: 0,
            premium: 135.0,
            contracts: 50,
            multiplier: 1,
            underlyingSymbol: 'VFV.TO',
          },
        ],
      },
    ],
  },

  // 4. RESP - Registered Education Savings Plan
  {
    id: 'act-resp',
    name: 'Registered Education Savings Plan (RESP)',
    code: 'RESP',
    accountNumber: 'ESP-441-9023',
    institution: 'RBC Direct Investing',
    currency: 'CAD',
    cashBalance: 5200.0,
    startingBalance: 18000.0,
    realizedPnL: 640.0,
    optionsLevel: 1,
    optionsLevelLabel: 'Level 1: Covered Calls & Capital Preservation',
    isRegistered: true,
    marginAllowed: false,
    color: '#a855f7',
    badge: '🇨🇦 RESP · EDUCATION',
    craContributionRoom: {
      annualLimit: 5000,
      usedThisYear: 2500,
      availableRoom: 2500,
      lifetimeLimit: 50000,
      notes: 'No annual maximum contribution, but Canada Education Savings Grant (CESG 20%) matches up to $2,500/year ($500 grant). Lifetime limit $50,000.',
    },
    taxStatusDescription: 'Investment growth is tax-sheltered. Withdrawals are taxed in the student beneficiary hands (typically near zero tax bracket).',
    usWithholdingTaxNote: 'Subject to 15% US dividend withholding. CAD index funds and Canadian blue-chips recommended.',
    orders: [],
    positions: [
      {
        id: 'pos-resp-xiu',
        ticker: 'XIU.TO',
        strategyName: 'iShares S&P/TSX 60 Index (250 shs)',
        openedAt: '09:40:00',
        contracts: 250,
        entryCost: 8750.0,
        currentMark: 9100.0,
        unrealizedPnL: 350.0,
        unrealizedPnLPercent: 4.0,
        assetCategory: 'stock',
        sharesOrContracts: 250,
        legs: [
          {
            id: 'leg-resp-xiu-stk',
            type: 'stock',
            action: 'buy',
            strike: 35.0,
            expiration: 'Perpetual',
            dte: 0,
            iv: 0,
            premium: 35.0,
            contracts: 250,
            multiplier: 1,
            underlyingSymbol: 'XIU.TO',
          },
        ],
      },
      {
        id: 'pos-resp-cnq',
        ticker: 'CNQ.TO',
        strategyName: 'Canadian Natural Resources (100 shs)',
        openedAt: '10:30:00',
        contracts: 100,
        entryCost: 4600.0,
        currentMark: 4890.0,
        unrealizedPnL: 290.0,
        unrealizedPnLPercent: 6.3,
        assetCategory: 'stock',
        sharesOrContracts: 100,
        legs: [
          {
            id: 'leg-resp-cnq-stk',
            type: 'stock',
            action: 'buy',
            strike: 46.0,
            expiration: 'Perpetual',
            dte: 0,
            iv: 0,
            premium: 46.0,
            contracts: 100,
            multiplier: 1,
            underlyingSymbol: 'CNQ.TO',
          },
        ],
      },
    ],
  },

  // 5. Non-Registered Margin Account (CAD & USD)
  {
    id: 'act-margin',
    name: 'Non-Registered Margin Account',
    code: 'MARGIN_USD',
    accountNumber: 'MRG-552-8190',
    institution: 'Interactive Brokers Canada',
    currency: 'USD',
    cashBalance: 100000.0,
    startingBalance: 100000.0,
    realizedPnL: 0,
    optionsLevel: 4,
    optionsLevelLabel: 'Level 4: Full Margin, Spreads, Iron Condors, Naked Options & CME/ICE Futures',
    isRegistered: false,
    marginAllowed: true,
    color: '#ff334b',
    badge: '🇨🇦 MARGIN · TAXABLE',
    craContributionRoom: {
      annualLimit: Infinity,
      usedThisYear: 0,
      availableRoom: Infinity,
      notes: 'No CRA contribution limits. Full leverage, margin borrowing, and short selling permitted.',
    },
    taxStatusDescription: 'Taxable account. Capital gains taxed at Canadian inclusion rate (50% up to $250k, 66.7% above). Interest expense on margin borrowing is tax-deductible against investment income (CRA Line 22100).',
    usWithholdingTaxNote: '15% IRS withholding on US dividends, recoverable as Foreign Tax Credit on Canadian T1 return (Form T2209). Form T1135 foreign property reporting required if foreign cost basis > $100,000 CAD.',
    orders: [],
    positions: [
      {
        id: 'pos-margin-nvda',
        ticker: 'NVDA',
        strategyName: 'Long Stock (100 shs)',
        openedAt: '09:31:14',
        contracts: 100,
        entryCost: 12150.0,
        currentMark: 12450.0,
        unrealizedPnL: 300.0,
        unrealizedPnLPercent: 2.47,
        assetCategory: 'stock',
        sharesOrContracts: 100,
        legs: [
          {
            id: 'leg-margin-nvda-stk',
            type: 'stock',
            action: 'buy',
            strike: 121.5,
            expiration: 'Perpetual',
            dte: 0,
            iv: 0,
            premium: 121.5,
            contracts: 100,
            multiplier: 1,
            underlyingSymbol: 'NVDA',
          },
        ],
      },
      {
        id: 'pos-margin-es',
        ticker: '/ES',
        strategyName: 'Long Future (2 cts CME)',
        openedAt: '08:15:00',
        contracts: 2,
        entryCost: 578000.0,
        currentMark: 582400.0,
        unrealizedPnL: 4400.0,
        unrealizedPnLPercent: 0.76,
        assetCategory: 'future',
        sharesOrContracts: 2,
        legs: [
          {
            id: 'leg-margin-es-fut',
            type: 'future',
            action: 'buy',
            strike: 5780.0,
            expiration: 'DEC 26',
            dte: 78,
            iv: 0,
            premium: 5780.0,
            contracts: 2,
            multiplier: 50,
            underlyingSymbol: '/ES',
          },
        ],
      },
      {
        id: 'pos-margin-spy-ic',
        ticker: 'SPY',
        strategyName: 'Iron Condor (4-Leg Delta-Neutral)',
        openedAt: '10:00:00',
        contracts: 1,
        entryCost: -285.0,
        currentMark: 195.0,
        unrealizedPnL: 90.0,
        unrealizedPnLPercent: 31.58,
        assetCategory: 'option',
        sharesOrContracts: 1,
        legs: [
          {
            id: 'leg-m-ic-lp',
            type: 'put',
            action: 'buy',
            strike: 545.0,
            expiration: 'NOV 26',
            dte: 45,
            iv: 0.16,
            premium: 1.45,
            contracts: 1,
            multiplier: 100,
            underlyingSymbol: 'SPY',
          },
          {
            id: 'leg-m-ic-sp',
            type: 'put',
            action: 'sell',
            strike: 555.0,
            expiration: 'NOV 26',
            dte: 45,
            iv: 0.15,
            premium: 3.2,
            contracts: 1,
            multiplier: 100,
            underlyingSymbol: 'SPY',
          },
          {
            id: 'leg-m-ic-sc',
            type: 'call',
            action: 'sell',
            strike: 585.0,
            expiration: 'NOV 26',
            dte: 45,
            iv: 0.14,
            premium: 2.9,
            contracts: 1,
            multiplier: 100,
            underlyingSymbol: 'SPY',
          },
          {
            id: 'leg-m-ic-lc',
            type: 'call',
            action: 'buy',
            strike: 595.0,
            expiration: 'NOV 26',
            dte: 45,
            iv: 0.145,
            premium: 1.8,
            contracts: 1,
            multiplier: 100,
            underlyingSymbol: 'SPY',
          },
        ],
      },
    ],
  },
];

/**
 * CRA Restriction Alert Definition for Canadian Brokerage Accounts
 */
export interface CRARestrictionAlert {
  id: string;
  strategyName: string;
  isRestricted: boolean;
  severity: 'PROHIBITED' | 'CAUTION' | 'PERMITTED';
  ruleSource: string;
  brokerLevel: string;
  title: string;
  description: string;
  penaltyConsequence: string;
  recommendedAlternative: string;
  supportedAccounts: CanadianAccountType[];
  prohibitedAccounts: CanadianAccountType[];
}

export const CRA_RESTRICTED_STRATEGIES_CATALOG: CRARestrictionAlert[] = [
  {
    id: 'cra-short-stock',
    strategyName: 'Short Stock / Naked Short Shares',
    isRestricted: true,
    severity: 'PROHIBITED',
    ruleSource: 'Income Tax Act (ITA) Section 146.2 & CRA Bulletin IT-320R2',
    brokerLevel: 'Level 3/4 Margin Required',
    title: 'Short Selling Stock is Prohibited in Registered Plans',
    description: 'The Canada Revenue Agency (CRA) explicitly forbids borrowing and short-selling underlying equity or ETF shares inside TFSA, RRSP, FHSA, and RESP accounts.',
    penaltyConsequence: 'Subject to a 100% Advantage Tax under Section 207.05 of the Income Tax Act, plus potential deregistration of the plan.',
    recommendedAlternative: 'Buy Long Put Options or inverse exchange-traded funds (e.g., Horizons BetaPro inverse ETFs on TSX).',
    supportedAccounts: ['MARGIN_CAD', 'MARGIN_USD', 'CORPORATE'],
    prohibitedAccounts: ['TFSA', 'RRSP', 'FHSA', 'RESP'],
  },
  {
    id: 'cra-naked-call',
    strategyName: 'Naked Short Call (Uncovered Call)',
    isRestricted: true,
    severity: 'PROHIBITED',
    ruleSource: 'Income Tax Act Section 146(1) & CIRO Rule 3200',
    brokerLevel: 'Level 4 (Highest Speculation)',
    title: 'Naked Calls Prohibited (Requires 100 Shares / Long Call)',
    description: 'Uncovered calls have theoretically infinite risk. Registered plans are legally cash-only trusts and cannot expose the plan to open-ended borrowed liabilities.',
    penaltyConsequence: '100% punitive CRA Advantage Tax on any option premiums earned or short positions held.',
    recommendedAlternative: 'Write Covered Calls (hold 100 shares of the underlying equity) or purchase a higher strike long call to cap exposure.',
    supportedAccounts: ['MARGIN_CAD', 'MARGIN_USD', 'CORPORATE'],
    prohibitedAccounts: ['TFSA', 'RRSP', 'FHSA', 'RESP'],
  },
  {
    id: 'cra-iron-condor',
    strategyName: 'Iron Condor & Iron Butterfly (4-Leg Margin Spreads)',
    isRestricted: true,
    severity: 'PROHIBITED',
    ruleSource: 'CIRO (Canadian Investment Regulatory Organization) Rule 3200',
    brokerLevel: 'Level 3/4 Margin Spread',
    title: 'Multi-Leg Margin Credit Spreads Not Permitted in Registered Plans',
    description: 'Canadian brokerages (Questrade, TD Direct Investing, RBC Direct Investing, Wealthsimple) do not allow margin borrowing or multi-leg credit spread margin in cash registered accounts.',
    penaltyConsequence: 'Order will be rejected at the broker clearing gate as an ineligible registered account trade.',
    recommendedAlternative: 'Trade in a Non-Registered Margin CAD or USD account, or trade Long Call/Put Debit Spreads (where supported with full cash cover).',
    supportedAccounts: ['MARGIN_CAD', 'MARGIN_USD', 'CORPORATE'],
    prohibitedAccounts: ['TFSA', 'RRSP', 'FHSA', 'RESP'],
  },
  {
    id: 'cra-naked-put',
    strategyName: 'Naked Short Put / Cash-Secured Put',
    isRestricted: true,
    severity: 'PROHIBITED',
    ruleSource: 'CRA Qualified Investment Rules & Broker Policy',
    brokerLevel: 'Level 2/3 Cash-Secured / Margin',
    title: 'Short Put Sales are Blocked by Big-5 Canadian Banks in TFSA/RRSP',
    description: 'While CRA does not explicitly prohibit fully cash-secured puts, almost all Canadian brokerages (TD, RBC, BMO, Scotiabank, Questrade) restrict put writing in registered accounts due to assignment liability.',
    penaltyConsequence: 'Trade execution blocked by Canadian brokerage compliance engines.',
    recommendedAlternative: 'Buy the underlying stock directly and write a Covered Call (Buy-Write), which achieves the identical synthetic payoff curve.',
    supportedAccounts: ['MARGIN_CAD', 'MARGIN_USD', 'CORPORATE'],
    prohibitedAccounts: ['TFSA', 'RRSP', 'FHSA', 'RESP'],
  },
  {
    id: 'cra-futures',
    strategyName: 'Commodity & Index Futures Contracts (/ES, /CL, /NQ, /GC)',
    isRestricted: true,
    severity: 'PROHIBITED',
    ruleSource: 'Income Tax Act Qualified Investment Definition',
    brokerLevel: 'Commodity Futures Account',
    title: 'Direct Futures Cannot be Held Inside Registered Accounts',
    description: 'Futures contracts are bilateral margin derivative commitments and do not qualify as legal property held by a registered retirement or savings trust under Section 204.4.',
    penaltyConsequence: 'Futures contracts are classified as non-qualified investments subject to 50% penalty tax on fair market value under Part XI.01.',
    recommendedAlternative: 'Trade TSX or US exchange-traded index options (SPY, QQQ, USO) or ETFs.',
    supportedAccounts: ['MARGIN_CAD', 'MARGIN_USD', 'CORPORATE'],
    prohibitedAccounts: ['TFSA', 'RRSP', 'FHSA', 'RESP'],
  },
  {
    id: 'cra-covered-call',
    strategyName: 'Covered Call (Own 100 Shares + Sell 1 OTM Call)',
    isRestricted: false,
    severity: 'PERMITTED',
    ruleSource: 'CRA Qualified Registered Investment Guidelines',
    brokerLevel: 'Level 2 Approved',
    title: '100% CRA-Compliant Strategy for Registered Accounts',
    description: 'Fully permitted in TFSA, RRSP, FHSA, and RESP. Generates tax-free cash flow from underlying stock holdings.',
    penaltyConsequence: 'None. All premiums and capital gains are 100% tax-free in TFSA / tax-deferred in RRSP.',
    recommendedAlternative: 'Ideal strategy for blue-chip Canadian dividend stocks (RY.TO, ENB.TO, TD.TO, SHOP.TO).',
    supportedAccounts: ['TFSA', 'RRSP', 'FHSA', 'RESP', 'MARGIN_CAD', 'MARGIN_USD', 'CORPORATE'],
    prohibitedAccounts: [],
  },
  {
    id: 'cra-long-options',
    strategyName: 'Long Calls & Long Puts (Protective / Speculative)',
    isRestricted: false,
    severity: 'PERMITTED',
    ruleSource: 'CRA Qualified Investment Guidelines',
    brokerLevel: 'Level 2 Approved',
    title: '100% CRA-Compliant Strategy for Registered Accounts',
    description: 'Purchasing options for directional speculation or protective hedging (Married Put) is completely legal in registered accounts, as risk is strictly limited to the premium paid.',
    penaltyConsequence: 'None. Gains are 100% tax-free in TFSA.',
    recommendedAlternative: 'Excellent for asymmetric upside on growth stocks or downside crash insurance.',
    supportedAccounts: ['TFSA', 'RRSP', 'FHSA', 'RESP', 'MARGIN_CAD', 'MARGIN_USD', 'CORPORATE'],
    prohibitedAccounts: [],
  },
];

/**
 * Audit any strategy or legs for a Canadian account
 */
export function auditCanadianStrategy(
  strategyName: string,
  account: CanadianAccount,
  legs: TradeLeg[] = []
): {
  isAllowed: boolean;
  alert: CRARestrictionAlert;
  warningMessage?: string;
} {
  const normName = strategyName.toLowerCase();

  // If non-registered, all strategies are permitted
  if (!account.isRegistered) {
    return {
      isAllowed: true,
      alert: {
        id: 'margin-permitted',
        strategyName,
        isRestricted: false,
        severity: 'PERMITTED',
        ruleSource: 'Canadian Margin Account Standard Agreement',
        brokerLevel: 'Level 4 Margin',
        title: 'Permitted in Non-Registered Margin Account',
        description: 'Margin accounts have full clearing access to spreads, naked options, and futures.',
        penaltyConsequence: 'None. Taxable under normal Canadian capital gains rules.',
        recommendedAlternative: 'Proceed with standard margin risk management.',
        supportedAccounts: ['MARGIN_CAD', 'MARGIN_USD', 'CORPORATE'],
        prohibitedAccounts: [],
      },
    };
  }

  // Check specific strategy names
  if (normName.includes('condor') || normName.includes('butterfly') || normName.includes('credit spread') || normName.includes('box spread')) {
    const alert = CRA_RESTRICTED_STRATEGIES_CATALOG.find((a) => a.id === 'cra-iron-condor')!;
    return {
      isAllowed: false,
      alert,
      warningMessage: `⚠️ CRA RESTRICTION: ${strategyName} is a multi-leg margin spread prohibited in registered ${account.code} cash accounts.`,
    };
  }

  if (normName.includes('short call') || normName.includes('naked call')) {
    const alert = CRA_RESTRICTED_STRATEGIES_CATALOG.find((a) => a.id === 'cra-naked-call')!;
    return {
      isAllowed: false,
      alert,
      warningMessage: `⛔ CRA VIOLATION: Naked short calls are strictly prohibited in ${account.code}. Subject to 100% Advantage Tax.`,
    };
  }

  if (normName.includes('short put') || normName.includes('cash-secured put') || normName.includes('naked put')) {
    const alert = CRA_RESTRICTED_STRATEGIES_CATALOG.find((a) => a.id === 'cra-naked-put')!;
    return {
      isAllowed: false,
      alert,
      warningMessage: `⚠️ BROKER RESTRICTION: Short put writing is restricted in ${account.code} accounts by Canadian clearing firms.`,
    };
  }

  if (normName.includes('future') || normName.includes('/es') || normName.includes('/cl') || normName.includes('/nq')) {
    const alert = CRA_RESTRICTED_STRATEGIES_CATALOG.find((a) => a.id === 'cra-futures')!;
    return {
      isAllowed: false,
      alert,
      warningMessage: `⛔ CRA PROHIBITED: Futures contracts cannot be held in registered ${account.code} accounts.`,
    };
  }

  if (normName.includes('covered call') || normName.includes('buy-write')) {
    const alert = CRA_RESTRICTED_STRATEGIES_CATALOG.find((a) => a.id === 'cra-covered-call')!;
    return { isAllowed: true, alert };
  }

  if (normName.includes('long call') || normName.includes('long put') || normName.includes('protective put')) {
    const alert = CRA_RESTRICTED_STRATEGIES_CATALOG.find((a) => a.id === 'cra-long-options')!;
    return { isAllowed: true, alert };
  }

  // Fallback to leg inspection
  const validation = validateCanadianOptionsTrade(account, legs);
  if (!validation.allowed) {
    return {
      isAllowed: false,
      alert: {
        id: 'custom-prohibited',
        strategyName,
        isRestricted: true,
        severity: 'PROHIBITED',
        ruleSource: 'CRA Registered Account Rules',
        brokerLevel: 'Level 3/4',
        title: 'CRA Registered Account Compliance Violation',
        description: validation.reason || 'This strategy configuration violates CRA registered account rules.',
        penaltyConsequence: 'Risk of 100% CRA Advantage Tax or trade rejection at broker clearing gate.',
        recommendedAlternative: 'Use Covered Calls, Married Puts, or switch to Non-Registered Margin account.',
        supportedAccounts: ['MARGIN_CAD', 'MARGIN_USD'],
        prohibitedAccounts: ['TFSA', 'RRSP', 'FHSA', 'RESP'],
      },
      warningMessage: validation.reason,
    };
  }

  return {
    isAllowed: true,
    alert: CRA_RESTRICTED_STRATEGIES_CATALOG.find((a) => a.id === 'cra-long-options')!,
  };
}

/**
 * Validate CRA Options Trading Rules for Registered Canadian Accounts
 */
export function validateCanadianOptionsTrade(
  account: CanadianAccount,
  legs: TradeLeg[]
): {
  allowed: boolean;
  reason?: string;
  craWarning?: string;
} {
  if (!account.isRegistered) {
    // Non-registered margin account allows all levels
    return { allowed: true };
  }

  // Registered Accounts (TFSA, RRSP, FHSA, RESP)
  // Check for short stock or futures (prohibited by CRA)
  const hasShortStock = legs.some((l) => l.type === 'stock' && l.action === 'sell' && legs.length === 1);
  if (hasShortStock) {
    return {
      allowed: false,
      reason: 'CRA Violation: Short selling stock is strictly prohibited in registered Canadian accounts (TFSA/RRSP/FHSA) under the Income Tax Act.',
    };
  }

  const hasFutures = legs.some((l) => l.type === 'future');
  if (hasFutures) {
    return {
      allowed: false,
      reason: 'CRA Restriction: Direct commodity and index futures contracts (/ES, /CL) cannot be held inside registered accounts.',
    };
  }

  // Check for naked short calls or naked short puts
  const callLegs = legs.filter((l) => l.type === 'call');
  const putLegs = legs.filter((l) => l.type === 'put');
  const stockLegs = legs.filter((l) => l.type === 'stock');

  const shortCalls = callLegs.filter((l) => l.action === 'sell');
  const longCalls = callLegs.filter((l) => l.action === 'buy');
  const longStock = stockLegs.filter((l) => l.action === 'buy');

  // Covered Call check
  if (shortCalls.length > 0) {
    const isCovered = longStock.length > 0 || longCalls.length >= shortCalls.length;
    if (!isCovered) {
      return {
        allowed: false,
        reason: 'CRA Rule: Naked Short Calls are prohibited in registered accounts. You must own 100 shares of the underlying stock (Covered Call) or a long call hedge.',
      };
    }
  }

  // Multi-leg spreads with margin requirements (Iron Condor, Credit Spreads)
  if (legs.length >= 2 && !longStock.length) {
    const hasCreditRisk = legs.some((l) => l.action === 'sell');
    if (hasCreditRisk) {
      return {
        allowed: false,
        reason: `CRA & Broker Limitation: ${account.name} is a cash-only registered account. Spreads requiring margin collateral (e.g. Iron Condors, Credit Spreads) are not supported by Canadian brokerages in registered accounts. Use Level 1 & 2 strategies (Covered Calls, Long Calls, Long Puts, Married Puts).`,
      };
    }
  }

  return { allowed: true };
}

/**
 * Norbert's Gambit Currency Conversion Calculator
 * Popular strategy used by Canadian traders to convert CAD <-> USD at exact spot without 2% bank fees
 */
export interface NorbertsGambitResult {
  sourceAmount: number;
  sourceCurrency: 'CAD' | 'USD';
  targetCurrency: 'CAD' | 'USD';
  dlrSharePriceCad: number;
  dlrSharePriceUsd: number;
  sharesToTrade: number;
  grossTargetAmount: number;
  retailBankSpreadCost: number; // typical 2.0% bank markup
  norbertsGambitBrokerFee: number; // ~$10 round-trip trading commission
  netTargetAmount: number;
  netSavingsCad: number;
}

export function calculateNorbertsGambit(
  amount: number,
  direction: 'CAD_TO_USD' | 'USD_TO_CAD',
  rate: number = USDCAD_EXCHANGE_RATE
): NorbertsGambitResult {
  const dlrSharePriceUsd = 10.0;
  const dlrSharePriceCad = Number((dlrSharePriceUsd * rate).toFixed(2));

  if (direction === 'CAD_TO_USD') {
    const sharesToTrade = Math.floor(amount / dlrSharePriceCad);
    const grossTargetAmount = sharesToTrade * dlrSharePriceUsd;
    const retailBankRate = rate * 1.02; // bank takes 2% spread
    const retailBankTarget = amount / retailBankRate;
    const retailBankSpreadCost = (amount / rate) - retailBankTarget;
    const brokerFeeUsd = 7.5; // ~$10 CAD

    return {
      sourceAmount: amount,
      sourceCurrency: 'CAD',
      targetCurrency: 'USD',
      dlrSharePriceCad,
      dlrSharePriceUsd,
      sharesToTrade,
      grossTargetAmount,
      retailBankSpreadCost: Number(retailBankSpreadCost.toFixed(2)),
      norbertsGambitBrokerFee: brokerFeeUsd,
      netTargetAmount: Number((grossTargetAmount - brokerFeeUsd).toFixed(2)),
      netSavingsCad: Number(((retailBankSpreadCost - brokerFeeUsd) * rate).toFixed(2)),
    };
  } else {
    // USD to CAD
    const sharesToTrade = Math.floor(amount / dlrSharePriceUsd);
    const grossTargetAmount = sharesToTrade * dlrSharePriceCad;
    const retailBankRate = rate * 0.98;
    const retailBankTarget = amount * retailBankRate;
    const retailBankSpreadCost = (amount * rate) - retailBankTarget;
    const brokerFeeCad = 10.0;

    return {
      sourceAmount: amount,
      sourceCurrency: 'USD',
      targetCurrency: 'CAD',
      dlrSharePriceCad,
      dlrSharePriceUsd,
      sharesToTrade,
      grossTargetAmount,
      retailBankSpreadCost: Number(retailBankSpreadCost.toFixed(2)),
      norbertsGambitBrokerFee: brokerFeeCad,
      netTargetAmount: Number((grossTargetAmount - brokerFeeCad).toFixed(2)),
      netSavingsCad: Number(((retailBankSpreadCost - brokerFeeCad) * rate).toFixed(2)),
    };
  }
}

/**
 * Canadian Margin Health Metrics (CIRO / IIROC Rule 5300 & CRA Anti-Borrowing Compliance)
 */
export interface CanadianMarginHealthMetrics {
  accountId: string;
  accountName: string;
  accountCode: CanadianAccountType;
  accountNumber: string;
  institution: string;
  currency: 'CAD' | 'USD';
  isRegistered: boolean;
  optionsLevel: number;
  optionsLevelLabel: string;
  ciroRuleLabel: string;
  healthScore: number; // 0 - 100
  status: 'EXCELLENT' | 'GOOD' | 'WARNING' | 'CRITICAL';
  statusColor: string;
  netLiquidityCad: number;
  netLiquidityUsd: number;
  cashBalance: number;
  positionsMark: number;
  unrealizedPnLCad: number;
  marginRequirementNative: number;
  maintenanceReqNative: number;
  marginCushionNative: number;
  marginCushionPercent: number;
  marginDebt: number; // CRA mandate: must be $0.00 in registered accounts
  hasProhibitedBorrowing: boolean;
  foreignAssetsValNative: number;
  fxHaircutRate: number; // 3.00% under CIRO
  fxHaircutDollarCad: number;
  cipfLimitCad: number; // $1,000,000 CAD CIPF Insurance
  isCipfFullyCovered: boolean;
  isFullyCompliant: boolean;
  complianceNotes: string[];
}

/**
 * Computes Canadian Margin Health and Regulatory Compliance
 */
export function calculateCanadianMarginHealth(
  account: CanadianAccount,
  rate: number = USDCAD_EXCHANGE_RATE
): CanadianMarginHealthMetrics {
  const positionsMark = account.positions.reduce((acc, p) => acc + p.currentMark, 0);
  const netLiquidityNative = Math.max(1, account.cashBalance + positionsMark);

  const netLiquidityCad = account.currency === 'CAD'
    ? netLiquidityNative
    : Number((netLiquidityNative * rate).toFixed(2));
  const netLiquidityUsd = account.currency === 'USD'
    ? netLiquidityNative
    : Number((netLiquidityNative / rate).toFixed(2));

  const unrealizedPnLNative = account.positions.reduce((acc, p) => acc + p.unrealizedPnL, 0);
  const unrealizedPnLCad = account.currency === 'CAD'
    ? unrealizedPnLNative
    : Number((unrealizedPnLNative * rate).toFixed(2));

  let marginRequirementNative = 0;
  let foreignAssetsValNative = 0;
  const complianceNotes: string[] = [];

  // Check positions
  let hasProhibitedBorrowing = false;
  let hasNakedShortOptions = false;

  if (account.isRegistered) {
    // Registered accounts (TFSA, RRSP, FHSA, RESP)
    // 1. CRA STRICT RULE: No borrowing allowed. Cash must be >= 0.
    if (account.cashBalance < 0) {
      hasProhibitedBorrowing = true;
      complianceNotes.push(
        `CRITICAL CRA VIOLATION: Negative cash balance (-$${Math.abs(account.cashBalance).toFixed(2)} ${account.currency}) creates prohibited margin debt under Section 146/146.2 of the Income Tax Act.`
      );
    }

    // 2. Options must be covered
    account.positions.forEach((pos) => {
      const stockLegs = pos.legs.filter((l) => l.type === 'stock' && l.action === 'buy');
      const shortCallLegs = pos.legs.filter((l) => l.type === 'call' && l.action === 'sell');
      const shortPutLegs = pos.legs.filter((l) => l.type === 'put' && l.action === 'sell');

      if (shortCallLegs.length > 0) {
        const totalShortCallContracts = shortCallLegs.reduce((s, l) => s + l.contracts, 0);
        const totalStockShares = stockLegs.reduce((s, l) => s + l.contracts, 0);
        if (totalShortCallContracts * 100 > totalStockShares) {
          hasNakedShortOptions = true;
          complianceNotes.push(`CRA RESTRICTION: Naked call option on ${pos.ticker} not fully covered by 100 shares.`);
        }
      }

      if (shortPutLegs.length > 0) {
        // Cash secured puts require 100% strike cash
        const reqCash = shortPutLegs.reduce((s, l) => s + l.strike * 100 * l.contracts, 0);
        if (account.cashBalance < reqCash) {
          complianceNotes.push(`COLLATERAL WARNING: Short put on ${pos.ticker} requires $${reqCash.toLocaleString()} cash collateral.`);
        }
      }
    });

    // In registered accounts, margin requirement represents cash needed to cover trades
    marginRequirementNative = Math.max(0, -account.cashBalance);
  } else {
    // Non-registered Margin Account (CIRO Rule 5300)
    account.positions.forEach((pos) => {
      const isUsAsset = !pos.ticker.endsWith('.TO') && !pos.ticker.endsWith('.V');
      if (isUsAsset) {
        foreignAssetsValNative += Math.abs(pos.currentMark);
      }

      // CIRO margin rates: 30% on senior equities, 50% on US equities
      const marginRate = isUsAsset ? 0.50 : 0.30;
      if (pos.assetCategory === 'stock') {
        marginRequirementNative += Math.abs(pos.currentMark) * marginRate;
      } else if (pos.assetCategory === 'future') {
        marginRequirementNative += pos.contracts * (pos.ticker === '/ES' ? 12500 : 7500);
      } else {
        // Options: max loss or 30% on covered
        if (pos.entryCost < 0) {
          marginRequirementNative += Math.abs(pos.entryCost) * 1.5;
        } else {
          marginRequirementNative += Math.abs(pos.currentMark) * 0.3;
        }
      }
    });
  }

  // CIRO Maintenance Margin Requirement (75% of initial)
  const maintenanceReqNative = Number((marginRequirementNative * 0.75).toFixed(2));
  const marginCushionNative = Number((netLiquidityNative - maintenanceReqNative).toFixed(2));
  const marginCushionPercent = Number(((marginCushionNative / netLiquidityNative) * 100).toFixed(1));

  // Foreign Currency Haircut (3.00% under CIRO Rule 5300)
  const fxHaircutRate = 0.03;
  const fxHaircutDollarNative = foreignAssetsValNative * fxHaircutRate;
  const fxHaircutDollarCad = account.currency === 'CAD'
    ? Number(fxHaircutDollarNative.toFixed(2))
    : Number((fxHaircutDollarNative * rate).toFixed(2));

  // Determine Canadian Health Score & Status
  let healthScore = 100;
  let status: 'EXCELLENT' | 'GOOD' | 'WARNING' | 'CRITICAL' = 'EXCELLENT';
  let statusColor = '#00e676';

  if (account.isRegistered) {
    if (hasProhibitedBorrowing) {
      healthScore = 15;
      status = 'CRITICAL';
      statusColor = '#ff334b';
    } else if (hasNakedShortOptions) {
      healthScore = 40;
      status = 'WARNING';
      statusColor = '#ffd600';
    } else {
      healthScore = 100;
      status = 'EXCELLENT';
      statusColor = '#00e676';
      complianceNotes.push('100% Cash-Covered: 0% Margin Debt. Fully compliant with CRA Income Tax Act rules.');
    }
  } else {
    // Margin Account
    if (marginCushionNative <= 0) {
      healthScore = 10;
      status = 'CRITICAL';
      statusColor = '#ff334b';
      complianceNotes.push('CIRO Rule 5300 Margin Call: Maintenance collateral deficit. Deposit funds or liquidate positions.');
    } else if (marginCushionPercent < 25) {
      healthScore = Math.max(25, Math.round(marginCushionPercent * 2));
      status = 'WARNING';
      statusColor = '#ffd600';
      complianceNotes.push('CIRO Margin Warning: Free collateral cushion is under 25% buffer threshold.');
    } else {
      healthScore = Math.min(100, Math.round(60 + (marginCushionPercent - 25) * 0.55));
      status = 'EXCELLENT';
      statusColor = '#00e676';
      complianceNotes.push('CIRO Rule 5300 Margin Secure: Healthy equity cushion above house and regulatory minimums.');
    }
  }

  // CIPF Insurance Status
  const cipfLimitCad = 1000000;
  const isCipfFullyCovered = netLiquidityCad <= cipfLimitCad;

  const ciroRuleLabel = account.isRegistered
    ? 'CRA Anti-Leverage (ITA Sec 146.2) · Cash-Covered Only'
    : 'CIRO Rule 5300 · Portfolio Margin Standard';

  return {
    accountId: account.id,
    accountName: account.name,
    accountCode: account.code,
    accountNumber: account.accountNumber,
    institution: account.institution,
    currency: account.currency,
    isRegistered: account.isRegistered,
    optionsLevel: account.optionsLevel,
    optionsLevelLabel: account.optionsLevelLabel,
    ciroRuleLabel,
    healthScore,
    status,
    statusColor,
    netLiquidityCad,
    netLiquidityUsd,
    cashBalance: account.cashBalance,
    positionsMark,
    unrealizedPnLCad,
    marginRequirementNative: Number(marginRequirementNative.toFixed(2)),
    maintenanceReqNative,
    marginCushionNative,
    marginCushionPercent,
    marginDebt: account.isRegistered ? Math.max(0, -account.cashBalance) : 0,
    hasProhibitedBorrowing,
    foreignAssetsValNative: Number(foreignAssetsValNative.toFixed(2)),
    fxHaircutRate,
    fxHaircutDollarCad,
    cipfLimitCad,
    isCipfFullyCovered,
    isFullyCompliant: !hasProhibitedBorrowing && !hasNakedShortOptions && status !== 'CRITICAL',
    complianceNotes,
  };
}

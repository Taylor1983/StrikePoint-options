import { Ticker, ExpirationOptionChain, OptionContract, Candle, Position, TradeLeg } from '../types/options';
import { calculateBSM } from '../utils/blackScholes';

export const INITIAL_TICKERS: Record<string, Ticker> = {
  SPY: {
    symbol: 'SPY',
    name: 'SPDR S&P 500 ETF Trust',
    price: 568.25,
    change: 3.45,
    changePercent: 0.61,
    high: 569.10,
    low: 565.30,
    open: 565.80,
    previousClose: 564.80,
    volume: '54.2M',
    avgVolume: '62.8M',
    marketCap: '$524.2B',
    peRatio: '26.4',
    ivRank: 32,
    ivPercentile: 38,
    historicalVol30d: 0.138,
    currentIV: 0.145,
    beta: 1.0,
    week52High: 574.80,
    week52Low: 490.20,
    candles: generateHistoricalCandles(568.25, 60, 0.008),
  },
  QQQ: {
    symbol: 'QQQ',
    name: 'Invesco QQQ Trust (Nasdaq 100)',
    price: 488.60,
    change: 4.80,
    changePercent: 0.99,
    high: 490.15,
    low: 484.50,
    open: 485.20,
    previousClose: 483.80,
    volume: '38.6M',
    avgVolume: '45.1M',
    marketCap: '$282.1B',
    peRatio: '31.2',
    ivRank: 39,
    ivPercentile: 44,
    historicalVol30d: 0.185,
    currentIV: 0.198,
    beta: 1.18,
    week52High: 503.50,
    week52Low: 398.20,
    candles: generateHistoricalCandles(488.60, 60, 0.012),
  },
  NVDA: {
    symbol: 'NVDA',
    name: 'NVIDIA Corporation',
    price: 129.40,
    change: 3.85,
    changePercent: 3.07,
    high: 130.65,
    low: 125.80,
    open: 126.10,
    previousClose: 125.55,
    volume: '64.1M',
    avgVolume: '58.4M',
    marketCap: '$3.18T',
    peRatio: '48.6',
    ivRank: 58,
    ivPercentile: 64,
    historicalVol30d: 0.42,
    currentIV: 0.46,
    beta: 1.94,
    week52High: 140.76,
    week52Low: 75.60,
    candles: generateHistoricalCandles(129.40, 60, 0.024),
    assetType: 'equity',
    daysToEarnings: 48,
    earningsDate: 'Nov 19, 2026',
    earningsEstimatedMovePct: 7.8,
    earningsIvTrend5d: [41.2, 43.5, 46.8, 51.4, 55.6],
  },
  TSLA: {
    symbol: 'TSLA',
    name: 'Tesla, Inc.',
    price: 248.50,
    change: -2.30,
    changePercent: -0.92,
    high: 253.40,
    low: 246.10,
    open: 251.20,
    previousClose: 250.80,
    volume: '71.3M',
    avgVolume: '82.0M',
    marketCap: '$792.5B',
    peRatio: '68.2',
    ivRank: 66,
    ivPercentile: 71,
    historicalVol30d: 0.49,
    currentIV: 0.52,
    beta: 2.15,
    week52High: 271.00,
    week52Low: 138.80,
    candles: generateHistoricalCandles(248.50, 60, 0.028),
    assetType: 'equity',
    daysToEarnings: 19,
    earningsDate: 'Oct 21, 2026',
    earningsEstimatedMovePct: 8.5,
    earningsIvTrend5d: [45.8, 47.9, 50.2, 53.6, 58.0],
  },
  AAPL: {
    symbol: 'AAPL',
    name: 'Apple Inc.',
    price: 227.80,
    change: 1.15,
    changePercent: 0.51,
    high: 228.90,
    low: 226.40,
    open: 226.90,
    previousClose: 226.65,
    volume: '42.9M',
    avgVolume: '48.3M',
    marketCap: '$3.47T',
    peRatio: '33.8',
    ivRank: 24,
    ivPercentile: 29,
    historicalVol30d: 0.175,
    currentIV: 0.188,
    beta: 0.92,
    week52High: 237.23,
    week52Low: 164.08,
    candles: generateHistoricalCandles(227.80, 60, 0.010),
    assetType: 'equity',
    daysToEarnings: 28,
    earningsDate: 'Oct 30, 2026',
    earningsEstimatedMovePct: 4.2,
    earningsIvTrend5d: [16.4, 17.2, 18.0, 19.1, 20.8],
  },
  AMZN: {
    symbol: 'AMZN',
    name: 'Amazon.com, Inc.',
    price: 187.90,
    change: 2.10,
    changePercent: 1.13,
    high: 189.20,
    low: 185.90,
    open: 186.40,
    previousClose: 185.80,
    volume: '34.5M',
    avgVolume: '41.2M',
    marketCap: '$1.96T',
    peRatio: '42.1',
    ivRank: 31,
    ivPercentile: 36,
    historicalVol30d: 0.23,
    currentIV: 0.25,
    beta: 1.14,
    week52High: 201.20,
    week52Low: 118.35,
    candles: generateHistoricalCandles(187.90, 60, 0.015),
    assetType: 'equity',
    daysToEarnings: 26,
    earningsDate: 'Oct 28, 2026',
    earningsEstimatedMovePct: 6.1,
    earningsIvTrend5d: [21.8, 23.2, 24.8, 26.5, 29.2],
  },
  META: {
    symbol: 'META',
    name: 'Meta Platforms, Inc.',
    price: 568.40,
    change: 8.75,
    changePercent: 1.56,
    high: 571.20,
    low: 561.10,
    open: 562.50,
    previousClose: 559.65,
    volume: '16.4M',
    avgVolume: '14.8M',
    marketCap: '$1.44T',
    peRatio: '28.9',
    ivRank: 42,
    ivPercentile: 48,
    historicalVol30d: 0.28,
    currentIV: 0.31,
    beta: 1.25,
    week52High: 574.00,
    week52Low: 298.50,
    candles: generateHistoricalCandles(568.40, 60, 0.018),
    assetType: 'equity',
    daysToEarnings: 27,
    earningsDate: 'Oct 29, 2026',
    earningsEstimatedMovePct: 6.9,
    earningsIvTrend5d: [27.4, 29.0, 31.0, 33.5, 37.0],
  },
  MSFT: {
    symbol: 'MSFT',
    name: 'Microsoft Corporation',
    price: 432.10,
    change: 1.80,
    changePercent: 0.42,
    high: 434.50,
    low: 430.20,
    open: 431.00,
    previousClose: 430.30,
    volume: '18.9M',
    avgVolume: '21.5M',
    marketCap: '$3.21T',
    peRatio: '35.4',
    ivRank: 22,
    ivPercentile: 27,
    historicalVol30d: 0.165,
    currentIV: 0.178,
    beta: 0.89,
    week52High: 468.35,
    week52Low: 309.45,
    candles: generateHistoricalCandles(432.10, 60, 0.011),
    assetType: 'equity',
    daysToEarnings: 24,
    earningsDate: 'Oct 26, 2026',
    earningsEstimatedMovePct: 4.5,
    earningsIvTrend5d: [15.6, 16.3, 17.1, 18.5, 20.0],
  },
  AMD: {
    symbol: 'AMD',
    name: 'Advanced Micro Devices',
    price: 156.80,
    change: 4.15,
    changePercent: 2.72,
    high: 158.40,
    low: 152.90,
    open: 153.20,
    previousClose: 152.65,
    volume: '44.8M',
    avgVolume: '51.2M',
    marketCap: '$253.9B',
    peRatio: '112.4',
    ivRank: 51,
    ivPercentile: 57,
    historicalVol30d: 0.38,
    currentIV: 0.42,
    beta: 1.72,
    week52High: 227.30,
    week52Low: 94.04,
    candles: generateHistoricalCandles(156.80, 60, 0.026),
    assetType: 'equity',
    daysToEarnings: 29,
    earningsDate: 'Oct 31, 2026',
    earningsEstimatedMovePct: 7.2,
    earningsIvTrend5d: [35.8, 37.6, 40.2, 43.1, 46.5],
  },
  BP: {
    symbol: 'BP',
    name: 'BP p.l.c. (British Petroleum)',
    price: 33.45,
    change: 0.42,
    changePercent: 1.27,
    high: 33.80,
    low: 33.05,
    open: 33.15,
    previousClose: 33.03,
    volume: '9.8M',
    avgVolume: '11.4M',
    marketCap: '$94.6B',
    peRatio: '11.8',
    ivRank: 28,
    ivPercentile: 34,
    historicalVol30d: 0.19,
    currentIV: 0.205,
    beta: 0.74,
    week52High: 39.80,
    week52Low: 29.20,
    candles: generateHistoricalCandles(33.45, 60, 0.012),
    assetType: 'equity',
    daysToEarnings: 33,
    earningsDate: 'Nov 04, 2026',
    earningsEstimatedMovePct: 3.8,
    earningsIvTrend5d: [18.5, 19.1, 19.8, 20.6, 22.0],
  },
  DJT: {
    symbol: 'DJT',
    name: 'Trump Media & Technology Group Corp.',
    price: 31.50,
    change: -1.25,
    changePercent: -3.82,
    high: 33.40,
    low: 30.80,
    open: 32.80,
    previousClose: 32.75,
    volume: '18.4M',
    avgVolume: '14.2M',
    marketCap: '$6.12B',
    peRatio: 'N/A',
    ivRank: 88,
    ivPercentile: 94,
    historicalVol30d: 0.82,
    currentIV: 0.96,
    beta: 3.40,
    week52High: 79.38,
    week52Low: 11.75,
    candles: generateHistoricalCandles(31.50, 60, 0.055),
    assetType: 'equity',
    daysToEarnings: 42,
    earningsDate: 'Nov 12, 2026',
    earningsEstimatedMovePct: 15.4,
    earningsIvTrend5d: [82.5, 86.4, 91.2, 94.0, 98.5],
  },
  // FUTURES & OPTIONS ON FUTURES (FOP)
  '/ES': {
    symbol: '/ES',
    name: 'E-mini S&P 500 Index Futures',
    price: 5742.50,
    change: 26.50,
    changePercent: 0.46,
    high: 5754.00,
    low: 5721.25,
    open: 5725.00,
    previousClose: 5716.00,
    volume: '1.24M',
    avgVolume: '1.45M',
    marketCap: '$28.7T Notional',
    peRatio: '24.8',
    ivRank: 31,
    ivPercentile: 36,
    historicalVol30d: 0.132,
    currentIV: 0.141,
    beta: 1.0,
    week52High: 5800.00,
    week52Low: 4950.00,
    candles: generateHistoricalCandles(5742.50, 60, 0.006),
    assetType: 'future',
    multiplier: 50, // $50 per index point
    tickSize: 0.25,
    daysToEarnings: null,
  },
  '/NQ': {
    symbol: '/NQ',
    name: 'E-mini Nasdaq 100 Futures',
    price: 20185.00,
    change: 172.50,
    changePercent: 0.86,
    high: 20240.00,
    low: 20045.00,
    open: 20070.00,
    previousClose: 20012.50,
    volume: '580K',
    avgVolume: '620K',
    marketCap: '$19.2T Notional',
    peRatio: '29.4',
    ivRank: 37,
    ivPercentile: 42,
    historicalVol30d: 0.178,
    currentIV: 0.192,
    beta: 1.16,
    week52High: 20800.00,
    week52Low: 16800.00,
    candles: generateHistoricalCandles(20185.00, 60, 0.009),
    assetType: 'future',
    multiplier: 20, // $20 per index point
    tickSize: 0.25,
    daysToEarnings: null,
  },
  '/CL': {
    symbol: '/CL',
    name: 'Crude Oil WTI Futures (Light Sweet)',
    price: 68.45,
    change: 0.95,
    changePercent: 1.41,
    high: 69.20,
    low: 67.80,
    open: 67.95,
    previousClose: 67.50,
    volume: '340K',
    avgVolume: '410K',
    marketCap: 'Commodity Physical',
    peRatio: 'N/A',
    ivRank: 44,
    ivPercentile: 49,
    historicalVol30d: 0.28,
    currentIV: 0.31,
    beta: 0.42,
    week52High: 88.50,
    week52Low: 64.20,
    candles: generateHistoricalCandles(68.45, 60, 0.016),
    assetType: 'future',
    multiplier: 1000, // 1,000 barrels ($1,000 per $1.00 move)
    tickSize: 0.01,
    daysToEarnings: null,
  },
  '/GC': {
    symbol: '/GC',
    name: 'Gold Comex Futures',
    price: 2682.40,
    change: 11.20,
    changePercent: 0.42,
    high: 2690.00,
    low: 2674.50,
    open: 2676.00,
    previousClose: 2671.20,
    volume: '220K',
    avgVolume: '245K',
    marketCap: 'Precious Metals',
    peRatio: 'N/A',
    ivRank: 35,
    ivPercentile: 40,
    historicalVol30d: 0.145,
    currentIV: 0.158,
    beta: 0.12,
    week52High: 2715.00,
    week52Low: 1980.00,
    candles: generateHistoricalCandles(2682.40, 60, 0.005),
    assetType: 'future',
    multiplier: 100, // 100 troy oz ($100 per $1.00 move)
    tickSize: 0.10,
    daysToEarnings: null,
  },
  '/BTC': {
    symbol: '/BTC',
    name: 'Bitcoin CME Futures',
    price: 64250.00,
    change: 1420.00,
    changePercent: 2.26,
    high: 64900.00,
    low: 63100.00,
    open: 63250.00,
    previousClose: 62830.00,
    volume: '18.4K',
    avgVolume: '22.1K',
    marketCap: '$1.28T Asset',
    peRatio: 'N/A',
    ivRank: 52,
    ivPercentile: 58,
    historicalVol30d: 0.52,
    currentIV: 0.56,
    beta: 1.85,
    week52High: 73800.00,
    week52Low: 38500.00,
    candles: generateHistoricalCandles(64250.00, 60, 0.022),
    assetType: 'future',
    multiplier: 5, // 5 Bitcoin per contract
    tickSize: 5.00,
    daysToEarnings: null,
  },
  '/ZB': {
    symbol: '/ZB',
    name: '30-Year U.S. Treasury Bond Futures',
    price: 118.50,
    change: -0.45,
    changePercent: -0.38,
    high: 119.20,
    low: 118.15,
    open: 118.95,
    previousClose: 118.95,
    volume: '290K',
    avgVolume: '340K',
    marketCap: 'US Sovereign Debt',
    peRatio: 'N/A',
    ivRank: 26,
    ivPercentile: 30,
    historicalVol30d: 0.11,
    currentIV: 0.118,
    beta: -0.35,
    week52High: 126.00,
    week52Low: 110.00,
    candles: generateHistoricalCandles(118.50, 60, 0.004),
    assetType: 'future',
    multiplier: 1000, // $1,000 per point
    tickSize: 0.03125,
    daysToEarnings: null,
  },
  '/RTY': {
    symbol: '/RTY',
    name: 'E-mini Russell 2000 Index Futures',
    price: 2224.50,
    change: 14.80,
    changePercent: 0.67,
    high: 2232.00,
    low: 2208.50,
    open: 2212.00,
    previousClose: 2209.70,
    volume: '310K',
    avgVolume: '360K',
    marketCap: '$2.8T Notional',
    peRatio: '21.5',
    ivRank: 38,
    ivPercentile: 43,
    historicalVol30d: 0.195,
    currentIV: 0.208,
    beta: 1.22,
    week52High: 2300.00,
    week52Low: 1720.00,
    candles: generateHistoricalCandles(2224.50, 60, 0.014),
    assetType: 'future',
    multiplier: 50, // $50 per index point
    tickSize: 0.10,
    daysToEarnings: null,
  },
  '/NG': {
    symbol: '/NG',
    name: 'Natural Gas Henry Hub Futures',
    price: 2.885,
    change: 0.065,
    changePercent: 2.30,
    high: 2.940,
    low: 2.810,
    open: 2.825,
    previousClose: 2.820,
    volume: '185K',
    avgVolume: '210K',
    marketCap: 'Energy Commodity',
    peRatio: 'N/A',
    ivRank: 62,
    ivPercentile: 68,
    historicalVol30d: 0.55,
    currentIV: 0.61,
    beta: 0.28,
    week52High: 3.65,
    week52Low: 1.52,
    candles: generateHistoricalCandles(2.885, 60, 0.035),
    assetType: 'future',
    multiplier: 10000, // 10,000 MMBtu ($10,000 per $1.00 move)
    tickSize: 0.001,
    daysToEarnings: null,
  },
  '/SI': {
    symbol: '/SI',
    name: 'Silver Comex 5,000oz Futures',
    price: 32.15,
    change: 0.48,
    changePercent: 1.52,
    high: 32.45,
    low: 31.60,
    open: 31.75,
    previousClose: 31.67,
    volume: '95K',
    avgVolume: '110K',
    marketCap: 'Precious Metals',
    peRatio: 'N/A',
    ivRank: 48,
    ivPercentile: 53,
    historicalVol30d: 0.28,
    currentIV: 0.315,
    beta: 0.65,
    week52High: 33.20,
    week52Low: 21.80,
    candles: generateHistoricalCandles(32.15, 60, 0.018),
    assetType: 'future',
    multiplier: 5000, // 5,000 troy oz ($5,000 per $1.00 move)
    tickSize: 0.005,
    daysToEarnings: null,
  },
  '/6E': {
    symbol: '/6E',
    name: 'Euro FX CME Currency Futures',
    price: 1.1165,
    change: 0.0028,
    changePercent: 0.25,
    high: 1.1185,
    low: 1.1130,
    open: 1.1140,
    previousClose: 1.1137,
    volume: '260K',
    avgVolume: '290K',
    marketCap: 'Foreign Exchange FX',
    peRatio: 'N/A',
    ivRank: 22,
    ivPercentile: 26,
    historicalVol30d: 0.075,
    currentIV: 0.082,
    beta: 0.15,
    week52High: 1.1240,
    week52Low: 1.0600,
    candles: generateHistoricalCandles(1.1165, 60, 0.003),
    assetType: 'future',
    multiplier: 125000, // 125,000 EUR
    tickSize: 0.00005,
    daysToEarnings: null,
  },
  '/ZN': {
    symbol: '/ZN',
    name: '10-Year U.S. Treasury Note Futures',
    price: 113.85,
    change: -0.22,
    changePercent: -0.19,
    high: 114.25,
    low: 113.60,
    open: 114.10,
    previousClose: 114.07,
    volume: '1.45M',
    avgVolume: '1.65M',
    marketCap: 'US Sovereign Benchmark',
    peRatio: 'N/A',
    ivRank: 24,
    ivPercentile: 28,
    historicalVol30d: 0.085,
    currentIV: 0.092,
    beta: -0.25,
    week52High: 116.50,
    week52Low: 107.00,
    candles: generateHistoricalCandles(113.85, 60, 0.003),
    assetType: 'future',
    multiplier: 1000, // $1,000 per point
    tickSize: 0.015625,
    daysToEarnings: null,
  },
  '/ETH': {
    symbol: '/ETH',
    name: 'Ether CME Futures',
    price: 2680.00,
    change: 78.50,
    changePercent: 3.02,
    high: 2720.00,
    low: 2590.00,
    open: 2615.00,
    previousClose: 2601.50,
    volume: '34K',
    avgVolume: '42K',
    marketCap: '$320B Asset',
    peRatio: 'N/A',
    ivRank: 56,
    ivPercentile: 62,
    historicalVol30d: 0.58,
    currentIV: 0.63,
    beta: 2.10,
    week52High: 4080.00,
    week52Low: 1520.00,
    candles: generateHistoricalCandles(2680.00, 60, 0.026),
    assetType: 'future',
    multiplier: 50, // 50 Ether per contract
    tickSize: 0.50,
    daysToEarnings: null,
  },
  // DEFENSE PRIMES & DEFCON MONITORING
  LMT: {
    symbol: 'LMT',
    name: 'Lockheed Martin Corporation',
    price: 582.40,
    change: 9.85,
    changePercent: 1.72,
    high: 585.50,
    low: 576.20,
    open: 577.00,
    previousClose: 572.55,
    volume: '1.45M',
    avgVolume: '1.62M',
    marketCap: '$139.8B',
    peRatio: '20.6',
    ivRank: 64,
    ivPercentile: 70,
    historicalVol30d: 0.21,
    currentIV: 0.245,
    beta: 0.62,
    week52High: 614.49,
    week52Low: 419.00,
    candles: generateHistoricalCandles(582.40, 60, 0.012),
    assetType: 'equity',
    daysToEarnings: 18,
    earningsDate: 'Oct 20, 2026',
    earningsEstimatedMovePct: 3.9,
    earningsIvTrend5d: [21.5, 22.0, 22.8, 23.6, 24.5],
  },
  RTX: {
    symbol: 'RTX',
    name: 'RTX Corporation (Raytheon)',
    price: 124.60,
    change: 2.10,
    changePercent: 1.71,
    high: 125.40,
    low: 123.10,
    open: 123.30,
    previousClose: 122.50,
    volume: '5.8M',
    avgVolume: '6.4M',
    marketCap: '$165.2B',
    peRatio: '32.1',
    ivRank: 58,
    ivPercentile: 62,
    historicalVol30d: 0.195,
    currentIV: 0.228,
    beta: 0.78,
    week52High: 128.70,
    week52Low: 77.00,
    candles: generateHistoricalCandles(124.60, 60, 0.011),
    assetType: 'equity',
    daysToEarnings: 20,
    earningsDate: 'Oct 22, 2026',
    earningsEstimatedMovePct: 4.2,
    earningsIvTrend5d: [20.0, 20.8, 21.5, 22.1, 22.8],
  },
  NOC: {
    symbol: 'NOC',
    name: 'Northrop Grumman Corp',
    price: 538.90,
    change: 11.20,
    changePercent: 2.12,
    high: 541.80,
    low: 531.00,
    open: 532.00,
    previousClose: 527.70,
    volume: '820K',
    avgVolume: '910K',
    marketCap: '$79.4B',
    peRatio: '28.4',
    ivRank: 71,
    ivPercentile: 77,
    historicalVol30d: 0.23,
    currentIV: 0.262,
    beta: 0.58,
    week52High: 554.00,
    week52Low: 422.00,
    candles: generateHistoricalCandles(538.90, 60, 0.013),
    assetType: 'equity',
    daysToEarnings: 22,
    earningsDate: 'Oct 24, 2026',
    earningsEstimatedMovePct: 4.6,
    earningsIvTrend5d: [23.1, 23.9, 24.8, 25.5, 26.2],
  },
  // CANADIAN REGISTERED & TSX BLUE CHIPS (TFSA / RRSP / RESP)
  'RY.TO': {
    symbol: 'RY.TO',
    name: 'Royal Bank of Canada (TSX: RY)',
    price: 167.50,
    change: 1.45,
    changePercent: 0.87,
    high: 168.20,
    low: 166.40,
    open: 166.80,
    previousClose: 166.05,
    volume: '2.8M',
    avgVolume: '3.1M',
    marketCap: '$236.4B CAD',
    peRatio: '14.2',
    ivRank: 26,
    ivPercentile: 31,
    historicalVol30d: 0.142,
    currentIV: 0.158,
    beta: 0.82,
    week52High: 172.50,
    week52Low: 116.80,
    candles: generateHistoricalCandles(167.50, 60, 0.009),
    assetType: 'equity',
    daysToEarnings: 42,
    earningsDate: 'Nov 13, 2026',
    earningsEstimatedMovePct: 3.1,
    earningsIvTrend5d: [14.5, 14.8, 15.1, 15.4, 15.8],
  },
  'SHOP.TO': {
    symbol: 'SHOP.TO',
    name: 'Shopify Inc. (TSX: SHOP)',
    price: 104.20,
    change: 3.60,
    changePercent: 3.58,
    high: 105.80,
    low: 101.50,
    open: 101.90,
    previousClose: 100.60,
    volume: '4.6M',
    avgVolume: '5.2M',
    marketCap: '$134.8B CAD',
    peRatio: '78.5',
    ivRank: 52,
    ivPercentile: 58,
    historicalVol30d: 0.36,
    currentIV: 0.395,
    beta: 2.15,
    week52High: 122.40,
    week52Low: 64.20,
    candles: generateHistoricalCandles(104.20, 60, 0.024),
    assetType: 'equity',
    daysToEarnings: 34,
    earningsDate: 'Nov 05, 2026',
    earningsEstimatedMovePct: 7.8,
    earningsIvTrend5d: [34.0, 35.5, 37.0, 38.2, 39.5],
  },
  'ENB.TO': {
    symbol: 'ENB.TO',
    name: 'Enbridge Inc. (TSX: ENB)',
    price: 54.80,
    change: 0.65,
    changePercent: 1.20,
    high: 55.10,
    low: 54.25,
    open: 54.30,
    previousClose: 54.15,
    volume: '7.1M',
    avgVolume: '8.4M',
    marketCap: '$116.5B CAD',
    peRatio: '17.8',
    ivRank: 24,
    ivPercentile: 29,
    historicalVol30d: 0.135,
    currentIV: 0.148,
    beta: 0.68,
    week52High: 56.40,
    week52Low: 42.10,
    candles: generateHistoricalCandles(54.80, 60, 0.008),
    assetType: 'equity',
    daysToEarnings: 27,
    earningsDate: 'Oct 29, 2026',
    earningsEstimatedMovePct: 2.8,
    earningsIvTrend5d: [13.8, 14.1, 14.3, 14.5, 14.8],
  },
  'DLR.TO': {
    symbol: 'DLR.TO',
    name: "Horizons US Dollar Currency ETF (TSX: DLR - Norbert's Gambit CAD)",
    price: 13.68,
    change: 0.03,
    changePercent: 0.22,
    high: 13.70,
    low: 13.65,
    open: 13.66,
    previousClose: 13.65,
    volume: '850K',
    avgVolume: '920K',
    marketCap: '$1.4B CAD',
    peRatio: 'N/A',
    ivRank: 12,
    ivPercentile: 14,
    historicalVol30d: 0.045,
    currentIV: 0.052,
    beta: 0.18,
    week52High: 13.92,
    week52Low: 13.15,
    candles: generateHistoricalCandles(13.68, 60, 0.002),
    assetType: 'equity',
    daysToEarnings: null,
  },
};

export const INITIAL_MACRO_INDICES: import('../types/options').MacroIndexQuote[] = [
  { symbol: 'SPX', name: 'S&P 500 INDEX', value: 5738.17, change: 24.34, changePct: 0.43 },
  { symbol: 'NDX', name: 'NASDAQ 100', value: 20112.45, change: 168.20, changePct: 0.84 },
  { symbol: 'RUT', name: 'RUSSELL 2000', value: 2228.60, change: 12.10, changePct: 0.55 },
  { symbol: 'VIX', name: 'CBOE VOLATILITY', value: 15.35, change: -0.62, changePct: -3.88 },
  { symbol: 'US10Y', name: '10-YR BENCHMARK', value: 3.754, change: -0.021, changePct: -0.56, isRateOrYield: true },
  { symbol: 'DXY', name: 'USD CURRENCY INDEX', value: 100.82, change: 0.12, changePct: 0.12 },
  { symbol: 'CL1', name: 'WTI CRUDE FUTURE', value: 71.35, change: 0.85, changePct: 1.21 },
  { symbol: 'OVX', name: 'CRUDE OIL VOL INDEX', value: 38.60, change: 1.45, changePct: 3.90 },
  { symbol: 'XAU', name: 'SPOT GOLD', value: 2658.40, change: 9.80, changePct: 0.37 },
  { symbol: 'BTC', name: 'BITCOIN / USD', value: 65890.00, change: 1420.00, changePct: 2.20 },
];

export const INITIAL_FLOW_SEED: import('../types/options').UnusualFlowItem[] = [
  {
    id: 'fl-1',
    time: '15:58:42',
    ticker: 'NVDA',
    strike: 135.0,
    type: 'CALL',
    expiration: 'Oct 18, 2026',
    dte: 21,
    spot: 129.40,
    orderType: 'SWEEP',
    sentiment: 'BULLISH',
    contracts: 4500,
    premium: 1890000,
    pricePerShare: 4.20,
    impliedVol: 0.47,
    openInterest: 12450,
    volume: 38200,
    exchange: 'PHLX',
    details: 'Above ask aggression · Whale repeat buyer',
  },
  {
    id: 'fl-2',
    time: '15:56:10',
    ticker: 'SPY',
    strike: 565.0,
    type: 'PUT',
    expiration: 'Oct 04, 2026',
    dte: 7,
    spot: 568.25,
    orderType: 'BLOCK',
    sentiment: 'BEARISH',
    contracts: 2200,
    premium: 858000,
    pricePerShare: 3.90,
    impliedVol: 0.158,
    openInterest: 8400,
    volume: 16900,
    exchange: 'CBOE',
    details: 'Cross-venue block hedge · Near-the-money put',
  },
  {
    id: 'fl-3',
    time: '15:51:33',
    ticker: 'TSLA',
    strike: 260.0,
    type: 'CALL',
    expiration: 'Nov 15, 2026',
    dte: 49,
    spot: 248.50,
    orderType: 'SWEEP',
    sentiment: 'BULLISH',
    contracts: 3100,
    premium: 3255000,
    pricePerShare: 10.50,
    impliedVol: 0.54,
    openInterest: 5120,
    volume: 14200,
    exchange: 'ARCA',
    details: 'Golden Sweep · Multiexchange execution at ask',
  },
  {
    id: 'fl-4',
    time: '15:47:05',
    ticker: 'META',
    strike: 580.0,
    type: 'CALL',
    expiration: 'Oct 25, 2026',
    dte: 28,
    spot: 568.40,
    orderType: 'SWEEP',
    sentiment: 'BULLISH',
    contracts: 1250,
    premium: 1687500,
    pricePerShare: 13.50,
    impliedVol: 0.32,
    openInterest: 1890,
    volume: 7850,
    exchange: 'BOX',
    details: 'Vol > OI · Aggressive upside positioning',
  },
  {
    id: 'fl-5',
    time: '15:42:19',
    ticker: 'AAPL',
    strike: 225.0,
    type: 'PUT',
    expiration: 'Oct 11, 2026',
    dte: 14,
    spot: 227.80,
    orderType: 'SPLIT',
    sentiment: 'BEARISH',
    contracts: 3800,
    premium: 988000,
    pricePerShare: 2.60,
    impliedVol: 0.19,
    openInterest: 15300,
    volume: 24100,
    exchange: 'EDGX',
    details: 'Split lot dark pool printed at bid',
  },
  {
    id: 'fl-6',
    time: '15:38:50',
    ticker: 'AMD',
    strike: 165.0,
    type: 'CALL',
    expiration: 'Nov 01, 2026',
    dte: 35,
    spot: 156.80,
    orderType: 'SWEEP',
    sentiment: 'BULLISH',
    contracts: 2800,
    premium: 1736000,
    pricePerShare: 6.20,
    impliedVol: 0.44,
    openInterest: 3200,
    volume: 11400,
    exchange: 'PHLX',
    details: 'Size exceeded open interest by 3.5x',
  },
];

export function generateRandomFlowItem(tickers: Record<string, import('../types/options').Ticker>): import('../types/options').UnusualFlowItem {
  const symbols = Object.keys(tickers);
  const sym = symbols[Math.floor(Math.random() * symbols.length)];
  const t = tickers[sym] || tickers['SPY'];
  const isCall = Math.random() > 0.45;
  const isSweep = Math.random() > 0.35;
  const exchanges: ('CBOE' | 'PHLX' | 'BOX' | 'ARCA' | 'EDGX')[] = ['CBOE', 'PHLX', 'BOX', 'ARCA', 'EDGX'];
  const ex = exchanges[Math.floor(Math.random() * exchanges.length)];

  const step = t.price > 300 ? 5 : 2.5;
  const strikeOffset = (Math.floor(Math.random() * 5) - 2) * step;
  const strike = Math.round((t.price + strikeOffset) / step) * step;

  const dteDays = [7, 14, 21, 35, 60, 90][Math.floor(Math.random() * 6)];
  const expDate = new Date();
  expDate.setDate(expDate.getDate() + dteDays);
  const expirationStr = expDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

  const contracts = Math.floor(500 + Math.random() * 4500);
  const pps = Number((Math.max(0.5, (t.price * 0.025) * (0.8 + Math.random() * 0.5))).toFixed(2));
  const premium = Math.round(contracts * pps * 100);

  const now = new Date();
  const timeStr = now.toTimeString().split(' ')[0];

  const sentiment = isCall ? (Math.random() > 0.2 ? 'BULLISH' : 'NEUTRAL') : (Math.random() > 0.2 ? 'BEARISH' : 'NEUTRAL');

  return {
    id: `fl-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    time: timeStr,
    ticker: sym,
    strike,
    type: isCall ? 'CALL' : 'PUT',
    expiration: expirationStr,
    dte: dteDays,
    spot: t.price,
    orderType: isSweep ? 'SWEEP' : 'BLOCK',
    sentiment: sentiment as 'BULLISH' | 'BEARISH' | 'NEUTRAL',
    contracts,
    premium,
    pricePerShare: pps,
    impliedVol: Number((t.currentIV * (0.95 + Math.random() * 0.15)).toFixed(3)),
    openInterest: Math.floor(1000 + Math.random() * 15000),
    volume: Math.floor(contracts * (1.2 + Math.random() * 2)),
    exchange: ex,
    details: isSweep ? 'Aggressive sweep executed across multiple venues' : 'Institutional single block dark trade',
  };
}


function generateHistoricalCandles(basePrice: number, count: number, volatility: number): Candle[] {
  const candles: Candle[] = [];
  const totalDays = Math.max(count, 310); // Provide rich historical data for 200-day SMA, 1M, 3M, 6M, 1Y technical analysis
  let curr = basePrice * 0.84;
  const now = new Date();

  for (let i = totalDays; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    // skip weekends
    if (d.getDay() === 0 || d.getDay() === 6) continue;

    const drift = 0.0007; // slight upward drift
    const changePct = (Math.random() - 0.485) * volatility + drift;
    const open = curr;
    const close = Math.max(1, curr * (1 + changePct));
    const high = Math.max(open, close) * (1 + Math.random() * (volatility * 0.5));
    const low = Math.min(open, close) * (1 - Math.random() * (volatility * 0.5));
    const volume = Math.floor(20000000 + Math.random() * 35000000);

    curr = close;

    candles.push({
      time: d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(close.toFixed(2)),
      volume,
    });
  }

  // Force last candle close to match current price
  if (candles.length > 0) {
    candles[candles.length - 1].close = basePrice;
  }

  return candles;
}

export interface ExpirationPreset {
  days: number;
  label: string;
  category: 'Weekly' | 'Monthly' | 'Quarterly' | 'LEAPS';
  month: string;       // e.g. 'SEP', 'OCT', 'NOV', 'DEC', etc.
  monthYear: string;   // e.g. "SEP '26", "DEC '26"
  dateLabel: string;   // e.g. "29 SEP 26", "18 DEC 26"
}

export const EXPIRATION_PRESETS: ExpirationPreset[] = [
  { days: 0, label: "29 SEP '26 (0d)", category: 'Weekly', month: 'SEP', monthYear: "SEP '26", dateLabel: '29 SEP 26' },
  { days: 3, label: "02 OCT '26 (3d)", category: 'Weekly', month: 'OCT', monthYear: "OCT '26", dateLabel: '02 OCT 26' },
  { days: 10, label: "09 OCT '26 (10d)", category: 'Weekly', month: 'OCT', monthYear: "OCT '26", dateLabel: '09 OCT 26' },
  { days: 17, label: "16 OCT '26 (17d) [M]", category: 'Monthly', month: 'OCT', monthYear: "OCT '26", dateLabel: '16 OCT 26' },
  { days: 24, label: "23 OCT '26 (24d)", category: 'Weekly', month: 'OCT', monthYear: "OCT '26", dateLabel: '23 OCT 26' },
  { days: 31, label: "30 OCT '26 (31d)", category: 'Weekly', month: 'OCT', monthYear: "OCT '26", dateLabel: '30 OCT 26' },
  { days: 38, label: "06 NOV '26 (38d)", category: 'Weekly', month: 'NOV', monthYear: "NOV '26", dateLabel: '06 NOV 26' },
  { days: 52, label: "20 NOV '26 (52d) [M]", category: 'Monthly', month: 'NOV', monthYear: "NOV '26", dateLabel: '20 NOV 26' },
  { days: 80, label: "18 DEC '26 (80d) [Q]", category: 'Quarterly', month: 'DEC', monthYear: "DEC '26", dateLabel: '18 DEC 26' },
  { days: 108, label: "15 JAN '27 (108d) [M]", category: 'Monthly', month: 'JAN', monthYear: "JAN '27", dateLabel: '15 JAN 27' },
  { days: 143, label: "19 FEB '27 (143d) [M]", category: 'Monthly', month: 'FEB', monthYear: "FEB '27", dateLabel: '19 FEB 27' },
  { days: 171, label: "19 MAR '27 (171d) [Q]", category: 'Quarterly', month: 'MAR', monthYear: "MAR '27", dateLabel: '19 MAR 27' },
  { days: 202, label: "16 APR '27 (202d) [M]", category: 'Monthly', month: 'APR', monthYear: "APR '27", dateLabel: '16 APR 27' },
  { days: 233, label: "21 MAY '27 (233d) [M]", category: 'Monthly', month: 'MAY', monthYear: "MAY '27", dateLabel: '21 MAY 27' },
  { days: 262, label: "18 JUN '27 (262d) [Q]", category: 'Quarterly', month: 'JUN', monthYear: "JUN '27", dateLabel: '18 JUN 27' },
  { days: 353, label: "17 SEP '27 (353d) [L]", category: 'LEAPS', month: 'SEP', monthYear: "SEP '27", dateLabel: '17 SEP 27' },
  { days: 445, label: "17 DEC '27 (445d) [L]", category: 'LEAPS', month: 'DEC', monthYear: "DEC '27", dateLabel: '17 DEC 27' },
  { days: 810, label: "15 DEC '28 (810d) [L]", category: 'LEAPS', month: 'DEC', monthYear: "DEC '28", dateLabel: '15 DEC 28' },
];

/**
 * Generates an authentic options chain around the given ticker and price
 */
export function generateOptionsChainForTicker(
  ticker: Ticker,
  dteDays: number
): ExpirationOptionChain {
  const S = ticker.price;
  const rawBaseIV = ticker.currentIV;
  const T = Math.max(0.001, dteDays / 365);

  // Term Structure adjustment based on IV Rank
  // Low IV Rank (< 50): Contango (front-month IV lower, back-month IV higher)
  // High IV Rank (>= 50): Backwardation (front-month IV elevated, back-month IV lower)
  const isHighVol = ticker.ivRank >= 50;
  const termSpread = isHighVol ? (ticker.ivRank - 50) / 100 : (50 - ticker.ivRank) / 100;
  const termSlope = (dteDays - 30) / 150; // -0.16 at 5D, 0 at 30D, +1.0 at 180D
  const termAdjustment = isHighVol ? -termSlope * termSpread * 0.18 : termSlope * termSpread * 0.18;
  const baseIV = Math.max(0.08, rawBaseIV * (1 + termAdjustment));

  const expDate = new Date();
  expDate.setDate(expDate.getDate() + dteDays);
  const dateStr = expDate.toISOString().split('T')[0];
  const formattedDate = expDate.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
  const monthName = expDate.toLocaleDateString('en-US', { month: 'short' }).toUpperCase();
  const yearShort = expDate.toLocaleDateString('en-US', { year: '2-digit' });
  const monthYear = `${monthName} '${yearShort}`;

  // Determine strike step size based on asset price & type
  let step = 1;
  let strikeCount = 52; // Full institutional strike spectrum (deep OTM to deep ITM)
  if (ticker.symbol === '/6E') {
    step = 0.005; // FX 50 pips
  } else if (ticker.symbol === '/NG') {
    step = 0.05;  // Natural Gas $0.05
  } else if (ticker.symbol === '/SI') {
    step = 0.25;  // Silver $0.25
  } else if (ticker.symbol === '/ZB' || ticker.symbol === '/ZN') {
    step = 0.50;  // Treasury bonds & notes half-point
  } else if (ticker.symbol === '/RTY') {
    step = 10;    // Russell 10 pts
  } else if (S > 50000) {
    step = 500; // e.g. /BTC
  } else if (S > 15000) {
    step = 50;  // e.g. /NQ
  } else if (S > 4000) {
    step = 25;  // e.g. /ES
  } else if (S > 2000) {
    step = 10;  // e.g. /GC, /ETH
  } else if (S > 500) {
    step = 5;
  } else if (S > 200) {
    step = 2.5;
  } else if (S > 100) {
    step = 1;
  } else if (S > 50) {
    step = 1;
  } else {
    step = 0.5;
  }

  const roundedAtm = Math.round(S / step) * step;
  const startStrike = Math.max(step, roundedAtm - Math.floor(strikeCount / 2) * step);

  // DTE scaling for skew steepness: short DTE has steeper skew slope (1 / sqrt(T))
  const dteScale = Math.max(0.55, Math.min(1.65, Math.sqrt(30 / Math.max(5, dteDays))));

  const calls: OptionContract[] = [];
  const puts: OptionContract[] = [];
  const strikePrecision = ticker.symbol === '/6E' ? 4 : ticker.symbol === '/NG' ? 3 : 2;

  for (let i = 0; i < strikeCount; i++) {
    const strike = Number((startStrike + i * step).toFixed(strikePrecision));
    const moneyness = strike / S; // >1 OTM call, <1 OTM put

    // Realistic volatility smile / skew (lower strikes have higher IV in equities)
    const skewFactor = (1 - moneyness) * (0.34 * dteScale);
    const smileFactor = Math.pow(moneyness - 1, 2) * (0.42 * dteScale);
    const callIV = Math.max(0.06, Number((baseIV + skewFactor * 0.55 + smileFactor).toFixed(4)));
    const putIV = Math.max(0.06, Number((baseIV + skewFactor * 1.08 + smileFactor).toFixed(4)));

    // BSM calculations
    const callBsm = calculateBSM(S, strike, T, callIV, 'call');
    const putBsm = calculateBSM(S, strike, T, putIV, 'put');

    // Spreads
    const callSpread = Math.max(0.02, Number((callBsm.price * 0.015 + 0.02).toFixed(2)));
    const putSpread = Math.max(0.02, Number((putBsm.price * 0.015 + 0.02).toFixed(2)));

    const callBid = Math.max(0.01, Number((callBsm.price - callSpread / 2).toFixed(2)));
    const callAsk = Number((callBsm.price + callSpread / 2).toFixed(2));

    const putBid = Math.max(0.01, Number((putBsm.price - putSpread / 2).toFixed(2)));
    const putAsk = Number((putBsm.price + putSpread / 2).toFixed(2));

    // Realistic Volume & Open Interest distribution (peak near ATM and round numbers)
    const distFromAtm = Math.abs(strike - roundedAtm) / S;
    const roundNumberBonus = strike % 5 === 0 ? 2.5 : strike % 1 === 0 ? 1.5 : 1.0;
    const baseVol = Math.max(20, Math.floor((12000 * roundNumberBonus) / (1 + distFromAtm * 35)));
    const baseOI = Math.max(80, Math.floor((34000 * roundNumberBonus) / (1 + distFromAtm * 25)));

    calls.push({
      strike,
      bid: callBid,
      ask: callAsk,
      last: callBsm.price,
      change: Number(((Math.random() - 0.45) * 0.35).toFixed(2)),
      volume: Math.floor(baseVol * (0.8 + Math.random() * 0.4)),
      openInterest: Math.floor(baseOI * (0.9 + Math.random() * 0.3)),
      iv: Number(callIV.toFixed(3)),
      delta: callBsm.greeks.delta,
      gamma: callBsm.greeks.gamma,
      theta: callBsm.greeks.theta,
      vega: callBsm.greeks.vega,
      rho: callBsm.greeks.rho,
      itm: S >= strike,
    });

    puts.push({
      strike,
      bid: putBid,
      ask: putAsk,
      last: putBsm.price,
      change: Number(((Math.random() - 0.52) * 0.35).toFixed(2)),
      volume: Math.floor(baseVol * (0.7 + Math.random() * 0.4)),
      openInterest: Math.floor(baseOI * (0.9 + Math.random() * 0.3)),
      iv: Number(putIV.toFixed(3)),
      delta: putBsm.greeks.delta,
      gamma: putBsm.greeks.gamma,
      theta: putBsm.greeks.theta,
      vega: putBsm.greeks.vega,
      rho: putBsm.greeks.rho,
      itm: S <= strike,
    });
  }

  return {
    expirationDate: dateStr,
    formattedDate,
    dte: dteDays,
    avgIV: Number(baseIV.toFixed(3)),
    month: monthName,
    monthYear,
    calls,
    puts,
  };
}

/**
 * Generates options chains across all standard expirations for a ticker
 */
export function generateAllOptionChainsForTicker(ticker: Ticker): ExpirationOptionChain[] {
  return EXPIRATION_PRESETS.map((preset) => generateOptionsChainForTicker(ticker, preset.days));
}

/**
 * Initial Multi-Asset Portfolio Positions (Stocks, Futures, and Options)
 * Pre-seeded so users immediately have realistic holdings to inspect, model, and stress-test in Risk Profile!
 */
export const INITIAL_PORTFOLIO_POSITIONS: Position[] = [
  // 1. Long Stock: NVDA (+100 Shares)
  {
    id: 'pos-stk-nvda-1',
    ticker: 'NVDA',
    strategyName: 'Long Stock (100 shs)',
    openedAt: '09:31:14',
    contracts: 100,
    entryCost: 12150.0, // bought @ $121.50
    currentMark: 12450.0, // mark @ $124.50
    unrealizedPnL: 300.0,
    unrealizedPnLPercent: 2.47,
    assetCategory: 'stock',
    sharesOrContracts: 100,
    legs: [
      {
        id: 'leg-nvda-stk-1',
        type: 'stock',
        action: 'buy',
        strike: 121.5,
        expiration: 'Perpetual',
        dte: 0,
        iv: 0,
        premium: 121.5,
        contracts: 100,
        multiplier: 1,
        underlyingSymbol: 'NVDA',
      },
    ],
  },
  // 2. Long Stock: AAPL (+150 Shares)
  {
    id: 'pos-stk-aapl-1',
    ticker: 'AAPL',
    strategyName: 'Long Stock (150 shs)',
    openedAt: '09:45:22',
    contracts: 150,
    entryCost: 33600.0, // bought @ $224.00
    currentMark: 34170.0, // mark @ $227.80
    unrealizedPnL: 570.0,
    unrealizedPnLPercent: 1.7,
    assetCategory: 'stock',
    sharesOrContracts: 150,
    legs: [
      {
        id: 'leg-aapl-stk-1',
        type: 'stock',
        action: 'buy',
        strike: 224.0,
        expiration: 'Perpetual',
        dte: 0,
        iv: 0,
        premium: 224.0,
        contracts: 150,
        multiplier: 1,
        underlyingSymbol: 'AAPL',
      },
    ],
  },
  // 3. Long Futures: /ES E-mini S&P 500 (+2 Contracts, $50 Multiplier)
  {
    id: 'pos-fut-es-1',
    ticker: '/ES',
    strategyName: 'Long Future (2 cts)',
    openedAt: '08:15:00',
    contracts: 2,
    entryCost: 578000.0, // 2 * 5,780.00 * 50
    currentMark: 582400.0, // 2 * 5,824.00 * 50
    unrealizedPnL: 4400.0,
    unrealizedPnLPercent: 0.76,
    assetCategory: 'future',
    sharesOrContracts: 2,
    legs: [
      {
        id: 'leg-es-fut-1',
        type: 'future',
        action: 'buy',
        strike: 5780.0,
        expiration: 'DEC 26',
        dte: 78,
        iv: 0.142,
        premium: 5780.0,
        contracts: 2,
        multiplier: 50,
        underlyingSymbol: '/ES',
      },
    ],
  },
  // 4. Long Futures: /CL WTI Crude Oil (+1 Contract, 1,000 bbl Multiplier)
  {
    id: 'pos-fut-cl-1',
    ticker: '/CL',
    strategyName: 'Long Future (1 ct)',
    openedAt: '07:30:11',
    contracts: 1,
    entryCost: 70400.0, // 1 * 70.40 * 1,000
    currentMark: 71350.0, // 1 * 71.35 * 1,000
    unrealizedPnL: 950.0,
    unrealizedPnLPercent: 1.35,
    assetCategory: 'future',
    sharesOrContracts: 1,
    legs: [
      {
        id: 'leg-cl-fut-1',
        type: 'future',
        action: 'buy',
        strike: 70.4,
        expiration: 'NOV 26',
        dte: 48,
        iv: 0.386,
        premium: 70.4,
        contracts: 1,
        multiplier: 1000,
        underlyingSymbol: '/CL',
      },
    ],
  },
  // 5. Options: NVDA Covered Call Short 130 Call (-1 Contract)
  {
    id: 'pos-opt-nvda-cc-1',
    ticker: 'NVDA',
    strategyName: 'Short Call Hedge (1 ct)',
    openedAt: '10:05:30',
    contracts: 1,
    entryCost: -380.0, // sold @ $3.80 credit
    currentMark: -290.0, // mark @ $2.90
    unrealizedPnL: 90.0,
    unrealizedPnLPercent: 23.68,
    assetCategory: 'option',
    sharesOrContracts: 1,
    legs: [
      {
        id: 'leg-nvda-opt-1',
        type: 'call',
        action: 'sell',
        strike: 130.0,
        expiration: 'Oct 18, 2026',
        dte: 21,
        iv: 0.442,
        premium: 3.8,
        contracts: 1,
        multiplier: 100,
        underlyingSymbol: 'NVDA',
      },
    ],
  },
  // 6. Options Spread: SPY Bull Call Spread (+2 Contracts)
  {
    id: 'pos-opt-spy-bcs-1',
    ticker: 'SPY',
    strategyName: 'Bull Call Spread (2 cts)',
    openedAt: '11:12:44',
    contracts: 2,
    entryCost: 680.0, // debit $3.40 * 200
    currentMark: 820.0, // mark $4.10 * 200
    unrealizedPnL: 140.0,
    unrealizedPnLPercent: 20.59,
    assetCategory: 'option',
    sharesOrContracts: 2,
    legs: [
      {
        id: 'leg-spy-opt-c1',
        type: 'call',
        action: 'buy',
        strike: 565.0,
        expiration: 'Oct 25, 2026',
        dte: 28,
        iv: 0.138,
        premium: 6.8,
        contracts: 2,
        multiplier: 100,
        underlyingSymbol: 'SPY',
      },
      {
        id: 'leg-spy-opt-c2',
        type: 'call',
        action: 'sell',
        strike: 575.0,
        expiration: 'Oct 25, 2026',
        dte: 28,
        iv: 0.132,
        premium: 3.4,
        contracts: 2,
        multiplier: 100,
        underlyingSymbol: 'SPY',
      },
    ],
  },
  // 7. Short Stock: TSLA (-100 Shares · Moderate Short Borrow Rate)
  {
    id: 'pos-stk-tsla-short',
    ticker: 'TSLA',
    strategyName: 'Short Stock (-100 shs)',
    openedAt: '09:50:12',
    contracts: 100,
    entryCost: -25400.0, // short sold @ $254.00 (credit received)
    currentMark: -24850.0, // mark @ $248.50 to buy back
    unrealizedPnL: 550.0,
    unrealizedPnLPercent: 2.17,
    assetCategory: 'stock',
    sharesOrContracts: 100,
    legs: [
      {
        id: 'leg-tsla-short-stk',
        type: 'stock',
        action: 'sell',
        strike: 254.0,
        expiration: 'Perpetual',
        dte: 0,
        iv: 0,
        premium: 254.0,
        contracts: 100,
        multiplier: 1,
        underlyingSymbol: 'TSLA',
      },
    ],
  },
  // 8. Short Stock HTB: DJT (-200 Shares · Hard to Borrow 18.5% Rate)
  {
    id: 'pos-stk-djt-short',
    ticker: 'DJT',
    strategyName: 'Short Stock HTB (-200 shs)',
    openedAt: '10:18:30',
    contracts: 200,
    entryCost: -6800.0, // short sold @ $34.00
    currentMark: -6300.0, // mark @ $31.50
    unrealizedPnL: 500.0,
    unrealizedPnLPercent: 7.35,
    assetCategory: 'stock',
    sharesOrContracts: 200,
    legs: [
      {
        id: 'leg-djt-short-stk',
        type: 'stock',
        action: 'sell',
        strike: 34.0,
        expiration: 'Perpetual',
        dte: 0,
        iv: 0,
        premium: 34.0,
        contracts: 200,
        multiplier: 1,
        underlyingSymbol: 'DJT',
      },
    ],
  },
];

export interface YieldCurvePoint {
  maturity: string; // "1M", "2M", "3M", "6M", "1Y", "2Y", "3Y", "5Y", "7Y", "10Y", "20Y", "30Y"
  years: number;    // e.g. 0.083, 0.167, 0.25, 0.5, 1, 2, 3, 5, 7, 10, 20, 30
  currentYield: number; // in %
  oneMonthAgoYield: number; // in %
  oneYearAgoYield: number; // in %
  change1M: number; // in bps
  change1Y: number; // in bps
}

export interface YieldCurveSpread {
  pair: string; // e.g. "2s10s", "3m10s", "5s30s"
  name: string;
  spreadBps: number; // 10Y - 2Y in basis points
  status: 'INVERTED' | 'FLAT' | 'NORMAL' | 'STEEPENING';
  significance: string;
}

export const YIELD_CURVE_DATA: YieldCurvePoint[] = [
  { maturity: '1M', years: 0.083, currentYield: 4.88, oneMonthAgoYield: 5.34, oneYearAgoYield: 5.48, change1M: -46, change1Y: -60 },
  { maturity: '2M', years: 0.167, currentYield: 4.82, oneMonthAgoYield: 5.28, oneYearAgoYield: 5.45, change1M: -46, change1Y: -63 },
  { maturity: '3M', years: 0.250, currentYield: 4.75, oneMonthAgoYield: 5.21, oneYearAgoYield: 5.44, change1M: -46, change1Y: -69 },
  { maturity: '6M', years: 0.500, currentYield: 4.48, oneMonthAgoYield: 4.98, oneYearAgoYield: 5.38, change1M: -50, change1Y: -90 },
  { maturity: '1Y', years: 1.000, currentYield: 3.98, oneMonthAgoYield: 4.45, oneYearAgoYield: 5.15, change1M: -47, change1Y: -117 },
  { maturity: '2Y', years: 2.000, currentYield: 3.64, oneMonthAgoYield: 3.92, oneYearAgoYield: 4.88, change1M: -28, change1Y: -124 },
  { maturity: '3Y', years: 3.000, currentYield: 3.55, oneMonthAgoYield: 3.80, oneYearAgoYield: 4.62, change1M: -25, change1Y: -107 },
  { maturity: '5Y', years: 5.000, currentYield: 3.56, oneMonthAgoYield: 3.75, oneYearAgoYield: 4.42, change1M: -19, change1Y: -86 },
  { maturity: '7Y', years: 7.000, currentYield: 3.65, oneMonthAgoYield: 3.82, oneYearAgoYield: 4.40, change1M: -17, change1Y: -75 },
  { maturity: '10Y', years: 10.00, currentYield: 3.75, oneMonthAgoYield: 3.88, oneYearAgoYield: 4.35, change1M: -13, change1Y: -60 },
  { maturity: '20Y', years: 20.00, currentYield: 4.15, oneMonthAgoYield: 4.22, oneYearAgoYield: 4.62, change1M: -7, change1Y: -47 },
  { maturity: '30Y', years: 30.00, currentYield: 4.12, oneMonthAgoYield: 4.18, oneYearAgoYield: 4.48, change1M: -6, change1Y: -36 },
];

export const YIELD_CURVE_SPREADS: YieldCurveSpread[] = [
  {
    pair: '2s10s',
    name: '10Y Minus 2Y Spread',
    spreadBps: 11.0, // 3.75 - 3.64 = +11 bps
    status: 'STEEPENING',
    significance: 'Exited historical 2-year inversion (deepest was -108 bps). Disinversion historically signals initial phases of monetary easing cycles.',
  },
  {
    pair: '3m10s',
    name: '10Y Minus 3M Spread',
    spreadBps: -100.0, // 3.75 - 4.75 = -100 bps
    status: 'INVERTED',
    significance: 'Primary recession predictor monitored by New York Fed. Remains inverted due to elevated policy rate floor.',
  },
  {
    pair: '5s30s',
    name: '30Y Minus 5Y Spread',
    spreadBps: 56.0, // 4.12 - 3.56 = +56 bps
    status: 'NORMAL',
    significance: 'Long end term premium expanding reflecting long-run US Treasury fiscal supply issuance expectations.',
  },
];
